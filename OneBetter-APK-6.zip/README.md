# OneBetter

Pequenas ações, grandes resultados.

App Android (Capacitor) com todo o código em `www/index.html`. Os dados ficam no telemóvel (IndexedDB) e funcionam sem Internet. Os lembretes são notificações nativas e disparam com a app fechada.

## Compilar com o GitHub (só pelo telemóvel)

1. Cria um repositório no GitHub (ex.: `onebetter`).
2. **Add file → Create new file** → no nome escreve `.github/workflows/compilar.yml` (cada `/` cria uma pasta) → cola o conteúdo do ficheiro `compilar.yml` → **Commit changes**.
3. **Add file → Upload files** → envia o zip **sem extrair** (qualquer nome) → **Commit changes**. A compilação começa sozinha.
4. Separador **Actions**: amarelo = a compilar (6–10 min), verde = pronto, vermelho = erro.
5. Página inicial do repositório → **Releases** → "OneBetter (última compilação)" → **OneBetter.apk** → instala (permite "fontes desconhecidas").

Para atualizar a app, envia outro zip com o mesmo nome. Também podes enviar só `config.js` e/ou `google-services.json` para a raiz do repositório: o workflow usa-os por cima dos do zip.
Se aparecer erro 403 no passo das Releases: Settings → Actions → General → Workflow permissions → **Read and write permissions**.

O APK usa sempre a mesma chave de assinatura (`assets/debug.keystore`), por isso cada versão nova **atualiza por cima** e mantém os dados.
SHA-1 dessa chave (para o Google): `5E:23:C4:77:0B:7C:14:F4:F1:44:ED:CC:B9:1F:28:87:28:72:F8:8C`

**Versão web (opcional):** Settings → Pages → Source: **GitHub Actions**; depois Actions → "Publicar versão web" → Run workflow. O endereço é `https://<utilizador>.github.io/<repositório>/`. O GitHub Pages gratuito exige repositório **público**. Abre o endereço no telemóvel e escolhe "Adicionar ao ecrã inicial".

## Configuração única (`www/config.js`)

Preenche uma vez e todos os utilizadores da tua versão ficam com isto ativo (sem colar nada na app):
- `firebase`: o `firebaseConfig` do teu projeto.
- `tmdbKey`: chave TMDB (filmes). Fica visível no código: só para projeto pessoal e não comercial.
- `aiUrl` e `aiToken`: serviço de IA (ver `ai-proxy/README.md`).

## Google (cadastro e entrada)

1. Firebase → Authentication → Sign-in method → ativa **Google** e **Email/palavra-passe**.
2. **Web:** Authentication → Settings → Authorized domains → adiciona `<utilizador>.github.io`.
3. **APK:** Firebase → Definições do projeto → Adicionar app **Android** → pacote `com.geronimo.onebetter` → SHA-1 acima → descarrega `google-services.json` e envia-o **para a raiz do repositório** (Add file → Upload files). O build instala sozinho o plugin do Google quando o encontra. Se o ficheiro não existir, o APK compila na mesma e só tem email.
4. Cria o Firestore com `firestore.rules` (passo 3 da secção de sincronização).

## APIs usadas (todas gratuitas)

1. **Firebase Authentication** (email e Google) e 2. **Cloud Firestore** (dados em qualquer dispositivo).
3. **Google Books** e 4. **TMDB** (Biblioteca; atribuição TMDB no ecrã Sobre; falta o logótipo oficial).
5. **Gemini via Cloudflare Worker** (IA online opcional).
6. **Open-Meteo** previsão e 7. **Open-Meteo Geocoding** (tempo no ecrã Hoje).
8. **Nager.Date** (feriados do teu país).
9. **ExchangeRate-API open** (câmbio).
10. **Wikipédia REST** (resumos).
11. **Open Library** (livros).
12. **Free Dictionary API** (inglês).
13. **Open Trivia DB** (treino rápido).
14. Open-Meteo Air Quality, 15. ipwho.is (detetar cidade), 16. REST Countries, 17. Wikimedia Neste dia, 18. MyMemory (tradutor), 19. Datamuse (sinónimos), 20. Stack Exchange (dúvidas), 21. Hipolabs (universidades), 22. DEV (artigos), 23. Hacker News, 24. Where the ISS at?, 25. NASA APOD (DEMO_KEY), 26. The Space Devs, 27. USGS (sismos), 28. Open Food Facts, 29. TheMealDB, 30. CoinGecko, 31. Art Institute of Chicago, 32. PoetryDB, 33. QR Server, 34. Advice Slip, 35. Useless Facts, 36. JokeAPI.
As 14 a 36 estão em Perfil, Explorar, Mais ferramentas. Nenhuma precisa de chave. Podem falhar ou mudar: a app mostra o erro e usa a última cópia guardada quando existe.
Além disso, APIs do sistema: notificações locais, Web Audio e vibração (alarme). Resultados ficam em cache e abrem offline.

## O que a app faz

- **Hoje / Plano / Livre / Progresso / Perfil.** No Perfil: conquistas, atividade, conta e atalhos para Objetivos, Assistente, Biblioteca, Explorar e Definições.
- **Gestos:** deslizar para os lados troca de separador; puxar para baixo atualiza e sincroniza; deslizar uma tarefa para a direita conclui, para a esquerda reagenda (num hábito, marca).
- **Fluidez:** barra de baixo que esconde ao deslizar, título que fica fixo no topo, fundo que recua quando abre uma janela, esqueletos de carregamento, vibração suave (desligável), confete ao concluir, anéis que se enchem.
- **Tarefas repetidas:** campo "Repetir" (todos os dias, dias úteis, semanal, mensal). A app cria as próximas ocorrências dos 7 dias seguintes.
- **Modo livre no APK:** notificação fixa enquanto conta, com botões Pausar e Terminar.
- **Modo livre:** cronómetro por atividade; o tempo guarda-se e aparece nos gráficos em tempo real.
- **Alarme:** atividades com "Alarme sonoro à hora" tocam (som e vibração, com ecrã de parar/adiar). No APK o alarme está agendado no sistema; em Definições há "Permitir alarmes exatos".
- **Aparência:** claro/escuro/automático, 6 cores de tema, 4 fontes, animações completas/suaves/desligadas.
- **Login:** com o Firebase configurado, a app pede conta (email ou Google); sem ligação continuas com a sessão já iniciada.
- **Planeador:** "Organizar este dia" e "Organizar a semana" propõem horários dentro da janela livre que defines, com pausas e margem. Mostra porquê, o que não cabe, e só aplica o que confirmares. Compromissos com hora e hábitos nunca são mexidos. Pesos da pontuação configuráveis nas Definições (prioridade ×10, urgência +8, objetivo +4, adiamentos −1 por defeito).
- **Reagendar:** mudar, reduzir, dividir ou remover; tarefas adiadas ≥2 vezes têm diagnóstico (duração, horário, clareza, energia, prioridade).
- **Hábitos** com sinal/desejo/resposta/recompensa, versão mínima e plano "se X, então Y"; sem punição por falhas.
- **Revisões** diária e semanal; resumos semanais e mensais só com dados registados.
- **Assistente:** regras locais (identificado como "Sistema local"). IA online opcional, só se configurares o teu próprio serviço nas Definições; se falhar, usa as regras locais e diz-to.
- **Biblioteca:** 25 itens guardados offline, recomendados pelos teus objetivos; podes adicionar os teus.

## Conta e sincronização (opcional)

Sem conta tudo funciona localmente. Para sincronizar:

1. console.firebase.google.com → Adicionar projeto.
2. Authentication → Começar → ativa **Email/palavra-passe** (Google só funciona no navegador, não no APK).
3. Firestore Database → Criar base de dados → **Regras** → cola `firestore.rules` → Publicar.
4. Definições do projeto → As tuas apps → Web → copia o `firebaseConfig`.
5. Na app: ⚙️ → "Conta e sincronização" → cola a configuração → cria conta.

Ao criar conta, os dados locais são associados à conta sem duplicar (ids estáveis). Em conflito (mesmo registo alterado em dois dispositivos) nada é apagado: escolhes que versão manter.

## Arquitetura (decisões)

- Um ficheiro para a app, por escolha (sem backend). Camadas separadas no código: `DB` (IndexedDB), `Logic` (regras puras), `Sync`/`FB`/`Cloud`, `Native`/`Notify`, interface.
- Toda a escrita regista uma operação em `syncOps` (fila). A sincronização envia, recebe, deteta conflitos e só limpa o que foi enviado.
- Os registos usam `updatedAt` do relógio do dispositivo; relógios muito desajustados podem afetar a ordem.

## Limitações conhecidas

- Os lembretes são agendados para os próximos 7 dias de cada vez que abres a app; se não a abrires durante mais de 7 dias, deixam de tocar. O Android pode limitar alarmes com poupança de bateria agressiva: define "Sem restrições" para a OneBetter.
- Sem tarefas recorrentes, tempo de deslocação, nem informação de streaming. O Google no APK não foi testado num telemóvel real (só o fluxo com simulações).
- Notificações push (FCM), App Check e Crashlytics não estão configurados.
- O APK é de debug (assinado com chave de debug): serve para instalar diretamente, não para a Play Store.
- O APK não pôde ser compilado no ambiente de desenvolvimento; a compilação corre no GitHub.

## Testes feitos

- Lógica: planeador, dependências, sobrecarga, resumos, recomendações, respostas locais.
- Sincronização com dois dispositivos simulados: duplicados, falha de rede, conflitos, eliminação.
- Fluxo web com simulações de Google, Firestore, Google Books e IA (login, sincronização automática, pesquisa, guardar, falha da IA, service worker).
- Fluxo completo em Chromium móvel (onboarding, atividade, planeador, concluir, hábitos, biblioteca, revisão, reinício sem perda de dados).

## Versão 3.3
- Cada ferramenta do Explorar abre numa página própria (botão Voltar); 32 ferramentas, com novas APIs sem chave: Frankfurter/ER-API, Crossref, TVMaze, iTunes (podcasts), Banco Mundial, Open-Meteo Marine, Wikipédia por idioma.
- "Para hoje" usa apenas a cidade que escolheste (tempo, UV, ar, feriados, câmbio, hora local).
- Idiomas: Português, English, Français (Definições, Idioma). Receitas, curiosidades, definições e outros conteúdos são traduzidos automaticamente (MyMemory/Lingva); se o serviço falhar, mostra o original.
- Barra de baixo desfoca o conteúdo atrás.
