# Serviço de IA (opcional, gratuito para começar)

Usa o Cloudflare Workers (plano gratuito, sem cartão) e a API Gemini (chave grátis no Google AI Studio). Confirma os limites atuais em ai.google.dev/gemini-api/docs/rate-limits e em developers.cloudflare.com/workers/platform/pricing.

1. aistudio.google.com → Get API key → copia a chave.
2. dash.cloudflare.com → Workers & Pages → Create → Worker → Deploy → Edit code → cola `worker.js` → Deploy.
3. Settings → Variables and Secrets → adiciona como **Secret**: `GEMINI_API_KEY` (a chave) e `APP_TOKEN` (uma palavra-passe longa que inventares). Opcional: `GEMINI_MODEL`.
4. Copia o endereço do Worker (`https://nome.conta.workers.dev`).
5. Na app: ⚙️ → Assistente com IA online → liga e cola o endereço e o código de acesso (ou põe-nos em `www/config.js`).

A app só envia a pergunta e totais (minutos planeados, minutos disponíveis, nº de objetivos). Nunca notas nem títulos. Limite de 20 pedidos por dia por dispositivo.
