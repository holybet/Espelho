package mz.espelho

import android.content.Context
import org.json.JSONObject
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

/** Pessoa com o Espelho ligado. [seen] é a hora local (ms) do último sinal. */
data class Person(val id: String, val name: String, val seen: Long)

/** Pedido recebido: alguém quer ver a nossa tela. */
data class Request(val id: String, val name: String)

/** Estado partilhado entre o ecrã, o serviço "online" e o serviço de partilha. */
object Online {
    const val DIR = "espelho-mz-lista"

    @Volatile var myId = ""
    @Volatile var myName = ""
    @Volatile var running = false
    @Volatile var lastMsg = ""

    val people = ConcurrentHashMap<String, Person>()

    @Volatile var incoming: Request? = null

    /** Mensagens para quem está a ver (deny, offer, byes). Chamado na thread principal. */
    @Volatile var viewerHandler: ((JSONObject) -> Unit)? = null

    /** Mensagens para quem está a partilhar (answer, byev). Chamado na thread principal. */
    @Volatile var shareHandler: ((JSONObject) -> Unit)? = null

    @Volatile var onChange: (() -> Unit)? = null

    fun load(context: Context) {
        Store.init(context)
        val prefs = context.applicationContext.getSharedPreferences("espelho", Context.MODE_PRIVATE)
        var id = prefs.getString("id", null)
        if (id == null) {
            val bytes = ByteArray(8)
            SecureRandom().nextBytes(bytes)
            id = bytes.joinToString("") { "%02x".format(it) }
            prefs.edit().putString("id", id).apply()
        }
        myId = id
        myName = prefs.getString("name", "") ?: ""
    }

    fun saveName(context: Context, name: String) {
        val clean = name.trim().take(24)
        context.applicationContext.getSharedPreferences("espelho", Context.MODE_PRIVATE)
            .edit().putString("name", clean).apply()
        myName = clean
    }

    fun inbox(id: String) = "espelho-mz-u-$id"

    /** Envia uma mensagem para a caixa de entrada de outra pessoa. */
    fun send(to: String, message: JSONObject) {
        message.put("from", myId).put("name", myName)
        Ntfy.send(inbox(to), message)
    }

    fun changed() {
        onChange?.invoke()
    }
}
