package mz.espelho

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Caixa de correio pública (ntfy.sh): só passa a lista de nomes, os pedidos e o SDP.
 * O vídeo nunca passa por aqui, vai direto entre os celulares.
 */
object Ntfy {
    const val HOST = "https://ntfy.sh"

    /** Diferença entre o relógio do servidor e o do celular (ms), medida ao ligar. */
    @Volatile var skewMs = 0L

    fun send(topic: String, message: JSONObject) {
        thread(isDaemon = true, name = "ntfy-enviar") {
            for (attempt in 0 until 3) {
                try {
                    val c = URL("$HOST/$topic").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.connectTimeout = 15000
                    c.readTimeout = 15000
                    c.outputStream.use { it.write(message.toString().toByteArray(Charsets.UTF_8)) }
                    val ok = c.responseCode in 200..299
                    c.disconnect()
                    if (ok) return@thread
                } catch (ignored: Exception) {
                    // tenta de novo
                }
                try {
                    Thread.sleep(1500)
                } catch (e: InterruptedException) {
                    return@thread
                }
            }
        }
    }

    /** Idade, em segundos, de uma mensagem com a hora [serverTime] do servidor. */
    fun ageSeconds(serverTime: Long): Long =
        (System.currentTimeMillis() + skewMs) / 1000 - serverTime
}

/** Escuta um tópico e volta a ligar sozinho se a ligação cair. */
class NtfyListener(
    private val topic: String,
    private val since: String,
    private val onMessage: (JSONObject, Long) -> Unit
) {
    @Volatile private var open = true
    @Volatile private var conn: HttpURLConnection? = null

    fun start() {
        thread(isDaemon = true, name = "ntfy-ouvir-$topic") {
            var lastId: String? = null
            while (open) {
                try {
                    val from = lastId ?: since
                    val c = URL("${Ntfy.HOST}/$topic/json?since=$from").openConnection() as HttpURLConnection
                    conn = c
                    c.connectTimeout = 15000
                    c.readTimeout = 120000
                    c.setRequestProperty("Accept-Encoding", "identity")
                    c.inputStream.bufferedReader().use { reader ->
                        while (open) {
                            val line = reader.readLine() ?: break
                            if (line.isBlank()) continue
                            try {
                                val event = JSONObject(line)
                                val time = event.optLong("time", 0L)
                                when (event.optString("event")) {
                                    "open" -> if (time > 0) {
                                        Ntfy.skewMs = time * 1000 - System.currentTimeMillis()
                                    }
                                    "message" -> {
                                        val id = event.optString("id", "")
                                        if (id.isNotEmpty()) lastId = id
                                        onMessage(JSONObject(event.getString("message")), time)
                                    }
                                }
                            } catch (ignored: Exception) {
                                // mensagem inválida: ignora
                            }
                        }
                    }
                } catch (ignored: Exception) {
                    // ligação caiu: volta a tentar
                }
                if (open) {
                    try {
                        Thread.sleep(2000)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            }
        }
    }

    fun stop() {
        open = false
        try {
            conn?.disconnect()
        } catch (ignored: Exception) {
        }
    }
}
