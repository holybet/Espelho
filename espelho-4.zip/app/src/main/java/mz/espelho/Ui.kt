package mz.espelho

import android.animation.ObjectAnimator
import android.animation.TimeInterpolator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

/** Cores: preto profundo, laranja âmbar e brancos translúcidos. */
object Palette {
    val BG: Int = Color.parseColor("#040404")
    val ORANGE: Int = Color.parseColor("#FF7A1A")
    val ORANGE_HOT: Int = Color.parseColor("#FF4D00")
    val AMBER: Int = Color.parseColor("#FFB347")
    val CREAM: Int = Color.parseColor("#FFE2C2")
    val WHITE: Int = Color.WHITE
    val SOFT: Int = Color.argb(205, 255, 255, 255)
    val FAINT: Int = Color.argb(125, 255, 255, 255)
    val GOOD: Int = Color.parseColor("#4DFFA6")
    val BAD: Int = Color.parseColor("#FF6B5B")
    val WARN: Int = Color.parseColor("#FFC247")
}

/** Fontes de terminal (DejaVu Sans Mono, incluída em res/font). */
object Fonts {
    var mono: Typeface = Typeface.MONOSPACE
    var monoBold: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun init(ctx: Context) {
        try {
            mono = ctx.resources.getFont(R.font.visk_mono)
            monoBold = ctx.resources.getFont(R.font.visk_mono_bold)
        } catch (e: Exception) {
            // fica a monoespaçada do sistema
        }
    }
}

/** Mola elástica: passa do alvo, balança e assenta (efeito "líquido" do iOS 26). */
class Elastic(private val period: Float = 0.42f, private val decay: Float = 8f) : TimeInterpolator {
    override fun getInterpolation(t: Float): Float {
        if (t <= 0f) return 0f
        if (t >= 1f) return 1f
        val wave = sin(((t - period / 4f) * 2.0 * PI / period))
        return (2.0.pow((-decay * t).toDouble()) * wave + 1.0).toFloat()
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.tv(text: String, sp: Float, color: Int = Palette.WHITE, bold: Boolean = false): TextView {
    val view = TextView(this)
    view.text = text
    view.textSize = sp
    view.setTextColor(color)
    view.typeface = if (bold) Fonts.monoBold else Fonts.mono
    return view
}

fun Context.lp(top: Int = 0, width: Int = ViewGroup.LayoutParams.MATCH_PARENT): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT)
    p.topMargin = dp(top)
    return p
}

/** Ao tocar, achata um pouco; ao largar, volta com um salto elástico. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.95f).scaleY(0.89f).setDuration(150)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(700)
                    .setInterpolator(Elastic()).start()
        }
        false
    }
}

/** Entrada elástica: sobe com um salto e aparece. */
fun View.springIn(delayMs: Long = 0L, rise: Int = 30) {
    animate().cancel()
    translationY = context.dp(rise).toFloat()
    scaleX = 0.94f
    scaleY = 0.94f
    alpha = 0f
    animate().translationY(0f).scaleX(1f).scaleY(1f)
        .setStartDelay(delayMs).setDuration(760).setInterpolator(Elastic()).start()
    val fade = ObjectAnimator.ofFloat(this, View.ALPHA, 0f, 1f)
    fade.duration = 260
    fade.startDelay = delayMs
    fade.start()
}

/** Escreve o texto letra a letra, como num terminal. */
fun TextView.typeText(full: String, perChar: Long = 26L) {
    (tag as? Runnable)?.let { removeCallbacks(it) }
    text = ""
    var i = 0
    val step = object : Runnable {
        override fun run() {
            i++
            text = full.substring(0, minOf(i, full.length))
            if (i < full.length) postDelayed(this, perChar)
        }
    }
    tag = step
    post(step)
}

/** Faz o texto piscar como o cursor de um terminal. */
fun View.blink() {
    val a = ObjectAnimator.ofFloat(this, View.ALPHA, 1f, 0.05f)
    a.duration = 520
    a.repeatCount = ObjectAnimator.INFINITE
    a.repeatMode = ObjectAnimator.REVERSE
    a.start()
}

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}
