package mz.espelho

import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import kotlin.math.cos
import kotlin.math.sin

/** Temas: toda a cor da app é desenhada em laranja e rodada para o matiz do tema escolhido. */
object Hue {
    val NAMES = listOf("LARANJA", "CIANO", "VIOLETA", "VERDE", "ROSA")
    val DEGREES = floatArrayOf(0f, 163f, 245f, 115f, 310f)

    @Volatile var deg = 0f
    private var m = matrix(0f)

    fun set(theme: Int) {
        deg = DEGREES[theme.coerceIn(0, DEGREES.size - 1)]
        m = matrix(deg)
    }

    private fun matrix(d: Float): FloatArray {
        val r = Math.toRadians(d.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        return floatArrayOf(
            0.213f + c * 0.787f - s * 0.213f, 0.715f - c * 0.715f - s * 0.715f, 0.072f - c * 0.072f + s * 0.928f,
            0.213f - c * 0.213f + s * 0.143f, 0.715f + c * 0.285f + s * 0.140f, 0.072f - c * 0.072f - s * 0.283f,
            0.213f - c * 0.213f - s * 0.787f, 0.715f - c * 0.715f + s * 0.715f, 0.072f + c * 0.928f + s * 0.072f
        )
    }

    private fun cl(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else (v + 0.5f).toInt()

    private fun apply(mm: FloatArray, a: Int, r: Int, g: Int, b: Int): Int {
        val nr = mm[0] * r + mm[1] * g + mm[2] * b
        val ng = mm[3] * r + mm[4] * g + mm[5] * b
        val nb = mm[6] * r + mm[7] * g + mm[8] * b
        return Color.argb(a, cl(nr), cl(ng), cl(nb))
    }

    fun argb(a: Int, r: Int, g: Int, b: Int): Int =
        if (deg == 0f) Color.argb(a, r, g, b) else apply(m, a, r, g, b)

    fun rgb(r: Int, g: Int, b: Int): Int = argb(255, r, g, b)

    fun color(c: Int): Int = argb(Color.alpha(c), Color.red(c), Color.green(c), Color.blue(c))

    /** Cor representativa de um tema (para as bolinhas de escolha). */
    fun swatch(theme: Int): Int =
        apply(matrix(DEGREES[theme]), 255, 255, 122, 26)

    fun filter(): ColorMatrixColorFilter? {
        if (deg == 0f) return null
        return ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    m[0], m[1], m[2], 0f, 0f,
                    m[3], m[4], m[5], 0f, 0f,
                    m[6], m[7], m[8], 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
}
