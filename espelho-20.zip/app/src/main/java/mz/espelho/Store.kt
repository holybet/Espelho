package mz.espelho

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Uma sessão registada no histórico. [dir] é "view" (viu) ou "share" (partilhou). */
data class Entry(val id: String, val name: String, val dir: String, val start: Long, val dur: Long)

/** Mensagem de uma conversa. [path] não vazio = anexo guardado no telemóvel. */
data class ChatMsg(
    val mine: Boolean, val text: String, val time: Long,
    val path: String = "", val fname: String = "", val fsize: Long = 0L, val mime: String = ""
)

data class ChatPeer(val id: String, val name: String, val last: String, val mine: Boolean, val time: Long, val unread: Int)

/** Dados guardados no celular: favoritos, bloqueados, histórico e ajustes. */
object Store {
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs == null) {
            prefs = ctx.applicationContext.getSharedPreferences("espelho", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = prefs ?: throw IllegalStateException("Store não iniciado")

    private fun readMap(key: String): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        try {
            val o = JSONObject(p().getString(key, "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                out[k] = o.optString(k)
            }
        } catch (e: Exception) {
            // dados inválidos: começa vazio
        }
        return out
    }

    private fun writeMap(key: String, map: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        p().edit().putString(key, o.toString()).apply()
    }

    // ------------------------------------------------------------ favoritos
    fun favorites(): LinkedHashMap<String, String> = readMap("fav")

    fun isFav(id: String): Boolean = readMap("fav").containsKey(id)

    fun toggleFav(id: String, name: String) {
        val m = readMap("fav")
        if (m.containsKey(id)) m.remove(id) else m[id] = name
        writeMap("fav", m)
    }

    // ------------------------------------------------------------ bloqueados
    fun blocked(): LinkedHashMap<String, String> = readMap("blocked")

    fun isBlocked(id: String): Boolean = readMap("blocked").containsKey(id)

    fun block(id: String, name: String) {
        val m = readMap("blocked")
        m[id] = name
        writeMap("blocked", m)
    }

    fun unblock(id: String) {
        val m = readMap("blocked")
        m.remove(id)
        writeMap("blocked", m)
    }

    // ------------------------------------------------------------ histórico
    fun history(): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            val a = JSONArray(p().getString("hist", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.optString("id"), o.optString("name"), o.optString("dir"), o.optLong("start"), o.optLong("dur")))
            }
        } catch (e: Exception) {
            // dados inválidos: lista vazia
        }
        return out
    }

    fun addHistory(e: Entry) {
        val a = JSONArray()
        a.put(JSONObject().put("id", e.id).put("name", e.name).put("dir", e.dir).put("start", e.start).put("dur", e.dur))
        val old = history()
        for (i in 0 until minOf(old.size, 59)) {
            val x = old[i]
            a.put(JSONObject().put("id", x.id).put("name", x.name).put("dir", x.dir).put("start", x.start).put("dur", x.dur))
        }
        p().edit().putString("hist", a.toString()).apply()
    }

    fun clearHistory() {
        p().edit().putString("hist", "[]").apply()
    }

    // ------------------------------------------------------------ chat
    private fun readList(key: String): ArrayList<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(p().getString(key, "[]") ?: "[]")
            for (i in 0 until a.length()) out.add(a.optString(i))
        } catch (e: Exception) {
            // vazio
        }
        return out
    }

    fun seenMid(mid: String): Boolean = mid.isNotEmpty() && readList("chat_mids").contains(mid)

    private fun preview(text: String, fname: String, mime: String): String = when {
        fname.isEmpty() -> text.take(80)
        mime.startsWith("image/") -> "[foto] " + text.take(60)
        else -> "[ficheiro] $fname"
    }

    /** Guarda uma mensagem. Devolve false se já existia (mensagem repetida). */
    fun chatAdd(
        id: String, name: String, mine: Boolean, text: String, time: Long, mid: String,
        fpath: String = "", fname: String = "", fsize: Long = 0L, fmime: String = ""
    ): Boolean {
        if (mid.isNotEmpty()) {
            val seen = readList("chat_mids")
            if (seen.contains(mid)) return false
            seen.add(mid)
            while (seen.size > 200) seen.removeAt(0)
            val ja = JSONArray()
            for (x in seen) ja.put(x)
            p().edit().putString("chat_mids", ja.toString()).apply()
        }
        val old = try {
            JSONArray(p().getString("chat_$id", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        val arr = JSONArray()
        for (i in maxOf(0, old.length() - 299) until old.length()) arr.put(old.get(i))
        arr.put(
            JSONObject().put("m", if (mine) 1 else 0).put("x", text).put("t", time)
                .put("p", fpath).put("n", fname).put("s", fsize).put("y", fmime)
        )
        val idx = try {
            JSONObject(p().getString("chat_idx", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        val o = idx.optJSONObject(id) ?: JSONObject()
        if (!o.has("name") || (name.isNotEmpty() && name != "???")) o.put("name", name)
        o.put("last", preview(text, fname, fmime)).put("mine", mine).put("t", time)
        o.put("unread", if (mine) o.optInt("unread", 0) else o.optInt("unread", 0) + 1)
        idx.put(id, o)
        p().edit().putString("chat_$id", arr.toString()).putString("chat_idx", idx.toString()).apply()
        return true
    }

    fun chatMessages(id: String): List<ChatMsg> {
        val out = ArrayList<ChatMsg>()
        try {
            val a = JSONArray(p().getString("chat_$id", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    ChatMsg(
                        o.optInt("m") == 1, o.optString("x"), o.optLong("t"),
                        o.optString("p"), o.optString("n"), o.optLong("s"), o.optString("y")
                    )
                )
            }
        } catch (e: Exception) {
            // vazio
        }
        return out
    }

    fun chatPeers(): List<ChatPeer> {
        val out = ArrayList<ChatPeer>()
        try {
            val idx = JSONObject(p().getString("chat_idx", "{}") ?: "{}")
            val it = idx.keys()
            while (it.hasNext()) {
                val id = it.next()
                val o = idx.getJSONObject(id)
                out.add(ChatPeer(id, o.optString("name"), o.optString("last"), o.optBoolean("mine"), o.optLong("t"), o.optInt("unread")))
            }
        } catch (e: Exception) {
            // vazio
        }
        return out.sortedByDescending { it.time }
    }

    fun chatUnread(): Int = chatPeers().sumOf { it.unread }

    fun chatRead(id: String) {
        try {
            val idx = JSONObject(p().getString("chat_idx", "{}") ?: "{}")
            val o = idx.optJSONObject(id) ?: return
            if (o.optInt("unread") == 0) return
            o.put("unread", 0)
            p().edit().putString("chat_idx", idx.toString()).apply()
        } catch (e: Exception) {
            // ignora
        }
    }

    fun chatClear(id: String) {
        try {
            val idx = JSONObject(p().getString("chat_idx", "{}") ?: "{}")
            idx.remove(id)
            p().edit().remove("chat_$id").putString("chat_idx", idx.toString()).apply()
        } catch (e: Exception) {
            // ignora
        }
    }

    fun chatClearAll() {
        for (c in chatPeers()) chatClear(c.id)
    }

    fun exported(path: String): String = readMap("exported")[path] ?: ""

    fun setExported(path: String, uri: String) {
        val m = readMap("exported")
        m[path] = uri
        writeMap("exported", m)
    }

    // ------------------------------------------------------------ ajustes
    /** Tema de cor: índice em [Hue.NAMES]. */
    var theme: Int
        get() = p().getInt("theme", 0)
        set(value) {
            p().edit().putInt("theme", value).apply()
        }

    /** Fundo animado do chat: 0 aurora, 1 rede, 2 ondas, 3 linhas. */
    var chatBg: Int
        get() = p().getInt("chat_bg", 0)
        set(value) {
            p().edit().putInt("chat_bg", value).apply()
        }

    /** "auto", "high" ou "eco". */
    var quality: String
        get() = p().getString("quality", "auto") ?: "auto"
        set(value) {
            p().edit().putString("quality", value).apply()
        }

    var dnd: Boolean
        get() = p().getBoolean("dnd", false)
        set(value) {
            p().edit().putBoolean("dnd", value).apply()
        }

    /** Servidor TURN próprio (ex.: global.relay.metered.ca). Vazio = só os públicos. */
    var turnHost: String
        get() = p().getString("turn_host", "") ?: ""
        set(value) {
            p().edit().putString("turn_host", value.trim()).apply()
        }

    var turnUser: String
        get() = p().getString("turn_user", "") ?: ""
        set(value) {
            p().edit().putString("turn_user", value.trim()).apply()
        }

    var turnPass: String
        get() = p().getString("turn_pass", "") ?: ""
        set(value) {
            p().edit().putString("turn_pass", value.trim()).apply()
        }

    var haptic: Boolean
        get() = p().getBoolean("haptic", true)
        set(value) {
            p().edit().putBoolean("haptic", value).apply()
        }

    var keepOn: Boolean
        get() = p().getBoolean("keep_on", true)
        set(value) {
            p().edit().putBoolean("keep_on", value).apply()
        }

    var showStats: Boolean
        get() = p().getBoolean("show_stats", true)
        set(value) {
            p().edit().putBoolean("show_stats", value).apply()
        }

    var autoHide: Boolean
        get() = p().getBoolean("auto_hide", true)
        set(value) {
            p().edit().putBoolean("auto_hide", value).apply()
        }

    /** 0 suave, 1 elástico, 2 geleia. */
    var anim: Int
        get() = p().getInt("anim", 1)
        set(value) {
            p().edit().putInt("anim", value).apply()
        }

    var fx: Boolean
        get() = p().getBoolean("fx", true)
        set(value) {
            p().edit().putBoolean("fx", value).apply()
        }

    var autostart: Boolean
        get() = p().getBoolean("autostart", false)
        set(value) {
            p().edit().putBoolean("autostart", value).apply()
        }

    var favNotify: Boolean
        get() = p().getBoolean("fav_notify", true)
        set(value) {
            p().edit().putBoolean("fav_notify", value).apply()
        }

    var onlineOn: Boolean
        get() = p().getBoolean("online_on", true)
        set(value) {
            p().edit().putBoolean("online_on", value).apply()
        }
}
