package mz.espelho

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

/**
 * Mantém o celular na lista de pessoas e recebe os pedidos de quem quer ver a tela.
 */
class OnlineService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var dir: NtfyListener? = null
    private var inbox: NtfyListener? = null

    private val beat = object : Runnable {
        override fun run() {
            sendHello()
            main.postDelayed(this, 30000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        Online.load(this)
        if (Online.myName.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Online.running) {
            sendHello()
            return START_STICKY
        }
        Online.running = true

        dir = NtfyListener(Online.DIR, "2m") { m, t -> main.post { onHello(m, t) } }
        dir?.start()
        inbox = NtfyListener(Online.inbox(Online.myId), "12h") { m, t -> main.post { onInbox(m, t) } }
        inbox?.start()
        main.post(beat)
        return START_STICKY
    }

    private fun startAsForeground(): Boolean {
        return try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ONLINE, "Espelho Visk", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val stop = PendingIntent.getService(
                this, 3, Intent(this, OnlineService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            val notification = Notification.Builder(this, CHANNEL_ONLINE)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Espelho Visk")
                .setContentText("Online")
                .setContentIntent(open)
                .addAction(0, "Offline", stop)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ONLINE, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ONLINE, notification)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun sendHello() {
        if (Online.myName.isEmpty()) return
        Ntfy.send(
            Online.DIR,
            JSONObject().put("t", "hello").put("id", Online.myId).put("name", Online.myName)
        )
    }

    private fun onHello(m: JSONObject, time: Long) {
        if (Ntfy.ageSeconds(time) > 100) return
        val id = m.optString("id")
        if (m.optString("t") != "hello" || id.isEmpty() || id == Online.myId) return
        val name = m.optString("name").trim().take(24)
        if (name.isEmpty()) return
        val before = Online.people[id]
        val isNew = before == null || System.currentTimeMillis() - before.seen > 100_000
        Online.people[id] = Person(id, name, System.currentTimeMillis())
        if (isNew && Store.favNotify && Store.isFav(id) && !Store.isBlocked(id) && Ntfy.ageSeconds(time) < 35) {
            notifyFav(id, name)
        }
        Online.changed()
    }

    private fun onInbox(m: JSONObject, time: Long) {
        val kind = m.optString("t")
        if (kind != "chat" && kind != "file" && Ntfy.ageSeconds(time) > 60) return
        val from = m.optString("from")
        if (from.isEmpty()) return
        when (m.optString("t")) {
            "req" -> onRequest(from, m.optString("name").trim().take(24))
            "chat", "file" -> onChat(from, m, time)
            "deny", "offer", "byes", "st" -> Online.viewerHandler?.invoke(m)
            "msg" -> if (ShareState.active && from == ShareState.vid) {
                if (!Store.isBlocked(from)) {
                    Online.lastMsg = m.optString("x").trim().take(60)
                    Online.changed()
                }
            } else {
                Online.viewerHandler?.invoke(m)
            }
            "answer", "byev" -> Online.shareHandler?.invoke(m)
        }
    }

    private fun onRequest(from: String, name: String) {
        if (Store.isBlocked(from)) {
            Online.send(from, JSONObject().put("t", "deny"))
            return
        }
        if (Store.dnd) {
            Online.send(from, JSONObject().put("t", "deny").put("why", "dnd"))
            return
        }
        if (ShareState.active || Online.incoming != null) {
            Online.send(from, JSONObject().put("t", "deny").put("why", "busy"))
            return
        }
        val shown = name.ifEmpty { "???" }
        Online.incoming = Request(from, shown)
        notifyRequest(shown)
        Online.changed()
        main.postDelayed({
            val current = Online.incoming
            if (current != null && current.id == from) {
                Online.incoming = null
                getSystemService(NotificationManager::class.java).cancel(NOTIF_REQUEST)
                Online.changed()
            }
        }, 60000)
    }

    private fun safeName(n: String): String =
        n.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifEmpty { "ficheiro" }

    private fun onChat(from: String, m: JSONObject, time: Long) {
        if (Store.isBlocked(from)) return
        val mid = m.optString("mid")
        if (Store.seenMid(mid)) return
        val name = m.optString("name").trim().take(24).ifEmpty { "???" }
        val ts = time * 1000 - Ntfy.skewMs
        if (m.optString("t") == "file") {
            val url = m.optString("url")
            if (url.isEmpty()) return
            val fname = safeName(m.optString("fname"))
            val size = m.optLong("size")
            var mime = m.optString("mime")
            if (mime.isEmpty()) {
                val ext = fname.substringAfterLast('.', "").lowercase()
                mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: ""
            }
            val finalMime = mime
            thread(isDaemon = true) {
                val dir = File(filesDir, "chat")
                dir.mkdirs()
                val dest = File(dir, "${mid}_$fname")
                val ok = Ntfy.download(url, dest)
                main.post {
                    if (ok) {
                        deliver(from, name, "", ts, mid, dest.absolutePath, fname, dest.length(), finalMime)
                    } else {
                        deliver(from, name, "[falha ao receber] $fname", ts, mid, "", "", 0L, "")
                    }
                }
            }
        } else {
            val text = m.optString("x").trim().take(500)
            if (text.isEmpty()) return
            deliver(from, name, text, ts, mid, "", "", 0L, "")
        }
    }

    private fun deliver(
        from: String, name: String, text: String, ts: Long, mid: String,
        fpath: String, fname: String, fsize: Long, fmime: String
    ) {
        if (!Store.chatAdd(from, name, false, text, ts, mid, fpath, fname, fsize, fmime)) return
        val shown = when {
            fname.isEmpty() -> text
            fmime.startsWith("image/") -> "[foto]"
            else -> "[ficheiro] $fname"
        }
        Online.lastChatFrom = from
        Online.lastChatName = name
        Online.lastChatText = shown
        if (!Online.foreground) notifyChat(from, name, shown)
        Online.changed()
    }

    private fun notifyChat(id: String, name: String, text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_MSG, "Mensagens", NotificationManager.IMPORTANCE_HIGH)
            )
            val code = 200 + (id.hashCode() and 0xff)
            val open = PendingIntent.getActivity(
                this, code,
                Intent(this, MainActivity::class.java).putExtra("chat", id)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, CHANNEL_MSG)
                .setSmallIcon(android.R.drawable.ic_menu_send)
                .setContentTitle(name)
                .setContentText(text)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(code, n)
        } catch (ignored: Exception) {
        }
    }

    private fun notifyFav(id: String, name: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_FAV, "Favoritos", NotificationManager.IMPORTANCE_DEFAULT)
            )
            val open = PendingIntent.getActivity(
                this, 4,
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            val notification = Notification.Builder(this, CHANNEL_FAV)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Espelho Visk")
                .setContentText("● $name online")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(100 + (id.hashCode() and 0xff), notification)
        } catch (ignored: Exception) {
        }
    }

    private fun notifyRequest(name: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_REQUEST, "Pedidos", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_REQUEST)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Espelho Visk")
            .setContentText("> $name")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_REQUEST, notification)
    }

    override fun onDestroy() {
        Online.running = false
        main.removeCallbacksAndMessages(null)
        dir?.stop()
        inbox?.stop()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "mz.espelho.ONLINE_STOP"
        const val NOTIF_REQUEST = 2
        private const val CHANNEL_ONLINE = "online"
        private const val CHANNEL_REQUEST = "pedidos"
        private const val CHANNEL_FAV = "favoritos"
        private const val CHANNEL_MSG = "mensagens"
        private const val NOTIF_ONLINE = 3
    }
}
