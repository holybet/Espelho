package mz.espelho

import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Caixa de correio pública (ntfy.sh): só passa a lista de nomes, os pedidos e o SDP.
 * O vídeo nunca passa por aqui, vai direto entre os celulares.
 */
object Ntfy {
    const val HOST = "https://ntfy.sh"

    /** Diferença entre o relógio do servidor e o do celular (ms), medida ao ligar. */
    @Volatile var skewMs = 0L

    fun send(topic: String, message: JSONObject) {
        thread(isDaemon = true, name = "ntfy-enviar") {
            for (attempt in 0 until 3) {
                try {
                    val c = URL("$HOST/$topic").openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.doOutput = true
                    c.connectTimeout = 15000
                    c.readTimeout = 15000
                    c.outputStream.use { it.write(message.toString().toByteArray(Charsets.UTF_8)) }
                    val ok = c.responseCode in 200..299
                    c.disconnect()
                    if (ok) return@thread
                } catch (ignored: Exception) {
                    // tenta de novo
                }
                try {
                    Thread.sleep(1500)
                } catch (e: InterruptedException) {
                    return@thread
                }
            }
        }
    }

    /** Envia um ficheiro (até ~15 MB) como anexo; [meta] viaja em base64 no texto da mensagem. */
    fun putFile(topic: String, file: File, fname: String, mime: String, meta: JSONObject): Boolean {
        val msg = Base64.encodeToString(meta.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
        for (attempt in 0 until 2) {
            try {
                val c = URL("$HOST/$topic").openConnection() as HttpURLConnection
                c.requestMethod = "PUT"
                c.doOutput = true
                c.connectTimeout = 20000
                c.readTimeout = 90000
                c.setFixedLengthStreamingMode(file.length())
                c.setRequestProperty("Filename", fname)
                c.setRequestProperty("X-Message", msg)
                c.setRequestProperty("Content-Type", mime.ifEmpty { "application/octet-stream" })
                file.inputStream().use { i -> c.outputStream.use { o -> i.copyTo(o) } }
                val ok = c.responseCode in 200..299
                c.disconnect()
                if (ok) return true
            } catch (ignored: Exception) {
                // tenta de novo
            }
        }
        return false
    }

    fun download(url: String, dest: File): Boolean {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 20000
            c.readTimeout = 90000
            if (c.responseCode !in 200..299) return false
            c.inputStream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            c.disconnect()
            return dest.length() > 0
        } catch (e: Exception) {
            dest.delete()
            return false
        }
    }

    /** Idade, em segundos, de uma mensagem com a hora [serverTime] do servidor. */
    fun ageSeconds(serverTime: Long): Long =
        (System.currentTimeMillis() + skewMs) / 1000 - serverTime
}

/** Escuta um tópico e volta a ligar sozinho se a ligação cair. */
class NtfyListener(
    private val topic: String,
    private val since: String,
    private val onMessage: (JSONObject, Long) -> Unit
) {
    @Volatile private var open = true
    @Volatile private var conn: HttpURLConnection? = null

    fun start() {
        thread(isDaemon = true, name = "ntfy-ouvir-$topic") {
            var lastId: String? = null
            while (open) {
                try {
                    val from = lastId ?: since
                    val c = URL("${Ntfy.HOST}/$topic/json?since=$from").openConnection() as HttpURLConnection
                    conn = c
                    c.connectTimeout = 15000
                    c.readTimeout = 120000
                    c.setRequestProperty("Accept-Encoding", "identity")
                    c.inputStream.bufferedReader().use { reader ->
                        while (open) {
                            val line = reader.readLine() ?: break
                            if (line.isBlank()) continue
                            try {
                                val event = JSONObject(line)
                                val time = event.optLong("time", 0L)
                                when (event.optString("event")) {
                                    "open" -> if (time > 0) {
                                        Ntfy.skewMs = time * 1000 - System.currentTimeMillis()
                                    }
                                    "message" -> {
                                        val id = event.optString("id", "")
                                        if (id.isNotEmpty()) lastId = id
                                        val att = event.optJSONObject("attachment")
                                        val text = event.optString("message")
                                        val obj = if (att != null) {
                                            val o = try {
                                                JSONObject(String(Base64.decode(text, Base64.NO_WRAP or Base64.URL_SAFE), Charsets.UTF_8))
                                            } catch (e: Exception) {
                                                JSONObject()
                                            }
                                            o.put("t", "file").put("url", att.optString("url"))
                                                .put("fname", att.optString("name")).put("size", att.optLong("size"))
                                                .put("mime", att.optString("type"))
                                        } else {
                                            JSONObject(text)
                                        }
                                        onMessage(obj, time)
                                    }
                                }
                            } catch (ignored: Exception) {
                                // mensagem inválida: ignora
                            }
                        }
                    }
                } catch (ignored: Exception) {
                    // ligação caiu: volta a tentar
                }
                if (open) {
                    try {
                        Thread.sleep(2000)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            }
        }
    }

    fun stop() {
        open = false
        try {
            conn?.disconnect()
        } catch (ignored: Exception) {
        }
    }
}
