plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "mz.espelho"
    compileSdk = 35

    defaultConfig {
        applicationId = "mz.espelho.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "2.4"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    signingConfigs {
        getByName("debug") {
            // chave fixa: as próximas versões instalam por cima desta
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            // alguns telemóveis recusam instalar APKs marcados como "depuração"
            isDebuggable = false
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("io.getstream:stream-webrtc-android:1.3.9")
}
