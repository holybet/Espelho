package mz.espelho

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import org.json.JSONObject
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.RtpSender
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack

/** Estado visível para o ecrã principal. */
object ShareState {
    @Volatile var active = false
    @Volatile var name = ""
    @Volatile var status = ""
    @Volatile var since = 0L
    @Volatile var vid = ""
    @Volatile var paused = false
    @Volatile var onChange: (() -> Unit)? = null

    fun set(newStatus: String) {
        status = newStatus
        onChange?.invoke()
    }
}

/**
 * Serviço em primeiro plano que captura a tela e a envia por WebRTC a quem pediu e foi autorizado.
 * O Android exige que ele mostre uma notificação enquanto a tela está a ser partilhada.
 */
class ShareService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var capturer: ScreenCapturerAndroid? = null
    private var helper: SurfaceTextureHelper? = null
    private var source: VideoSource? = null
    private var track: VideoTrack? = null
    private var pc: PeerConnection? = null
    private var sender: RtpSender? = null
    private var vid = ""
    private var vname = ""
    private var connected = false
    private var offerSent = false
    private var answered = false
    private var closed = false
    private var failed = false
    private var fps = 15
    private var obs: PcObserver? = null
    private var connectedAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_PAUSE) {
            togglePause()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (ShareState.active) return START_NOT_STICKY

        val data = readProjectionData(intent)
        val viewerId = intent?.getStringExtra(EXTRA_VID).orEmpty()
        val viewerName = intent?.getStringExtra(EXTRA_VNAME).orEmpty()
        if (data == null || viewerId.isEmpty()) {
            failed = true
            ShareState.set("Falha ao iniciar.")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            begin(data, viewerId, viewerName)
        } catch (e: Throwable) {
            failed = true
            ShareState.set("Não foi possível iniciar a partilha (${e.javaClass.simpleName}).")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readProjectionData(intent: Intent?): Intent? {
        if (intent == null) return null
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra<Intent>(EXTRA_DATA)
        }
    }

    @Suppress("DEPRECATION")
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Partilha", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentTitle("Espelho Visk")
            .setContentText("Partilha ativa")
            .setContentIntent(open)
            .addAction(0, "Parar", stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun begin(data: Intent, viewerId: String, viewerName: String) {
        Rtc.init(this)
        vid = viewerId
        vname = viewerName.ifEmpty { "alguém" }
        ShareState.name = vname
        ShareState.vid = vid
        ShareState.paused = false
        ShareState.active = true
        ShareState.set("A ligar a $vname…")

        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val side = when (Store.quality) { "high" -> 1920f; "eco" -> 854f; else -> 1280f }
        fps = when (Store.quality) { "high" -> 24; "eco" -> 12; else -> 15 }
        val scale = minOf(1f, side / maxOf(dm.widthPixels, dm.heightPixels).toFloat())
        val w = (dm.widthPixels * scale).toInt() and 1.inv()
        val h = (dm.heightPixels * scale).toInt() and 1.inv()

        val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        })
        val texHelper = SurfaceTextureHelper.create("espelho-captura", Rtc.eglBase.eglBaseContext)
        val src = Rtc.factory.createVideoSource(true)
        cap.initialize(texHelper, applicationContext, src.capturerObserver)
        capturer = cap
        helper = texHelper
        source = src
        cap.startCapture(w, h, fps)
        track = Rtc.factory.createVideoTrack("espelho-video", src)

        Online.shareHandler = { m -> onSignal(m) }
        startPeer()
        // se a outra pessoa não chegar a ligar-se, termina sozinho
        main.postDelayed({
            if (!connected && !closed) {
                failed = true
                ShareState.set("Sem ligação (${obs?.summary() ?: "-"}).")
                stopSelf()
            }
        }, 90000)
    }

    private fun togglePause() {
        if (!ShareState.active || closed) return
        val now = !ShareState.paused
        ShareState.paused = now
        try {
            track?.setEnabled(!now)
        } catch (ignored: Exception) {
        }
        Online.send(vid, JSONObject().put("t", "st").put("p", if (now) 1 else 0))
        ShareState.set(if (now) "$vname // pausado" else "$vname // ao vivo")
    }

    private fun onSignal(m: JSONObject) {
        if (closed || m.optString("from") != vid) return
        when (m.optString("t")) {
            "answer" -> {
                try {
                    applyAnswer(unpack(m.optString("d")))
                } catch (e: Exception) {
                    ShareState.set("Erro ao ligar. Peça para a outra pessoa tentar de novo.")
                }
            }
            "byev" -> stopSelf()
        }
    }

    private fun startPeer() {
        val observer = object : PcObserver() {
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {
                if (newState == PeerConnection.IceGatheringState.COMPLETE) {
                    main.post { sendOffer() }
                }
            }

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                main.post { onIceState(newState) }
            }
        }
        obs = observer
        val peer = Rtc.factory.createPeerConnection(Rtc.rtcConfig(), observer)
        if (peer == null) {
            ShareState.set("Erro ao preparar a ligação.")
            return
        }
        pc = peer
        sender = peer.addTrack(track, listOf("espelho"))
        peer.createOffer(object : SdpObs() {
            override fun onCreateSuccess(description: SessionDescription?) {
                peer.setLocalDescription(SdpObs(), description)
                main.postDelayed({ sendOffer() }, 9000)
            }

            override fun onCreateFailure(error: String?) {
                main.post { ShareState.set("Erro ao preparar a ligação.") }
            }
        }, MediaConstraints())
    }

    private fun sendOffer() {
        if (closed || offerSent) return
        val sdp = pc?.localDescription?.description ?: return
        offerSent = true
        Online.send(vid, JSONObject().put("t", "offer").put("d", pack(sdp)))
    }

    private fun applyAnswer(sdp: String) {
        val peer = pc ?: return
        if (answered || sdp.isEmpty()) return
        answered = true
        peer.setRemoteDescription(object : SdpObs() {
            override fun onSetSuccess() {
                main.post { limitBitrate() }
            }

            override fun onSetFailure(error: String?) {
                main.post { ShareState.set("Erro ao ligar. Peça para a outra pessoa tentar de novo.") }
            }
        }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
    }

    private fun onIceState(state: PeerConnection.IceConnectionState?) {
        if (closed) return
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED,
            PeerConnection.IceConnectionState.COMPLETED -> {
                if (!connected) {
                    connectedAt = System.currentTimeMillis()
                    ShareState.since = connectedAt
                }
                connected = true
                ShareState.set("$vname // ao vivo")
            }
            PeerConnection.IceConnectionState.DISCONNECTED -> {
                ShareState.set("Ligação instável…")
            }
            PeerConnection.IceConnectionState.FAILED,
            PeerConnection.IceConnectionState.CLOSED -> {
                if (!connected) {
                    failed = true
                    ShareState.set("Sem ligação (${obs?.summary() ?: "-"}).")
                }
                stopSelf()
            }
            else -> {}
        }
    }

    private fun limitBitrate() {
        try {
            val snd = sender ?: return
            val params = snd.parameters
            for (e in params.encodings) {
                e.maxBitrateBps = when (Store.quality) { "high" -> 3_000_000; "eco" -> 800_000; else -> 1_500_000 }
            }
            snd.setParameters(params)
        } catch (ignored: Exception) {
        }
    }

    override fun onDestroy() {
        closed = true
        main.removeCallbacksAndMessages(null)
        if (connectedAt > 0L) {
            try {
                Store.addHistory(Entry(vid, vname, "share", connectedAt, System.currentTimeMillis() - connectedAt))
            } catch (ignored: Exception) {
            }
        }
        ShareState.since = 0L
        ShareState.paused = false
        ShareState.vid = ""
        if (vid.isNotEmpty()) Online.send(vid, JSONObject().put("t", "byes"))
        Online.shareHandler = null
        try {
            pc?.close()
            pc?.dispose()
        } catch (ignored: Exception) {
        }
        pc = null
        try {
            capturer?.stopCapture()
        } catch (ignored: Exception) {
        }
        try {
            capturer?.dispose()
        } catch (ignored: Exception) {
        }
        try {
            track?.dispose()
            source?.dispose()
            helper?.dispose()
        } catch (ignored: Exception) {
        }
        ShareState.active = false
        ShareState.name = ""
        if (!failed) ShareState.status = ""
        ShareState.onChange?.invoke()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "mz.espelho.STOP"
        const val ACTION_PAUSE = "mz.espelho.PAUSE"
        const val EXTRA_DATA = "data"
        const val EXTRA_VID = "vid"
        const val EXTRA_VNAME = "vname"
        private const val CHANNEL = "partilha"
        private const val NOTIF_ID = 1
    }
}
