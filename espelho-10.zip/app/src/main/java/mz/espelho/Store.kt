package mz.espelho

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Uma sessão registada no histórico. [dir] é "view" (viu) ou "share" (partilhou). */
data class Entry(val id: String, val name: String, val dir: String, val start: Long, val dur: Long)

/** Dados guardados no celular: favoritos, bloqueados, histórico e ajustes. */
object Store {
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs == null) {
            prefs = ctx.applicationContext.getSharedPreferences("espelho", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = prefs ?: throw IllegalStateException("Store não iniciado")

    private fun readMap(key: String): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        try {
            val o = JSONObject(p().getString(key, "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                out[k] = o.optString(k)
            }
        } catch (e: Exception) {
            // dados inválidos: começa vazio
        }
        return out
    }

    private fun writeMap(key: String, map: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        p().edit().putString(key, o.toString()).apply()
    }

    // ------------------------------------------------------------ favoritos
    fun favorites(): LinkedHashMap<String, String> = readMap("fav")

    fun isFav(id: String): Boolean = readMap("fav").containsKey(id)

    fun toggleFav(id: String, name: String) {
        val m = readMap("fav")
        if (m.containsKey(id)) m.remove(id) else m[id] = name
        writeMap("fav", m)
    }

    // ------------------------------------------------------------ bloqueados
    fun blocked(): LinkedHashMap<String, String> = readMap("blocked")

    fun isBlocked(id: String): Boolean = readMap("blocked").containsKey(id)

    fun block(id: String, name: String) {
        val m = readMap("blocked")
        m[id] = name
        writeMap("blocked", m)
    }

    fun unblock(id: String) {
        val m = readMap("blocked")
        m.remove(id)
        writeMap("blocked", m)
    }

    // ------------------------------------------------------------ histórico
    fun history(): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            val a = JSONArray(p().getString("hist", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.optString("id"), o.optString("name"), o.optString("dir"), o.optLong("start"), o.optLong("dur")))
            }
        } catch (e: Exception) {
            // dados inválidos: lista vazia
        }
        return out
    }

    fun addHistory(e: Entry) {
        val a = JSONArray()
        a.put(JSONObject().put("id", e.id).put("name", e.name).put("dir", e.dir).put("start", e.start).put("dur", e.dur))
        val old = history()
        for (i in 0 until minOf(old.size, 59)) {
            val x = old[i]
            a.put(JSONObject().put("id", x.id).put("name", x.name).put("dir", x.dir).put("start", x.start).put("dur", x.dur))
        }
        p().edit().putString("hist", a.toString()).apply()
    }

    fun clearHistory() {
        p().edit().putString("hist", "[]").apply()
    }

    // ------------------------------------------------------------ ajustes
    /** "auto", "high" ou "eco". */
    var quality: String
        get() = p().getString("quality", "auto") ?: "auto"
        set(value) {
            p().edit().putString("quality", value).apply()
        }

    var dnd: Boolean
        get() = p().getBoolean("dnd", false)
        set(value) {
            p().edit().putBoolean("dnd", value).apply()
        }

    /** Servidor TURN próprio (ex.: global.relay.metered.ca). Vazio = só os públicos. */
    var turnHost: String
        get() = p().getString("turn_host", "") ?: ""
        set(value) {
            p().edit().putString("turn_host", value.trim()).apply()
        }

    var turnUser: String
        get() = p().getString("turn_user", "") ?: ""
        set(value) {
            p().edit().putString("turn_user", value.trim()).apply()
        }

    var turnPass: String
        get() = p().getString("turn_pass", "") ?: ""
        set(value) {
            p().edit().putString("turn_pass", value.trim()).apply()
        }

    var haptic: Boolean
        get() = p().getBoolean("haptic", true)
        set(value) {
            p().edit().putBoolean("haptic", value).apply()
        }

    var keepOn: Boolean
        get() = p().getBoolean("keep_on", true)
        set(value) {
            p().edit().putBoolean("keep_on", value).apply()
        }

    var showStats: Boolean
        get() = p().getBoolean("show_stats", true)
        set(value) {
            p().edit().putBoolean("show_stats", value).apply()
        }

    var autoHide: Boolean
        get() = p().getBoolean("auto_hide", true)
        set(value) {
            p().edit().putBoolean("auto_hide", value).apply()
        }

    /** 0 suave, 1 elástico, 2 geleia. */
    var anim: Int
        get() = p().getInt("anim", 1)
        set(value) {
            p().edit().putInt("anim", value).apply()
        }

    var fx: Boolean
        get() = p().getBoolean("fx", true)
        set(value) {
            p().edit().putBoolean("fx", value).apply()
        }

    var autostart: Boolean
        get() = p().getBoolean("autostart", false)
        set(value) {
            p().edit().putBoolean("autostart", value).apply()
        }

    var favNotify: Boolean
        get() = p().getBoolean("fav_notify", true)
        set(value) {
            p().edit().putBoolean("fav_notify", value).apply()
        }

    var onlineOn: Boolean
        get() = p().getBoolean("online_on", true)
        set(value) {
            p().edit().putBoolean("online_on", value).apply()
        }
}
