package mz.espelho

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.RTCStatsCollectorCallback
import org.webrtc.RtpTransceiver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

/**
 * Quem vê: envia o pedido à pessoa escolhida; se ela permitir, recebe a oferta,
 * responde e mostra o vídeo no [renderer]. O [renderer] já tem de estar inicializado.
 */
class ViewerSession(
    private val target: Person,
    private val renderer: SurfaceViewRenderer,
    private val onStatus: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var pc: PeerConnection? = null
    private var remoteTrack: VideoTrack? = null
    private var closed = false
    private var gotOffer = false
    private var answerSent = false
    private var connectedOnce = false
    private var obs: PcObserver? = null
    @Volatile var connectedAt = 0L
    var onMessage: ((String) -> Unit)? = null
    private val startedAt = System.currentTimeMillis()

    private val handler: (JSONObject) -> Unit = { m -> onSignal(m) }

    fun start() {
        onStatus("À espera que ${target.name} aceite…")
        Online.viewerHandler = handler
        Online.send(target.id, JSONObject().put("t", "req"))
        main.postDelayed({
            if (!closed && !gotOffer) onStatus("${target.name} não respondeu.")
        }, 75000)
    }

    private fun onSignal(m: JSONObject) {
        if (closed || m.optString("from") != target.id) return
        when (m.optString("t")) {
            "deny" -> {
                if (!gotOffer) {
                    onStatus(
                        when (m.optString("why")) {
                            "busy" -> "${target.name} está ocupado(a)."
                            "dnd" -> "${target.name} não está a aceitar pedidos agora."
                            else -> "${target.name} recusou."
                        }
                    )
                }
            }
            "offer" -> if (!gotOffer) {
                try {
                    handleOffer(unpack(m.optString("d")))
                } catch (e: Exception) {
                    onStatus("Erro: dados inválidos. Tente de novo.")
                }
            }
            "byes" -> onStatus("A partilha terminou.")
            "msg" -> onMessage?.invoke(m.optString("x").trim().take(60))
            "st" -> onStatus(if (m.optInt("p") == 1) "// transmissão pausada" else "")
        }
    }

    private fun handleOffer(offerSdp: String) {
        if (offerSdp.isEmpty()) return
        gotOffer = true
        onStatus("A estabelecer a ligação…")

        val observer = object : PcObserver() {
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {
                if (newState == PeerConnection.IceGatheringState.COMPLETE) {
                    main.post { sendAnswer() }
                }
            }

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                main.post { onIceState(newState) }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val received = transceiver?.receiver?.track()
                if (received is VideoTrack) {
                    main.post { attach(received) }
                }
            }
        }
        obs = observer
        val peer = Rtc.factory.createPeerConnection(Rtc.rtcConfig(), observer)
        if (peer == null) {
            onStatus("Erro ao iniciar a ligação.")
            return
        }
        pc = peer
        peer.setRemoteDescription(object : SdpObs() {
            override fun onSetSuccess() {
                peer.createAnswer(object : SdpObs() {
                    override fun onCreateSuccess(description: SessionDescription?) {
                        peer.setLocalDescription(SdpObs(), description)
                        main.postDelayed({ sendAnswer() }, 9000)
                    }

                    override fun onCreateFailure(error: String?) {
                        main.post { onStatus("Erro ao responder à ligação.") }
                    }
                }, MediaConstraints())
            }

            override fun onSetFailure(error: String?) {
                main.post { onStatus("Erro ao ligar. Tente de novo.") }
            }
        }, SessionDescription(SessionDescription.Type.OFFER, offerSdp))
    }

    private fun sendAnswer() {
        if (closed || answerSent) return
        val sdp = pc?.localDescription?.description ?: return
        answerSent = true
        Online.send(target.id, JSONObject().put("t", "answer").put("d", pack(sdp)))
    }

    private fun attach(video: VideoTrack) {
        if (closed) return
        remoteTrack = video
        video.addSink(renderer)
    }

    private fun onIceState(state: PeerConnection.IceConnectionState?) {
        if (closed) return
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED,
            PeerConnection.IceConnectionState.COMPLETED -> {
                if (!connectedOnce) connectedAt = System.currentTimeMillis()
                connectedOnce = true
                onStatus("")
            }
            PeerConnection.IceConnectionState.DISCONNECTED -> onStatus("Ligação instável…")
            PeerConnection.IceConnectionState.FAILED,
            PeerConnection.IceConnectionState.CLOSED -> {
                if (connectedOnce) {
                    onStatus("A partilha terminou.")
                } else {
                    onStatus("Sem ligação (${obs?.summary() ?: "-"}). A rede pode estar a bloquear.")
                }
            }
            else -> {}
        }
    }

    private var lastBytes = 0.0
    private var lastAt = 0L

    private fun num(x: Any?): Double = (x as? Number)?.toDouble() ?: 0.0

    fun sendMsg(text: String) {
        if (!closed) Online.send(target.id, JSONObject().put("t", "msg").put("x", text))
    }

    /** Resolução, fps e débito atuais da transmissão recebida. */
    fun stats(cb: (String) -> Unit) {
        val peer = pc ?: return
        try {
            peer.getStats(RTCStatsCollectorCallback { report ->
                for (s in report.statsMap.values) {
                    if (s.type != "inbound-rtp") continue
                    val m = s.members
                    val w = num(m["frameWidth"])
                    if (w <= 0.0) continue
                    val h = num(m["frameHeight"])
                    val fps = num(m["framesPerSecond"])
                    val bytes = num(m["bytesReceived"])
                    val now = System.currentTimeMillis()
                    var mbps = 0.0
                    if (lastAt > 0L && now > lastAt) mbps = (bytes - lastBytes) * 8.0 / ((now - lastAt) / 1000.0) / 1_000_000.0
                    lastBytes = bytes
                    lastAt = now
                    cb("%dx%d · %d fps · %.1f Mbps".format(w.toInt(), h.toInt(), fps.toInt(), mbps))
                    break
                }
            })
        } catch (ignored: Throwable) {
        }
    }

    fun close() {
        if (closed) return
        closed = true
        main.removeCallbacksAndMessages(null)
        if (connectedAt > 0L) {
            try {
                Store.addHistory(Entry(target.id, target.name, "view", connectedAt, System.currentTimeMillis() - connectedAt))
            } catch (ignored: Exception) {
            }
        }
        Online.send(target.id, JSONObject().put("t", "byev"))
        if (Online.viewerHandler === handler) Online.viewerHandler = null
        try {
            remoteTrack?.removeSink(renderer)
        } catch (ignored: Exception) {
        }
        try {
            pc?.close()
            pc?.dispose()
        } catch (ignored: Exception) {
        }
        pc = null
        try {
            renderer.release()
        } catch (ignored: Exception) {
        }
    }
}
