package mz.espelho

import android.content.Context
import android.util.Base64
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/** WebRTC partilhado pela app (quem partilha e quem vê). */
object Rtc {
    private var ready = false

    lateinit var eglBase: EglBase
        private set
    lateinit var factory: PeerConnectionFactory
        private set

    @Synchronized
    fun init(context: Context) {
        if (ready) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                .createInitializationOptions()
        )
        eglBase = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        ready = true
    }

    /** STUN do Google + relay TURN público (usado quando a ligação direta não é possível). */
    fun rtcConfig(): PeerConnection.RTCConfiguration {
        val servers = listOf(
            PeerConnection.IceServer.builder(
                listOf(
                    "stun:stun.l.google.com:19302",
                    "stun:stun1.l.google.com:19302",
                    "stun:stun.cloudflare.com:3478"
                )
            ).createIceServer(),
            PeerConnection.IceServer.builder(
                listOf(
                    "turn:staticauth.openrelay.metered.ca:80",
                    "turn:staticauth.openrelay.metered.ca:443",
                    "turns:staticauth.openrelay.metered.ca:443?transport=tcp"
                )
            ).setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
            PeerConnection.IceServer.builder(
                listOf(
                    "turn:openrelay.metered.ca:80",
                    "turn:openrelay.metered.ca:443",
                    "turn:openrelay.metered.ca:443?transport=tcp"
                )
            ).setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
            PeerConnection.IceServer.builder(
                listOf(
                    "turn:turn.anyfirewall.com:443?transport=tcp"
                )
            ).setUsername("webrtc").setPassword("webrtc").createIceServer()
        )
        val own = ArrayList<PeerConnection.IceServer>(servers)
        try {
            val host = Store.turnHost
            if (host.isNotEmpty() && Store.turnUser.isNotEmpty()) {
                own.add(
                    0,
                    PeerConnection.IceServer.builder(
                        listOf(
                            "turn:$host:80",
                            "turn:$host:80?transport=tcp",
                            "turn:$host:443",
                            "turns:$host:443?transport=tcp"
                        )
                    ).setUsername(Store.turnUser).setPassword(Store.turnPass).createIceServer()
                )
            }
        } catch (e: Exception) {
            // sem servidor próprio
        }
        val config = PeerConnection.RTCConfiguration(own)
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        return config
    }
}

/** Comprime o SDP (gzip + base64) para caber numa mensagem curta. */
fun pack(text: String): String {
    val out = ByteArrayOutputStream()
    GZIPOutputStream(out).use { it.write(text.toByteArray(Charsets.UTF_8)) }
    return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP or Base64.URL_SAFE)
}

fun unpack(data: String): String {
    val raw = Base64.decode(data, Base64.NO_WRAP or Base64.URL_SAFE)
    return GZIPInputStream(ByteArrayInputStream(raw)).use { String(it.readBytes(), Charsets.UTF_8) }
}

/** Observador do PeerConnection com tudo vazio, para só sobrescrever o que interessa. */
open class PcObserver : PeerConnection.Observer {
    override fun onSignalingChange(newState: PeerConnection.SignalingState?) {}
    override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {}
    override fun onIceConnectionReceivingChange(receiving: Boolean) {}
    override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}
    @Volatile var host = 0
    @Volatile var srflx = 0
    @Volatile var relay = 0

    /** Conta os candidatos locais por tipo, para saber se o relay (TURN) respondeu. */
    override fun onIceCandidate(candidate: IceCandidate?) {
        val s = candidate?.sdp ?: return
        when {
            s.contains(" typ relay") -> relay++
            s.contains(" typ srflx") -> srflx++
            s.contains(" typ host") -> host++
        }
    }

    fun summary(): String = "h$host s$srflx r$relay"
    override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
    override fun onAddStream(stream: MediaStream?) {}
    override fun onRemoveStream(stream: MediaStream?) {}
    override fun onDataChannel(dataChannel: DataChannel?) {}
    override fun onRenegotiationNeeded() {}
}

open class SdpObs : SdpObserver {
    override fun onCreateSuccess(description: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}
