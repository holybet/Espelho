package mz.espelho

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Volta a ficar online quando o telemóvel liga, se a pessoa ativou essa opção. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            Online.load(context)
            if (Store.autostart && Store.onlineOn && Online.myName.isNotEmpty()) {
                context.startForegroundService(Intent(context, OnlineService::class.java))
            }
        } catch (e: Exception) {
            // não foi possível arrancar agora
        }
    }
}
