package mz.espelho

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: FrameLayout
    private lateinit var pages: Array<ScrollView>
    private lateinit var boxes: Array<LinearLayout>
    private lateinit var tabBar: TabBar

    private lateinit var onboard: FrameLayout
    private lateinit var nameInput: EditText
    private lateinit var onboardTitle: TextView
    private lateinit var onboardCancel: TextView

    private lateinit var requestLayer: FrameLayout
    private lateinit var reqAvatarBox: FrameLayout
    private lateinit var reqName: TextView

    private lateinit var shareLayer: FrameLayout
    private lateinit var shareWith: TextView
    private lateinit var shareStatus: TextView
    private lateinit var shareTime: TextView

    private lateinit var viewerLayer: FrameLayout
    private lateinit var viewerHost: FrameLayout
    private lateinit var viewerTitle: TextView
    private lateinit var viewerTime: TextView
    private lateinit var viewerStatus: TextView
    private lateinit var viewerControls: FrameLayout

    private lateinit var notice: TextView
    private lateinit var searchInput: EditText
    private lateinit var peopleList: LinearLayout
    private lateinit var peopleCount: TextView

    private var statusLine: TextView? = null
    private var statOnline: TextView? = null
    private var statSessions: TextView? = null
    private var statMinutes: TextView? = null

    private var tab = 0
    private var viewer: ViewerSession? = null
    private var editingName = false
    private var pendingAllow: Request? = null
    private var peopleSig = "\u0000"
    private var tickCount = 0
    private var controlsShown = true
    private var lastReqId = ""

    private val ticker = Handler(Looper.getMainLooper())
    private val noticeHider = Runnable { notice.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            tickCount++
            val now = System.currentTimeMillis()
            if (ShareState.active) {
                val since = ShareState.since
                shareTime.text = if (since > 0L) formatDuration(now - since) else "--:--"
            }
            viewer?.let {
                viewerTime.text = if (it.connectedAt > 0L) formatDuration(now - it.connectedAt) else "--:--"
            }
            refreshStatus()
            if (tickCount % 5 == 0 && tab == 1) renderPeople(false)
            ticker.postDelayed(this, 1000)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        Online.load(this)
        window.statusBarColor = Palette.BG
        window.navigationBarColor = Palette.BG
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        renderTab(0, true)
    }

    override fun onResume() {
        super.onResume()
        val changed = { runOnUiThread { refresh() } }
        ShareState.onChange = changed
        Online.onChange = changed
        startOnline()
        ticker.post(tick)
        refresh()
    }

    override fun onPause() {
        ShareState.onChange = null
        Online.onChange = null
        ticker.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        viewer?.close()
        viewer = null
        ticker.removeCallbacks(noticeHider)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            viewer != null -> closeViewer()
            editingName && Online.myName.isNotEmpty() -> {
                editingName = false
                hideKeyboard()
                refresh()
            }
            tab != 0 -> showTab(0)
            else -> super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------- online e nome

    private fun startOnline() {
        if (Online.myName.isEmpty() || !Store.onlineOn) return
        try {
            startForegroundService(Intent(this, OnlineService::class.java))
        } catch (e: Exception) {
            notice("Falha ao ficar online (${e.javaClass.simpleName}).")
        }
    }

    private fun stopOnline() {
        try {
            stopService(Intent(this, OnlineService::class.java))
        } catch (ignored: Exception) {
        }
        Online.people.clear()
        peopleSig = "\u0000"
    }

    private fun saveName() {
        val name = nameInput.text.toString().trim()
        if (name.isEmpty()) {
            notice("> nome vazio")
            return
        }
        hideKeyboard()
        Online.saveName(this, name)
        editingName = false
        startOnline()
        renderTab(tab, true)
        refresh()
    }

    // ---------------------------------------------------------------- pedidos recebidos

    private fun allow() {
        val request = Online.incoming ?: return
        pendingAllow = request
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    private fun deny() {
        val request = Online.incoming ?: return
        Online.send(request.id, JSONObject().put("t", "deny"))
        clearIncoming()
    }

    private fun blockRequester() {
        val request = Online.incoming ?: return
        Store.block(request.id, request.name)
        Online.send(request.id, JSONObject().put("t", "deny"))
        clearIncoming()
    }

    private fun clearIncoming() {
        Online.incoming = null
        getSystemService(NotificationManager::class.java).cancel(OnlineService.NOTIF_REQUEST)
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        val request = pendingAllow
        pendingAllow = null
        if (request == null) return
        if (resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ShareService::class.java)
                .putExtra(ShareService.EXTRA_DATA, data)
                .putExtra(ShareService.EXTRA_VID, request.id)
                .putExtra(ShareService.EXTRA_VNAME, request.name)
            ShareState.status = ""
            startForegroundService(intent)
            clearIncoming()
        } else {
            Online.send(request.id, JSONObject().put("t", "deny"))
            clearIncoming()
        }
    }

    private fun stopShare() {
        stopService(Intent(this, ShareService::class.java))
    }

    // ---------------------------------------------------------------- ver a tela de alguém

    private fun connectTo(person: Person) {
        try {
            Rtc.init(this)
        } catch (e: Throwable) {
            notice("Sem suporte de vídeo (${e.javaClass.simpleName}).")
            return
        }
        val renderer = SurfaceViewRenderer(this)
        renderer.init(Rtc.eglBase.eglBaseContext, null)
        renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        viewerHost.removeAllViews()
        viewerHost.addView(renderer, FrameLayout.LayoutParams(match, match))
        viewerTitle.text = "> ${person.name}"
        viewerTime.text = "--:--"
        setViewerStatus("A pedir ligação…")
        viewerLayer.visibility = View.VISIBLE
        viewerLayer.alpha = 0f
        viewerLayer.animate().alpha(1f).setDuration(300).start()
        viewerControls.alpha = 1f
        controlsShown = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val session = ViewerSession(person, renderer) { message -> runOnUiThread { setViewerStatus(message) } }
        viewer = session
        session.start()
    }

    private fun closeViewer() {
        viewer?.close()
        viewer = null
        viewerHost.removeAllViews()
        viewerLayer.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        refresh()
        if (tab == 0 || tab == 2) renderTab(tab, false)
    }

    private fun setViewerStatus(message: String) {
        viewerStatus.text = message
        viewerStatus.visibility = if (message.isEmpty()) View.GONE else View.VISIBLE
        if (message.isNotEmpty() && !controlsShown) toggleControls()
    }

    private fun toggleControls() {
        controlsShown = !controlsShown
        viewerControls.animate().alpha(if (controlsShown) 1f else 0f).setDuration(260).start()
    }

    // ---------------------------------------------------------------- construção da interface

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Palette.BG)
        root.addView(FxBackground(this), FrameLayout.LayoutParams(match, match))

        boxes = Array(4) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(18), dp(20), dp(18), dp(112))
            box
        }
        pages = Array(4) { i ->
            val page = ScrollView(this)
            page.isVerticalScrollBarEnabled = false
            page.overScrollMode = View.OVER_SCROLL_NEVER
            page.isFillViewport = false
            page.addView(boxes[i], FrameLayout.LayoutParams(match, wrap))
            page.visibility = if (i == 0) View.VISIBLE else View.GONE
            root.addView(page, FrameLayout.LayoutParams(match, match))
            page
        }
        buildPeopleShell()

        tabBar = TabBar(this, listOf("INÍCIO", "PESSOAS", "LOG", "CONFIG")) { i -> showTab(i) }
        val tabLp = FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM)
        tabLp.setMargins(dp(16), 0, dp(16), dp(14))
        root.addView(tabBar, tabLp)

        buildOnboard()
        buildRequest()
        buildShare()
        buildNotice()
        buildViewer()
        setContentView(root)
    }

    private fun buildNotice() {
        notice = tv("", 12f, Palette.CREAM, true)
        notice.setPadding(dp(16), dp(11), dp(16), dp(11))
        notice.background = glass(18f, hud = true, strength = 1.5f)
        notice.visibility = View.GONE
        val p = FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        p.topMargin = dp(46)
        root.addView(notice, p)
    }

    private fun buildOnboard() {
        onboard = FrameLayout(this)
        onboard.setBackgroundColor(Color.argb(232, 4, 4, 4))
        onboard.isClickable = true
        onboard.visibility = View.GONE
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(28), dp(28), dp(28))
        col.addView(LogoView(this), LinearLayout.LayoutParams(dp(96), dp(96)))
        onboardTitle = tv("", 15f, Palette.CREAM, true)
        col.addView(onboardTitle, lp(26))
        nameInput = EditText(this)
        nameInput.hint = "> nome_"
        nameInput.setHintTextColor(Palette.FAINT)
        nameInput.setTextColor(Color.WHITE)
        nameInput.typeface = Fonts.mono
        nameInput.textSize = 17f
        nameInput.setSingleLine(true)
        nameInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        nameInput.imeOptions = EditorInfo.IME_ACTION_DONE
        nameInput.filters = arrayOf(InputFilter.LengthFilter(24))
        nameInput.setPadding(dp(18), dp(15), dp(18), dp(15))
        nameInput.background = glass(20f, hud = true)
        nameInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                saveName()
                true
            } else {
                false
            }
        }
        col.addView(nameInput, lp(14))
        col.addView(button("[ ENTRAR ]", true) { saveName() }, lp(16))
        onboardCancel = tv("[cancelar]", 13f, Palette.FAINT, true)
        onboardCancel.setPadding(dp(14), dp(14), dp(14), dp(14))
        onboardCancel.setOnClickListener {
            editingName = false
            hideKeyboard()
            refresh()
        }
        col.addView(onboardCancel, LinearLayout.LayoutParams(wrap, wrap))
        onboard.addView(col, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER))
    }

    private fun buildRequest() {
        requestLayer = FrameLayout(this)
        requestLayer.setBackgroundColor(Color.argb(232, 4, 4, 4))
        requestLayer.isClickable = true
        requestLayer.visibility = View.GONE
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(26), dp(20), dp(26), dp(20))

        reqAvatarBox = FrameLayout(this)
        reqAvatarBox.addView(RippleView(this), FrameLayout.LayoutParams(match, match))
        col.addView(reqAvatarBox, LinearLayout.LayoutParams(dp(300), dp(300)))

        reqName = tv("", 24f, Color.WHITE, true)
        reqName.gravity = Gravity.CENTER
        col.addView(reqName, lp(0))
        val sub = tv("// pedido de ligação", 12f, Palette.ORANGE, true)
        sub.gravity = Gravity.CENTER
        sub.blink()
        col.addView(sub, lp(6))
        col.addView(button("[ PERMITIR ]", true) { allow() }, lp(30))
        col.addView(button("[ RECUSAR ]", false) { deny() }, lp(12))
        val block = tv("[bloquear]", 12f, Palette.FAINT, true)
        block.gravity = Gravity.CENTER
        block.setPadding(dp(14), dp(14), dp(14), dp(14))
        block.setOnClickListener { blockRequester() }
        col.addView(block, lp(4))
        requestLayer.addView(col, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER))
    }

    private fun buildShare() {
        shareLayer = FrameLayout(this)
        shareLayer.setBackgroundColor(Color.argb(232, 4, 4, 4))
        shareLayer.isClickable = true
        shareLayer.visibility = View.GONE
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(20), dp(22), dp(20))

        val c = card(24, 28f, true)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val live = tv("● AO VIVO", 13f, Palette.ORANGE, true)
        live.letterSpacing = 0.12f
        live.blink()
        c.addView(live)
        shareWith = tv("", 22f, Color.WHITE, true)
        shareWith.gravity = Gravity.CENTER
        c.addView(shareWith, lp(18))
        shareStatus = tv("", 12f, Palette.SOFT)
        shareStatus.gravity = Gravity.CENTER
        c.addView(shareStatus, lp(6))
        shareTime = tv("--:--", 40f, Palette.CREAM, true)
        shareTime.gravity = Gravity.CENTER
        c.addView(shareTime, lp(22))
        col.addView(c, lp(0))
        col.addView(button("[ PARAR ]", true) { stopShare() }, lp(18))
        shareLayer.addView(col, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER))
    }

    private fun buildViewer() {
        viewerLayer = FrameLayout(this)
        viewerLayer.setBackgroundColor(Color.BLACK)
        viewerLayer.visibility = View.GONE
        viewerHost = FrameLayout(this)
        viewerLayer.addView(viewerHost, FrameLayout.LayoutParams(match, match))
        viewerLayer.setOnClickListener { toggleControls() }

        viewerStatus = tv("", 13f, Palette.CREAM, true)
        viewerStatus.gravity = Gravity.CENTER
        viewerStatus.setPadding(dp(20), dp(14), dp(20), dp(14))
        viewerStatus.background = glass(20f, hud = true, strength = 1.5f)
        viewerLayer.addView(viewerStatus, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))

        viewerControls = FrameLayout(this)
        viewerControls.isClickable = false
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(18), dp(12), dp(18), dp(12))
        top.background = glass(20f, hud = true, strength = 1.6f)
        viewerTitle = tv("", 14f, Color.WHITE, true)
        top.addView(viewerTitle, LinearLayout.LayoutParams(0, wrap, 1f))
        viewerTime = tv("--:--", 14f, Palette.ORANGE, true)
        top.addView(viewerTime, LinearLayout.LayoutParams(wrap, wrap))
        val topLp = FrameLayout.LayoutParams(match, wrap, Gravity.TOP)
        topLp.setMargins(dp(14), dp(40), dp(14), 0)
        viewerControls.addView(top, topLp)
        val exit = button("[ SAIR ]", true) { closeViewer() }
        val exitLp = FrameLayout.LayoutParams(dp(180), wrap, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        exitLp.bottomMargin = dp(34)
        viewerControls.addView(exit, exitLp)
        viewerLayer.addView(viewerControls, FrameLayout.LayoutParams(match, match))
        root.addView(viewerLayer, FrameLayout.LayoutParams(match, match))
    }

    private fun buildPeopleShell() {
        val box = boxes[1]
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("// PESSOAS", 20f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
        peopleCount = tv("[0]", 14f, Palette.ORANGE, true)
        head.addView(peopleCount)
        box.addView(head, lp(4))

        searchInput = EditText(this)
        searchInput.hint = "$ grep _"
        searchInput.setHintTextColor(Palette.FAINT)
        searchInput.setTextColor(Palette.CREAM)
        searchInput.typeface = Fonts.mono
        searchInput.textSize = 15f
        searchInput.setSingleLine(true)
        searchInput.imeOptions = EditorInfo.IME_ACTION_DONE
        searchInput.setPadding(dp(18), dp(13), dp(18), dp(13))
        searchInput.background = glass(20f)
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                renderPeople(true)
            }
        })
        box.addView(searchInput, lp(16))
        peopleList = LinearLayout(this)
        peopleList.orientation = LinearLayout.VERTICAL
        box.addView(peopleList, lp(6))
    }

    // ---------------------------------------------------------------- peças

    private fun glass(radius: Float, accent: Boolean = false, hud: Boolean = false, strength: Float = 1f): GlassDrawable =
        GlassDrawable(resources.displayMetrics.density, radius, accent, hud, strength)

    private fun card(pad: Int = 16, radius: Float = 22f, hud: Boolean = false): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(radius, hud = hud)
        c.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        return c
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val v = tv(text, 15f, Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.letterSpacing = 0.1f
        v.setPadding(dp(16), dp(17), dp(16), dp(17))
        v.background = glass(24f, accent = primary, hud = !primary)
        v.isClickable = true
        v.setOnClickListener { onClick() }
        v.pressable()
        return v
    }

    private fun section(text: String): TextView {
        val v = tv(text, 12f, Palette.ORANGE, true)
        v.letterSpacing = 0.12f
        return v
    }

    private fun avatar(name: String, size: Int, sp: Float): TextView {
        val v = tv("", sp, Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        Avatars.style(v, name, size / 4)
        return v
    }

    private fun onlineMap(): Map<String, Person> {
        val now = System.currentTimeMillis()
        val out = LinkedHashMap<String, Person>()
        for (p in Online.people.values) {
            if (now - p.seen < 100_000 && !Store.isBlocked(p.id)) out[p.id] = p
        }
        return out
    }

    private fun stagger(box: LinearLayout) {
        for (i in 0 until box.childCount) box.getChildAt(i).springIn(i * 55L, 22)
    }

    // ---------------------------------------------------------------- abas

    private fun showTab(i: Int) {
        if (i == tab) return
        pages[tab].visibility = View.GONE
        tab = i
        pages[i].visibility = View.VISIBLE
        pages[i].scrollTo(0, 0)
        if (tabBar.selected != i) tabBar.select(i)
        renderTab(i, true)
    }

    private fun renderTab(i: Int, animate: Boolean) {
        when (i) {
            0 -> renderHome()
            1 -> renderPeople(true)
            2 -> renderLog()
            else -> renderConfig()
        }
        if (animate) {
            if (i == 1) stagger(peopleList) else stagger(boxes[i])
        }
    }

    private fun renderHome() {
        val box = boxes[0]
        box.removeAllViews()

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(LogoView(this), LinearLayout.LayoutParams(dp(60), dp(60)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, 0, 0)
        col.addView(tv("ESPELHO_VISK", 19f, Color.WHITE, true))
        val sl = tv("", 12f, Palette.GOOD, true)
        statusLine = sl
        col.addView(sl, lp(3))
        head.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        box.addView(head, lp(4))

        val term = card(18, 24f, true)
        val line = tv("", 13.5f, Palette.CREAM)
        line.setLineSpacing(0f, 1.2f)
        term.addView(line)
        line.typeText("\$ whoami\n> ${Online.myName}\n\$ scan --rede\n> a escutar_", 22L)
        box.addView(term, lp(18))

        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        val hist = Store.history()
        val minutes = hist.sumOf { it.dur } / 60000L
        val s1 = statCard("ONLINE", "0")
        statOnline = s1.second
        val s2 = statCard("SESSÕES", hist.size.toString())
        statSessions = s2.second
        val s3 = statCard("MIN", minutes.toString())
        statMinutes = s3.second
        val sp1 = LinearLayout.LayoutParams(0, wrap, 1f)
        val sp2 = LinearLayout.LayoutParams(0, wrap, 1f)
        val sp3 = LinearLayout.LayoutParams(0, wrap, 1f)
        sp2.setMargins(dp(10), 0, dp(10), 0)
        stats.addView(s1.first, sp1)
        stats.addView(s2.first, sp2)
        stats.addView(s3.first, sp3)
        box.addView(stats, lp(14))

        box.addView(button("[ VER PESSOAS ]", true) { showTab(1) }, lp(18))

        val favs = Store.favorites()
        if (favs.isNotEmpty()) {
            box.addView(section("// FAVORITOS"), lp(26))
            val scroll = HorizontalScrollView(this)
            scroll.isHorizontalScrollBarEnabled = false
            scroll.overScrollMode = View.OVER_SCROLL_NEVER
            val strip = LinearLayout(this)
            strip.orientation = LinearLayout.HORIZONTAL
            val live = onlineMap()
            for ((id, name) in favs) {
                val person = live[id]
                val chip = LinearLayout(this)
                chip.orientation = LinearLayout.VERTICAL
                chip.gravity = Gravity.CENTER_HORIZONTAL
                chip.background = glass(20f)
                chip.setPadding(dp(14), dp(12), dp(14), dp(10))
                chip.addView(avatar(name, 46, 18f))
                val nm = tv(if (name.length > 9) name.take(8) + "…" else name, 11f, Color.WHITE, true)
                nm.gravity = Gravity.CENTER
                chip.addView(nm, lp(7, wrap))
                val st = tv(if (person != null) "● on" else "○ off", 10f, if (person != null) Palette.GOOD else Palette.FAINT, true)
                st.gravity = Gravity.CENTER
                chip.addView(st, lp(2, wrap))
                chip.alpha = if (person != null) 1f else 0.5f
                if (person != null) {
                    chip.setOnClickListener { connectTo(person) }
                    chip.pressable()
                }
                val clp = LinearLayout.LayoutParams(wrap, wrap)
                clp.rightMargin = dp(10)
                strip.addView(chip, clp)
            }
            scroll.addView(strip)
            box.addView(scroll, lp(10))
        }

        box.addView(section("// RECENTE"), lp(26))
        if (hist.isEmpty()) {
            val empty = card(16, 20f)
            empty.addView(tv("> vazio", 13f, Palette.FAINT))
            box.addView(empty, lp(10))
        } else {
            for (e in hist.take(3)) box.addView(logRow(e), lp(10))
        }
        refreshStatus()
    }

    private fun statCard(label: String, value: String): Pair<LinearLayout, TextView> {
        val c = card(14, 20f)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val v = tv(value, 24f, Palette.ORANGE, true)
        v.gravity = Gravity.CENTER
        c.addView(v)
        val l = tv(label, 10f, Palette.FAINT, true)
        l.letterSpacing = 0.1f
        l.gravity = Gravity.CENTER
        c.addView(l, lp(3))
        return Pair(c, v)
    }

    private fun logRow(e: Entry): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(20f)
        row.setPadding(dp(16), dp(13), dp(16), dp(13))
        val view = e.dir == "view"
        val tag = tv(if (view) "VIEW" else "SHARE", 10f, if (view) Palette.AMBER else Palette.ORANGE, true)
        tag.letterSpacing = 0.1f
        tag.setPadding(dp(8), dp(4), dp(8), dp(4))
        tag.background = glass(8f, strength = 0.8f)
        row.addView(tag, LinearLayout.LayoutParams(wrap, wrap))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        col.addView(tv(e.name, 14f, Color.WHITE, true))
        val date = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(e.start))
        col.addView(tv(date, 11f, Palette.FAINT), lp(2))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(tv(formatDuration(e.dur), 14f, Palette.CREAM, true))
        return row
    }

    private fun renderPeople(force: Boolean) {
        val live = onlineMap()
        val favs = Store.favorites()
        val q = searchInput.text.toString().trim().lowercase()
        val entries = ArrayList<Triple<String, String, Person?>>()
        for (p in live.values) entries.add(Triple(p.id, p.name, p))
        for ((id, name) in favs) if (!live.containsKey(id) && !Store.isBlocked(id)) entries.add(Triple(id, name, null))
        val shown = entries
            .filter { q.isEmpty() || it.second.lowercase().contains(q) }
            .sortedWith(compareBy({ !favs.containsKey(it.first) }, { it.third == null }, { it.second.lowercase() }))
        val sig = q + "|" + shown.joinToString(",") { it.first + it.second + (it.third != null) + favs.containsKey(it.first) }
        if (!force && sig == peopleSig) return
        peopleSig = sig
        peopleCount.text = "[${live.size}]"
        peopleList.removeAllViews()
        if (shown.isEmpty()) {
            val empty = card(18, 20f)
            empty.addView(tv(if (q.isEmpty()) "> sem sinal" else "> 0 resultados", 13f, Palette.FAINT))
            peopleList.addView(empty, lp(10))
            return
        }
        for (t in shown) peopleList.addView(personRow(t.first, t.second, t.third), lp(10))
    }

    private fun personRow(id: String, name: String, person: Person?): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(22f)
        row.setPadding(dp(12), dp(12), dp(6), dp(12))
        row.addView(avatar(name, 48, 19f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, dp(6), 0)
        col.addView(tv(name, 16f, Color.WHITE, true))
        val on = person != null
        col.addView(tv(if (on) "● online" else "○ offline", 11f, if (on) Palette.GOOD else Palette.FAINT, true), lp(3))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        val fav = Store.isFav(id)
        val star = tv(if (fav) "★" else "☆", 24f, if (fav) Palette.ORANGE else Palette.FAINT, true)
        star.setPadding(dp(14), dp(10), dp(14), dp(10))
        star.setOnClickListener {
            Store.toggleFav(id, name)
            renderPeople(true)
        }
        star.pressable()
        row.addView(star)
        if (on && person != null) {
            row.isClickable = true
            row.setOnClickListener { connectTo(person) }
            row.pressable()
        } else {
            row.alpha = 0.5f
        }
        return row
    }

    private fun renderLog() {
        val box = boxes[2]
        box.removeAllViews()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("// LOG", 20f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
        val clear = tv("[limpar]", 13f, Palette.ORANGE, true)
        clear.setPadding(dp(10), dp(10), dp(4), dp(10))
        clear.setOnClickListener {
            Store.clearHistory()
            renderLog()
        }
        head.addView(clear)
        box.addView(head, lp(4))
        val hist = Store.history()
        if (hist.isEmpty()) {
            val empty = card(18, 20f)
            empty.addView(tv("> vazio", 13f, Palette.FAINT))
            box.addView(empty, lp(14))
        } else {
            for (e in hist) box.addView(logRow(e), lp(10))
        }
    }

    private fun qualityDetail(q: String): String = when (q) {
        "high" -> "1920px · 24fps · 3.0Mbps"
        "eco" -> "854px · 12fps · 0.8Mbps"
        else -> "1280px · 15fps · 1.5Mbps"
    }

    private fun settingRow(title: String, sub: String, initial: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(22f)
        row.setPadding(dp(18), dp(14), dp(16), dp(14))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 14f, Color.WHITE, true))
        col.addView(tv(sub, 11f, Palette.FAINT), lp(3))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(GlassSwitch(this, initial, onChange))
        return row
    }

    private fun renderConfig() {
        val box = boxes[3]
        box.removeAllViews()
        box.addView(tv("// CONFIG", 20f, Color.WHITE, true), lp(4))

        val prof = LinearLayout(this)
        prof.orientation = LinearLayout.HORIZONTAL
        prof.gravity = Gravity.CENTER_VERTICAL
        prof.background = glass(24f, hud = true)
        prof.setPadding(dp(16), dp(16), dp(12), dp(16))
        prof.addView(avatar(Online.myName.ifEmpty { "?" }, 54, 22f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, dp(6), 0)
        col.addView(tv(Online.myName, 17f, Color.WHITE, true))
        col.addView(tv("id:" + Online.myId.take(6), 11f, Palette.FAINT), lp(3))
        prof.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        val rename = tv("[renomear]", 12f, Palette.ORANGE, true)
        rename.setPadding(dp(10), dp(12), dp(10), dp(12))
        rename.setOnClickListener {
            editingName = true
            nameInput.setText(Online.myName)
            nameInput.setSelection(nameInput.text.length)
            refresh()
        }
        prof.addView(rename)
        box.addView(prof, lp(16))

        box.addView(section("// QUALIDADE"), lp(24))
        val keys = listOf("auto", "high", "eco")
        val detail = tv(qualityDetail(Store.quality), 11f, Palette.FAINT, true)
        val seg = Segmented(this, listOf("AUTO", "ALTA", "ECO"), keys.indexOf(Store.quality).coerceAtLeast(0)) { i ->
            Store.quality = keys[i]
            detail.text = qualityDetail(keys[i])
        }
        box.addView(seg, lp(10))
        detail.setPadding(dp(6), 0, 0, 0)
        box.addView(detail, lp(8))

        box.addView(section("// REDE"), lp(24))
        box.addView(
            settingRow("Aparecer online", "visível na lista", Store.onlineOn) { on ->
                Store.onlineOn = on
                if (on) startOnline() else stopOnline()
                refreshStatus()
            }, lp(10)
        )
        box.addView(
            settingRow("Não incomodar", "recusa pedidos", Store.dnd) { on -> Store.dnd = on }, lp(10)
        )

        val blocked = Store.blocked()
        if (blocked.isNotEmpty()) {
            box.addView(section("// BLOQUEADOS"), lp(24))
            for ((id, name) in blocked) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.background = glass(20f)
                row.setPadding(dp(16), dp(10), dp(8), dp(10))
                row.addView(tv(name, 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
                val un = tv("[desbloquear]", 12f, Palette.ORANGE, true)
                un.setPadding(dp(10), dp(12), dp(10), dp(12))
                un.setOnClickListener {
                    Store.unblock(id)
                    renderConfig()
                }
                row.addView(un)
                box.addView(row, lp(10))
            }
        }

        val about = card(16, 20f)
        about.addView(tv("ESPELHO_VISK", 12f, Palette.CREAM, true))
        about.addView(tv("v2.0 // webrtc p2p", 11f, Palette.FAINT), lp(3))
        box.addView(about, lp(28))
    }

    // ---------------------------------------------------------------- estado

    private fun overlay(v: View, show: Boolean) {
        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.visibility = View.VISIBLE
                v.alpha = 0f
                v.animate().alpha(1f).setDuration(280).start()
                val inner = (v as? ViewGroup)?.getChildAt(0)
                inner?.springIn(60L, 36)
            }
        } else if (v.visibility != View.GONE) {
            v.animate().cancel()
            v.visibility = View.GONE
        }
    }

    private fun refresh() {
        val sharing = ShareState.active
        val request = Online.incoming
        val needName = Online.myName.isEmpty() || editingName

        overlay(onboard, needName)
        overlay(requestLayer, !needName && !sharing && request != null)
        overlay(shareLayer, !needName && sharing)
        tabBar.visibility = if (needName || sharing || request != null) View.INVISIBLE else View.VISIBLE

        if (needName) {
            onboardCancel.visibility = if (Online.myName.isNotEmpty()) View.VISIBLE else View.GONE
            if (onboardTitle.tag == null) {
                onboardTitle.tag = "x"
                onboardTitle.typeText(if (Online.myName.isEmpty()) "\$ identificar_" else "\$ renomear_", 30L)
            }
        } else {
            onboardTitle.tag = null
        }

        if (request != null && request.id != lastReqId) {
            lastReqId = request.id
            reqName.text = request.name
            reqAvatarBox.removeAllViews()
            reqAvatarBox.addView(RippleView(this), FrameLayout.LayoutParams(match, match))
            val av = avatar(request.name, 92, 38f)
            reqAvatarBox.addView(av, FrameLayout.LayoutParams(dp(92), dp(92), Gravity.CENTER))
            av.springIn(120L, 0)
        }
        if (request == null) lastReqId = ""

        shareWith.text = "> ${ShareState.name}"
        shareStatus.text = ShareState.status

        if (!sharing && ShareState.status.isNotEmpty()) {
            val msg = ShareState.status
            ShareState.status = ""
            notice(msg)
        }

        refreshStatus()
        if (tab == 1) renderPeople(false)
    }

    private fun refreshStatus() {
        val n = onlineMap().size
        statOnline?.text = n.toString()
        val sl = statusLine ?: return
        if (!Store.onlineOn) {
            sl.text = "○ offline"
            sl.setTextColor(Palette.FAINT)
        } else if (Online.running) {
            sl.text = "● online // $n visíveis"
            sl.setTextColor(Palette.GOOD)
        } else {
            sl.text = "● a ligar…"
            sl.setTextColor(Palette.WARN)
        }
    }

    private fun notice(message: String) {
        ticker.removeCallbacks(noticeHider)
        notice.text = message
        notice.visibility = View.VISIBLE
        notice.springIn(0L, 16)
        ticker.postDelayed(noticeHider, 3800L)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(nameInput.windowToken, 0)
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    companion object {
        private const val REQ_CAPTURE = 42
    }
}
