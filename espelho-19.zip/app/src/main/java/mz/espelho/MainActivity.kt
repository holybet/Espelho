package mz.espelho

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import org.webrtc.EglRenderer
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: FrameLayout
    private lateinit var pages: Array<ScrollView>
    private lateinit var boxes: Array<LinearLayout>
    private lateinit var tabBar: TabBar

    private lateinit var onboard: FrameLayout
    private lateinit var nameInput: EditText
    private lateinit var onboardTitle: TextView
    private lateinit var onboardCancel: TextView

    private lateinit var requestLayer: FrameLayout
    private lateinit var reqAvatarBox: FrameLayout
    private lateinit var reqName: TextView

    private lateinit var shareLayer: FrameLayout
    private lateinit var shareWith: TextView
    private lateinit var shareStatus: TextView
    private lateinit var shareTime: TextView
    private lateinit var pauseBtn: TextView
    private var viewerRenderer: SurfaceViewRenderer? = null
    private var fillMode = false

    private lateinit var viewerLayer: FrameLayout
    private lateinit var viewerHost: FrameLayout
    private lateinit var viewerTitle: TextView
    private lateinit var viewerTime: TextView
    private lateinit var viewerStatus: TextView
    private lateinit var viewerControls: FrameLayout
    private lateinit var viewerStats: TextView
    private lateinit var chips: LinearLayout
    private lateinit var chatRow: LinearLayout
    private lateinit var chatInput: EditText
    private lateinit var replyInput: EditText
    private lateinit var fxBg: FxBackground
    private lateinit var scaler: ScaleGestureDetector
    private lateinit var tapper: GestureDetector
    private var lastPerson: Person? = null
    private var kbOpen = false
    private var maxH = 0
    private var lastW = 0
    private var peopleFilter = 0
    private var lastInteract = 0L
    private var landscape = false
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastX = 0f
    private var lastY = 0f

    private lateinit var notice: TextView
    private lateinit var searchInput: EditText
    private lateinit var peopleList: LinearLayout
    private lateinit var peopleCount: TextView

    private var statusLine: TextView? = null
    private var statOnline: TextView? = null
    private var statSessions: TextView? = null
    private var statMinutes: TextView? = null

    private var tab = 0
    private var viewer: ViewerSession? = null
    private var editingName = false
    private var pendingAllow: Request? = null
    private var peopleSig = "\u0000"
    private var tickCount = 0
    private var controlsShown = true
    private var lastReqId = ""

    private val ticker = Handler(Looper.getMainLooper())
    private val noticeHider = Runnable { notice.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() {
            tickCount++
            val now = System.currentTimeMillis()
            if (ShareState.active) {
                val since = ShareState.since
                shareTime.text = if (since > 0L) formatDuration(now - since) else "--:--"
            }
            viewer?.let {
                viewerTime.text = if (it.connectedAt > 0L) formatDuration(now - it.connectedAt) else "--:--"
            }
            if (tickCount % 2 == 0) {
                viewer?.stats { line -> runOnUiThread { if (Store.showStats) viewerStats.text = line } }
            }
            if (viewer != null && Store.autoHide && controlsShown && (viewer?.connectedAt ?: 0L) > 0L &&
                now - lastInteract > 5000L && chatRow.visibility != View.VISIBLE && !chatInput.hasFocus()
            ) {
                toggleControls()
            }
            refreshStatus()
            if (tickCount % 5 == 0 && tab == 1) renderPeople(false)
            ticker.postDelayed(this, 1000)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        Fx.ripple?.touch(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        Online.load(this)
        Fx.haptic = Store.haptic
        Fx.setLevel(Store.anim)
        window.statusBarColor = Palette.BG
        window.navigationBarColor = Palette.BG
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        renderTab(0, true)
    }

    override fun onResume() {
        super.onResume()
        val changed = { runOnUiThread { refresh() } }
        ShareState.onChange = changed
        Online.onChange = changed
        startOnline()
        ticker.post(tick)
        refresh()
    }

    override fun onPause() {
        ShareState.onChange = null
        Online.onChange = null
        ticker.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        viewer?.close()
        viewer = null
        ticker.removeCallbacks(noticeHider)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            viewer != null -> closeViewer()
            editingName && Online.myName.isNotEmpty() -> {
                editingName = false
                hideKeyboard()
                refresh()
            }
            tab != 0 -> showTab(0)
            else -> super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------- online e nome

    private fun startOnline() {
        if (Online.myName.isEmpty() || !Store.onlineOn) return
        try {
            startForegroundService(Intent(this, OnlineService::class.java))
        } catch (e: Exception) {
            notice("Falha ao ficar online (${e.javaClass.simpleName}).")
        }
    }

    private fun stopOnline() {
        try {
            stopService(Intent(this, OnlineService::class.java))
        } catch (ignored: Exception) {
        }
        Online.people.clear()
        peopleSig = "\u0000"
    }

    private fun saveName() {
        val name = nameInput.text.toString().trim()
        if (name.isEmpty()) {
            notice("> nome vazio")
            return
        }
        hideKeyboard()
        Online.saveName(this, name)
        editingName = false
        startOnline()
        renderTab(tab, true)
        refresh()
    }

    // ---------------------------------------------------------------- pedidos recebidos

    private fun allow() {
        val request = Online.incoming ?: return
        pendingAllow = request
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    private fun deny() {
        val request = Online.incoming ?: return
        Online.send(request.id, JSONObject().put("t", "deny"))
        clearIncoming()
    }

    private fun blockRequester() {
        val request = Online.incoming ?: return
        Store.block(request.id, request.name)
        Online.send(request.id, JSONObject().put("t", "deny"))
        clearIncoming()
    }

    private fun clearIncoming() {
        Online.incoming = null
        getSystemService(NotificationManager::class.java).cancel(OnlineService.NOTIF_REQUEST)
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        val request = pendingAllow
        pendingAllow = null
        if (request == null) return
        if (resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ShareService::class.java)
                .putExtra(ShareService.EXTRA_DATA, data)
                .putExtra(ShareService.EXTRA_VID, request.id)
                .putExtra(ShareService.EXTRA_VNAME, request.name)
            ShareState.status = ""
            startForegroundService(intent)
            clearIncoming()
        } else {
            Online.send(request.id, JSONObject().put("t", "deny"))
            clearIncoming()
        }
    }

    private fun stopShare() {
        stopService(Intent(this, ShareService::class.java))
    }

    // ---------------------------------------------------------------- ver a tela de alguém

    private fun connectTo(person: Person) {
        try {
            Rtc.init(this)
        } catch (e: Throwable) {
            notice("Sem suporte de vídeo (${e.javaClass.simpleName}).")
            return
        }
        val renderer = SurfaceViewRenderer(this)
        renderer.init(Rtc.eglBase.eglBaseContext, null)
        renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        viewerHost.removeAllViews()
        viewerHost.addView(renderer, FrameLayout.LayoutParams(match, match))
        viewerRenderer = renderer
        fillMode = false
        lastPerson = person
        resetZoom()
        viewerStats.text = ""
        chips.visibility = View.GONE
        viewerTitle.text = "> ${person.name}"
        viewerTime.text = "--:--"
        setViewerStatus("A pedir ligação…")
        viewerLayer.visibility = View.VISIBLE
        viewerLayer.alpha = 0f
        viewerLayer.animate().alpha(1f).setDuration(300).start()
        viewerControls.alpha = 1f
        controlsShown = true
        if (Store.keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lastInteract = System.currentTimeMillis()

        val session = ViewerSession(person, renderer) { message -> runOnUiThread { setViewerStatus(message) } }
        viewer = session
        session.onMessage = { text -> notice("> ${person.name}: $text") }
        session.start()
    }

    private fun closeViewer() {
        viewer?.close()
        viewer = null
        viewerHost.removeAllViews()
        viewerRenderer = null
        resetZoom()
        landscape = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        viewerLayer.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        refresh()
        if (tab == 0 || tab == 2) renderTab(tab, false)
    }

    private fun applyZoom() {
        val w = viewerHost.width.toFloat()
        val h = viewerHost.height.toFloat()
        val mx = (zoom - 1f) * w / 2f
        val my = (zoom - 1f) * h / 2f
        panX = panX.coerceIn(-mx, mx)
        panY = panY.coerceIn(-my, my)
        viewerHost.scaleX = zoom
        viewerHost.scaleY = zoom
        viewerHost.translationX = panX
        viewerHost.translationY = panY
    }

    private fun resetZoom() {
        zoom = 1f
        panX = 0f
        panY = 0f
        applyZoom()
    }

    private fun toggleRotate() {
        landscape = !landscape
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        viewerHost.post { resetZoom() }
    }

    private fun retry() {
        val p = lastPerson ?: return
        closeViewer()
        connectTo(p)
    }

    private fun sendTyped() {
        val text = chatInput.text.toString().trim()
        if (text.isEmpty()) return
        viewer?.sendMsg(text.take(60))
        chatInput.setText("")
        hideKeyboard()
        chips.visibility = View.GONE
        chatRow.visibility = View.GONE
        notice("> enviado")
    }

    private fun sendReply() {
        val text = replyInput.text.toString().trim()
        val to = ShareState.vid
        if (text.isEmpty() || to.isEmpty()) return
        Online.send(to, JSONObject().put("t", "msg").put("x", text.take(60)))
        replyInput.setText("")
        hideKeyboard()
        notice("> enviado")
    }

    private fun invite() {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, "Espelho Visk: https://github.com/holybet/Espelho/releases/latest")
        startActivity(Intent.createChooser(i, "Convidar"))
    }

    private fun relayField(hint: String, initial: String, save: (String) -> Unit): EditText {
        val e = inputBox(hint)
        e.textSize = 12f
        e.imeOptions = EditorInfo.IME_ACTION_DONE
        e.setText(initial)
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                save(s?.toString() ?: "")
            }
        })
        return e
    }

    private fun inputBox(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(Palette.FAINT)
        e.setTextColor(Palette.CREAM)
        e.typeface = Fonts.mono
        e.textSize = 14f
        e.setSingleLine(true)
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        e.imeOptions = EditorInfo.IME_ACTION_SEND
        e.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        e.filters = arrayOf(InputFilter.LengthFilter(60))
        e.setPadding(dp(16), dp(12), dp(16), dp(12))
        e.background = glass(18f, hud = true)
        return e
    }

    private fun sendQuick(text: String) {
        viewer?.sendMsg(text)
        chips.visibility = View.GONE
        notice("> enviado: $text")
    }

    private fun toggleFit() {
        val r = viewerRenderer ?: return
        fillMode = !fillMode
        r.setScalingType(
            if (fillMode) RendererCommon.ScalingType.SCALE_ASPECT_FILL
            else RendererCommon.ScalingType.SCALE_ASPECT_FIT
        )
        notice(if (fillMode) "> preencher" else "> ajustar")
    }

    private fun takePhoto() {
        val r = viewerRenderer ?: return
        r.addFrameListener(EglRenderer.FrameListener { bmp -> saveShot(bmp) }, 1f)
    }

    private fun saveShot(bmp: Bitmap) {
        var ok = false
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "espelho_" + System.currentTimeMillis() + ".png")
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/EspelhoVisk")
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        ok = bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                }
            }
        } catch (e: Exception) {
            ok = false
        }
        runOnUiThread { notice(if (ok) "> foto guardada" else "> falha na foto") }
    }

    private fun setViewerStatus(message: String) {
        viewerStatus.text = message
        viewerStatus.visibility = if (message.isEmpty()) View.GONE else View.VISIBLE
        if (message.isNotEmpty() && !controlsShown) toggleControls()
    }

    private fun toggleControls() {
        controlsShown = !controlsShown
        viewerControls.animate().alpha(if (controlsShown) 1f else 0f).setDuration(260).start()
    }

    // ---------------------------------------------------------------- construção da interface

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Palette.BG)
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        fxBg = FxBackground(this)
        root.addView(fxBg, FrameLayout.LayoutParams(match, match))

        boxes = Array(4) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(18), dp(20), dp(18), dp(28))
            box
        }
        pages = Array(4) { i ->
            val page = ScrollView(this)
            page.isVerticalScrollBarEnabled = false
            page.overScrollMode = View.OVER_SCROLL_NEVER
            page.isFillViewport = false
            page.addView(boxes[i], FrameLayout.LayoutParams(match, wrap))
            page.visibility = if (i == 0) View.VISIBLE else View.GONE
            val plp = FrameLayout.LayoutParams(match, match)
            plp.bottomMargin = dp(PAGE_GAP)
            root.addView(page, plp)
            page
        }
        buildPeopleShell()

        tabBar = TabBar(this, listOf("INÍCIO", "PESSOAS", "LOG", "CONFIG")) { i -> showTab(i) }
        val tabLp = FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM)
        tabLp.setMargins(dp(16), 0, dp(16), dp(14))
        root.addView(tabBar, tabLp)

        buildOnboard()
        buildRequest()
        buildShare()
        buildViewer()
        buildNotice()
        val water = WaterLayer(this)
        Fx.ripple = water
        root.addView(water, FrameLayout.LayoutParams(match, match))
        root.viewTreeObserver.addOnGlobalLayoutListener {
            if (root.width != lastW) {
                lastW = root.width
                maxH = 0
            }
            if (root.height > maxH) maxH = root.height
            val open = maxH > 0 && root.height < maxH * 0.8f
            if (open != kbOpen) {
                kbOpen = open
                updateTab()
            }
        }
        setContentView(root)
        root.requestFocus()
    }

    private fun buildNotice() {
        notice = tv("", 12f, Palette.CREAM, true)
        notice.setPadding(dp(16), dp(11), dp(16), dp(11))
        notice.background = glass(18f, hud = true, strength = 1.5f)
        notice.visibility = View.GONE
        val p = FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        p.topMargin = dp(46)
        root.addView(notice, p)
    }

    private fun buildOnboard() {
        onboard = FrameLayout(this)
        onboard.setBackgroundColor(Color.argb(232, 4, 4, 4))
        onboard.isClickable = true
        onboard.visibility = View.GONE
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(28), dp(28), dp(28))
        col.addView(LogoView(this), LinearLayout.LayoutParams(dp(96), dp(96)))
        onboardTitle = tv("", 15f, Palette.CREAM, true)
        col.addView(onboardTitle, lp(26))
        nameInput = EditText(this)
        nameInput.hint = "> nome_"
        nameInput.setHintTextColor(Palette.FAINT)
        nameInput.setTextColor(Color.WHITE)
        nameInput.typeface = Fonts.mono
        nameInput.textSize = 17f
        nameInput.setSingleLine(true)
        nameInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        nameInput.imeOptions = EditorInfo.IME_ACTION_DONE
        nameInput.filters = arrayOf(InputFilter.LengthFilter(24))
        nameInput.setPadding(dp(18), dp(15), dp(18), dp(15))
        nameInput.background = glass(20f, hud = true)
        nameInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                saveName()
                true
            } else {
                false
            }
        }
        col.addView(nameInput, lp(14))
        col.addView(button("[ ENTRAR ]", true) { saveName() }, lp(16))
        onboardCancel = tv("[cancelar]", 13f, Palette.FAINT, true)
        onboardCancel.setPadding(dp(14), dp(14), dp(14), dp(14))
        onboardCancel.setOnClickListener {
            editingName = false
            hideKeyboard()
            refresh()
        }
        col.addView(onboardCancel, LinearLayout.LayoutParams(wrap, wrap))
        onboard.addView(col, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER))
        root.addView(onboard, FrameLayout.LayoutParams(match, match))
    }

    private fun buildRequest() {
        requestLayer = FrameLayout(this)
        requestLayer.setBackgroundColor(Color.argb(232, 4, 4, 4))
        requestLayer.isClickable = true
        requestLayer.visibility = View.GONE
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(26), dp(20), dp(26), dp(20))

        reqAvatarBox = FrameLayout(this)
        reqAvatarBox.addView(RippleView(this), FrameLayout.LayoutParams(match, match))
        col.addView(reqAvatarBox, LinearLayout.LayoutParams(dp(300), dp(300)))

        reqName = tv("", 24f, Color.WHITE, true)
        reqName.gravity = Gravity.CENTER
        col.addView(reqName, lp(0))
        val sub = tv("// pedido de ligação", 12f, Palette.ORANGE, true)
        sub.gravity = Gravity.CENTER
        sub.blink()
        col.addView(sub, lp(6))
        col.addView(button("[ PERMITIR ]", true) { allow() }, lp(30))
        col.addView(button("[ RECUSAR ]", false) { deny() }, lp(12))
        val block = tv("[bloquear]", 12f, Palette.FAINT, true)
        block.gravity = Gravity.CENTER
        block.setPadding(dp(14), dp(14), dp(14), dp(14))
        block.setOnClickListener { blockRequester() }
        col.addView(block, lp(4))
        requestLayer.addView(col, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER))
        root.addView(requestLayer, FrameLayout.LayoutParams(match, match))
    }

    private fun buildShare() {
        shareLayer = FrameLayout(this)
        shareLayer.setBackgroundColor(Color.argb(232, 4, 4, 4))
        shareLayer.isClickable = true
        shareLayer.visibility = View.GONE
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(20), dp(22), dp(20))

        val c = card(24, 28f, true)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val live = tv("● AO VIVO", 13f, Palette.ORANGE, true)
        live.letterSpacing = 0.12f
        live.blink()
        c.addView(live)
        shareWith = tv("", 22f, Color.WHITE, true)
        shareWith.gravity = Gravity.CENTER
        c.addView(shareWith, lp(18))
        shareStatus = tv("", 12f, Palette.SOFT)
        shareStatus.gravity = Gravity.CENTER
        c.addView(shareStatus, lp(6))
        val reply = LinearLayout(this)
        reply.orientation = LinearLayout.HORIZONTAL
        reply.gravity = Gravity.CENTER_VERTICAL
        replyInput = inputBox("> responder_")
        replyInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendReply()
                true
            } else {
                false
            }
        }
        reply.addView(replyInput, LinearLayout.LayoutParams(0, wrap, 1f))
        val replySend = button("OK", true) { sendReply() }
        replySend.setPadding(dp(18), dp(12), dp(18), dp(12))
        val rsl = LinearLayout.LayoutParams(wrap, wrap)
        rsl.leftMargin = dp(8)
        reply.addView(replySend, rsl)
        c.addView(reply, lp(16))
        shareTime = tv("--:--", 40f, Palette.CREAM, true)
        shareTime.gravity = Gravity.CENTER
        c.addView(shareTime, lp(22))
        col.addView(c, lp(0))
        pauseBtn = button("[ PAUSAR ]", false) {
            startService(Intent(this, ShareService::class.java).setAction(ShareService.ACTION_PAUSE))
        }
        col.addView(pauseBtn, lp(18))
        col.addView(button("[ PARAR ]", true) { stopShare() }, lp(12))
        shareLayer.addView(col, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER))
        root.addView(shareLayer, FrameLayout.LayoutParams(match, match))
    }

    private fun buildViewer() {
        viewerLayer = FrameLayout(this)
        viewerLayer.setBackgroundColor(Color.BLACK)
        viewerLayer.visibility = View.GONE
        viewerHost = FrameLayout(this)
        viewerLayer.addView(viewerHost, FrameLayout.LayoutParams(match, match))
        scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(1f, 5f)
                applyZoom()
                return true
            }
        })
        tapper = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (zoom > 1f) {
                    resetZoom()
                } else {
                    zoom = 2.5f
                    applyZoom()
                }
                return true
            }
        })
        viewerLayer.setOnTouchListener { _, e ->
            lastInteract = System.currentTimeMillis()
            scaler.onTouchEvent(e)
            tapper.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.x
                    lastY = e.y
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    val k = if (e.actionIndex == 0) 1 else 0
                    lastX = e.getX(k)
                    lastY = e.getY(k)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount == 1 && zoom > 1f && !scaler.isInProgress) {
                        panX += e.x - lastX
                        panY += e.y - lastY
                        applyZoom()
                    }
                    lastX = e.x
                    lastY = e.y
                }
            }
            true
        }

        viewerStatus = tv("", 13f, Palette.CREAM, true)
        viewerStatus.gravity = Gravity.CENTER
        viewerStatus.setPadding(dp(20), dp(14), dp(20), dp(14))
        viewerStatus.background = glass(20f, hud = true, strength = 1.5f)
        viewerLayer.addView(viewerStatus, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))

        viewerControls = FrameLayout(this)
        viewerControls.isClickable = false
        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.setPadding(dp(18), dp(12), dp(18), dp(12))
        top.background = glass(20f, hud = true, strength = 1.6f)
        val trow = LinearLayout(this)
        trow.orientation = LinearLayout.HORIZONTAL
        trow.gravity = Gravity.CENTER_VERTICAL
        viewerTitle = tv("", 14f, Color.WHITE, true)
        trow.addView(viewerTitle, LinearLayout.LayoutParams(0, wrap, 1f))
        viewerTime = tv("--:--", 14f, Palette.ORANGE, true)
        trow.addView(viewerTime, LinearLayout.LayoutParams(wrap, wrap))
        top.addView(trow, lp(0))
        viewerStats = tv("", 10.5f, Palette.FAINT, true)
        top.addView(viewerStats, lp(3))
        val topLp = FrameLayout.LayoutParams(match, wrap, Gravity.TOP)
        topLp.setMargins(dp(14), dp(40), dp(14), 0)
        viewerControls.addView(top, topLp)
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER
        chips.visibility = View.GONE
        for (t in listOf("olá", "ok", "pode parar?")) {
            val chip = tv(t, 12f, Palette.CREAM, true)
            chip.setPadding(dp(14), dp(10), dp(14), dp(10))
            chip.background = glass(16f, hud = true, strength = 1.5f)
            chip.setOnClickListener { sendQuick(t) }
            chip.pressable()
            val cl = LinearLayout.LayoutParams(wrap, wrap)
            cl.setMargins(dp(5), 0, dp(5), 0)
            chips.addView(chip, cl)
        }
        bottom.addView(chips, lp(0))
        chatRow = LinearLayout(this)
        chatRow.orientation = LinearLayout.HORIZONTAL
        chatRow.gravity = Gravity.CENTER_VERTICAL
        chatRow.visibility = View.GONE
        chatInput = inputBox("> mensagem_")
        chatInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendTyped()
                true
            } else {
                false
            }
        }
        chatRow.addView(chatInput, LinearLayout.LayoutParams(0, wrap, 1f))
        val chatSend = button("OK", true) { sendTyped() }
        chatSend.setPadding(dp(18), dp(12), dp(18), dp(12))
        val csl = LinearLayout.LayoutParams(wrap, wrap)
        csl.leftMargin = dp(8)
        chatRow.addView(chatSend, csl)
        bottom.addView(chatRow, lp(8))

        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        val photo = button("FOTO", false) { takePhoto() }
        val fit = button("AJUSTAR", false) { toggleFit() }
        val rot = button("GIRAR", false) { toggleRotate() }
        val msg = button("MSG", false) {
            val show = chatRow.visibility != View.VISIBLE
            chatRow.visibility = if (show) View.VISIBLE else View.GONE
            chips.visibility = if (show) View.VISIBLE else View.GONE
        }
        val toolButtons = listOf(photo, fit, rot, msg)
        for ((i, bt) in toolButtons.withIndex()) {
            bt.textSize = 11f
            bt.letterSpacing = 0.04f
            bt.setPadding(dp(4), dp(13), dp(4), dp(13))
            val tl = LinearLayout.LayoutParams(0, wrap, 1f)
            if (i > 0) tl.leftMargin = dp(8)
            tools.addView(bt, tl)
        }
        bottom.addView(tools, lp(8))

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val again = button("RETENTAR", false) { retry() }
        val exit = button("SAIR", true) { closeViewer() }
        again.textSize = 12f
        exit.textSize = 12f
        again.setPadding(dp(4), dp(14), dp(4), dp(14))
        exit.setPadding(dp(4), dp(14), dp(4), dp(14))
        val r1 = LinearLayout.LayoutParams(0, wrap, 1f)
        val r2 = LinearLayout.LayoutParams(0, wrap, 1f)
        r2.leftMargin = dp(8)
        row2.addView(again, r1)
        row2.addView(exit, r2)
        bottom.addView(row2, lp(8))
        val bottomLp = FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM)
        bottomLp.setMargins(dp(14), 0, dp(14), dp(24))
        viewerControls.addView(bottom, bottomLp)
        viewerLayer.addView(viewerControls, FrameLayout.LayoutParams(match, match))
        root.addView(viewerLayer, FrameLayout.LayoutParams(match, match))
    }

    private fun buildPeopleShell() {
        val box = boxes[1]
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("// PESSOAS", 20f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
        peopleCount = tv("[0]", 14f, Palette.ORANGE, true)
        head.addView(peopleCount)
        box.addView(head, lp(4))

        searchInput = EditText(this)
        searchInput.hint = "$ grep _"
        searchInput.setHintTextColor(Palette.FAINT)
        searchInput.setTextColor(Palette.CREAM)
        searchInput.typeface = Fonts.mono
        searchInput.textSize = 15f
        searchInput.setSingleLine(true)
        searchInput.imeOptions = EditorInfo.IME_ACTION_DONE
        searchInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        searchInput.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        searchInput.setPadding(dp(18), dp(13), dp(18), dp(13))
        searchInput.background = glass(20f)
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                renderPeople(true)
            }
        })
        box.addView(searchInput, lp(16))
        box.addView(Segmented(this, listOf("TODOS", "FAV", "ONLINE"), 0) { i ->
            peopleFilter = i
            renderPeople(true)
        }, lp(10))
        peopleList = LinearLayout(this)
        peopleList.orientation = LinearLayout.VERTICAL
        box.addView(peopleList, lp(6))
    }

    // ---------------------------------------------------------------- peças

    private fun glass(radius: Float, accent: Boolean = false, hud: Boolean = false, strength: Float = 1f): GlassDrawable =
        GlassDrawable(resources.displayMetrics.density, radius, accent, hud, strength)

    private fun card(pad: Int = 16, radius: Float = 22f, hud: Boolean = false): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = glass(radius, hud = hud)
        c.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        return c
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val v = tv(text, 15f, Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.letterSpacing = 0.1f
        v.setPadding(dp(16), dp(17), dp(16), dp(17))
        v.background = glass(24f, accent = primary, hud = !primary)
        v.isClickable = true
        v.setOnClickListener { onClick() }
        v.pressable()
        return v
    }

    private fun section(text: String): TextView {
        val v = tv(text, 12f, Palette.ORANGE, true)
        v.letterSpacing = 0.12f
        return v
    }

    private fun avatar(name: String, size: Int, sp: Float): TextView {
        val v = tv("", sp, Color.WHITE, true)
        v.gravity = Gravity.CENTER
        v.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        Avatars.style(v, name, size / 4)
        return v
    }

    private fun onlineMap(): Map<String, Person> {
        val now = System.currentTimeMillis()
        val out = LinkedHashMap<String, Person>()
        for (p in Online.people.values) {
            if (now - p.seen < 100_000 && !Store.isBlocked(p.id)) out[p.id] = p
        }
        return out
    }

    private fun stagger(box: LinearLayout) {
        for (i in 0 until box.childCount) box.getChildAt(i).springIn(i * 55L, 22)
    }

    // ---------------------------------------------------------------- abas

    private fun showTab(i: Int) {
        if (i == tab) return
        val dir = if (i > tab) 1 else -1
        pages[tab].visibility = View.GONE
        tab = i
        pages[i].visibility = View.VISIBLE
        pages[i].animate().cancel()
        pages[i].translationX = dp(52) * dir.toFloat()
        pages[i].animate().translationX(0f).setDuration(820).setInterpolator(Elastic(0.5f, 6f)).start()
        pages[i].scrollTo(0, 0)
        if (i == 1) searchInput.setText("")
        root.requestFocus()
        hideKeyboard()
        if (tabBar.selected != i) tabBar.select(i)
        renderTab(i, true)
    }

    private fun renderTab(i: Int, animate: Boolean) {
        when (i) {
            0 -> renderHome()
            1 -> renderPeople(true)
            2 -> renderLog()
            else -> renderConfig()
        }
        if (animate) {
            if (i == 1) stagger(peopleList) else stagger(boxes[i])
        }
    }

    private fun renderHome() {
        val box = boxes[0]
        box.removeAllViews()

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(LogoView(this), LinearLayout.LayoutParams(dp(60), dp(60)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, 0, 0)
        col.addView(tv("ESPELHO_VISK", 19f, Color.WHITE, true))
        val sl = tv("", 12f, Palette.GOOD, true)
        statusLine = sl
        col.addView(sl, lp(3))
        head.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        box.addView(head, lp(4))

        val term = card(18, 24f, true)
        val line = tv("", 13.5f, Palette.CREAM)
        line.setLineSpacing(0f, 1.2f)
        term.addView(line)
        line.typeText("\$ whoami\n> ${Online.myName}\n\$ scan --rede\n> a escutar_", 22L)
        box.addView(term, lp(18))

        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        val hist = Store.history()
        val minutes = hist.sumOf { it.dur } / 60000L
        val s1 = statCard("ONLINE", "0")
        statOnline = s1.second
        val s2 = statCard("SESSÕES", hist.size.toString())
        statSessions = s2.second
        val s3 = statCard("MIN", minutes.toString())
        statMinutes = s3.second
        val sp1 = LinearLayout.LayoutParams(0, wrap, 1f)
        val sp2 = LinearLayout.LayoutParams(0, wrap, 1f)
        val sp3 = LinearLayout.LayoutParams(0, wrap, 1f)
        sp2.setMargins(dp(10), 0, dp(10), 0)
        stats.addView(s1.first, sp1)
        stats.addView(s2.first, sp2)
        stats.addView(s3.first, sp3)
        box.addView(stats, lp(14))

        box.addView(button("[ VER PESSOAS ]", true) { showTab(1) }, lp(18))

        val favs = Store.favorites()
        if (favs.isNotEmpty()) {
            box.addView(section("// FAVORITOS"), lp(26))
            val scroll = HorizontalScrollView(this)
            scroll.isHorizontalScrollBarEnabled = false
            scroll.overScrollMode = View.OVER_SCROLL_NEVER
            val strip = LinearLayout(this)
            strip.orientation = LinearLayout.HORIZONTAL
            val live = onlineMap()
            for ((id, name) in favs) {
                val person = live[id]
                val chip = LinearLayout(this)
                chip.orientation = LinearLayout.VERTICAL
                chip.gravity = Gravity.CENTER_HORIZONTAL
                chip.background = glass(20f)
                chip.setPadding(dp(14), dp(12), dp(14), dp(10))
                chip.addView(avatar(name, 46, 18f))
                val nm = tv(if (name.length > 9) name.take(8) + "…" else name, 11f, Color.WHITE, true)
                nm.gravity = Gravity.CENTER
                chip.addView(nm, lp(7, wrap))
                val st = tv(if (person != null) "● on" else "○ off", 10f, if (person != null) Palette.GOOD else Palette.FAINT, true)
                st.gravity = Gravity.CENTER
                chip.addView(st, lp(2, wrap))
                chip.alpha = if (person != null) 1f else 0.5f
                if (person != null) {
                    chip.setOnClickListener { connectTo(person) }
                    chip.pressable()
                }
                val clp = LinearLayout.LayoutParams(wrap, wrap)
                clp.rightMargin = dp(10)
                strip.addView(chip, clp)
            }
            scroll.addView(strip)
            box.addView(scroll, lp(10))
        }

        box.addView(section("// RECENTE"), lp(26))
        if (hist.isEmpty()) {
            val empty = card(16, 20f)
            empty.addView(tv("> vazio", 13f, Palette.FAINT))
            box.addView(empty, lp(10))
        } else {
            for (e in hist.take(3)) box.addView(logRow(e), lp(10))
        }
        refreshStatus()
    }

    private fun statCard(label: String, value: String): Pair<LinearLayout, TextView> {
        val c = card(14, 20f)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val v = tv(value, 24f, Palette.ORANGE, true)
        v.gravity = Gravity.CENTER
        c.addView(v)
        val l = tv(label, 10f, Palette.FAINT, true)
        l.letterSpacing = 0.1f
        l.gravity = Gravity.CENTER
        c.addView(l, lp(3))
        return Pair(c, v)
    }

    private fun logRow(e: Entry): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(20f)
        row.setPadding(dp(16), dp(13), dp(16), dp(13))
        val view = e.dir == "view"
        val tag = tv(if (view) "VIEW" else "SHARE", 10f, if (view) Palette.AMBER else Palette.ORANGE, true)
        tag.letterSpacing = 0.1f
        tag.setPadding(dp(8), dp(4), dp(8), dp(4))
        tag.background = glass(8f, strength = 0.8f)
        row.addView(tag, LinearLayout.LayoutParams(wrap, wrap))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        col.addView(tv(e.name, 14f, Color.WHITE, true))
        val date = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(e.start))
        col.addView(tv(date, 11f, Palette.FAINT), lp(2))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(tv(formatDuration(e.dur), 14f, Palette.CREAM, true))
        val live = onlineMap()[e.id]
        if (live != null) {
            row.isClickable = true
            row.setOnClickListener { connectTo(live) }
            row.pressable()
        }
        return row
    }

    private fun renderPeople(force: Boolean) {
        val live = onlineMap()
        val favs = Store.favorites()
        val q = searchInput.text.toString().trim().lowercase()
        val entries = ArrayList<Triple<String, String, Person?>>()
        for (p in live.values) entries.add(Triple(p.id, p.name, p))
        for ((id, name) in favs) if (!live.containsKey(id) && !Store.isBlocked(id)) entries.add(Triple(id, name, null))
        val shown = entries
            .filter { q.isEmpty() || it.second.lowercase().contains(q) }
            .filter { peopleFilter == 0 || (peopleFilter == 1 && favs.containsKey(it.first)) || (peopleFilter == 2 && it.third != null) }
            .sortedWith(compareBy({ !favs.containsKey(it.first) }, { it.third == null }, { it.second.lowercase() }))
        val sig = q + peopleFilter + "|" + shown.joinToString(",") { it.first + it.second + (it.third != null) + favs.containsKey(it.first) }
        if (!force && sig == peopleSig) return
        peopleSig = sig
        peopleCount.text = "[${live.size}]"
        peopleList.removeAllViews()
        if (shown.isEmpty()) {
            val empty = card(18, 20f)
            empty.addView(tv(if (q.isEmpty()) "> sem sinal" else "> 0 resultados", 13f, Palette.FAINT))
            peopleList.addView(empty, lp(10))
            return
        }
        for (t in shown) peopleList.addView(personRow(t.first, t.second, t.third), lp(10))
    }

    private fun personRow(id: String, name: String, person: Person?): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(22f)
        row.setPadding(dp(12), dp(12), dp(6), dp(12))
        row.addView(avatar(name, 48, 19f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, dp(6), 0)
        col.addView(tv(name, 16f, Color.WHITE, true))
        val on = person != null
        col.addView(tv(if (on) "● online" else "○ offline", 11f, if (on) Palette.GOOD else Palette.FAINT, true), lp(3))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        val fav = Store.isFav(id)
        val star = tv(if (fav) "★" else "☆", 24f, if (fav) Palette.ORANGE else Palette.FAINT, true)
        star.setPadding(dp(14), dp(10), dp(14), dp(10))
        star.setOnClickListener {
            Store.toggleFav(id, name)
            renderPeople(true)
        }
        star.pressable()
        row.addView(star)
        if (on && person != null) {
            row.isClickable = true
            row.setOnClickListener { connectTo(person) }
            row.pressable()
        } else {
            row.alpha = 0.5f
        }
        return row
    }

    private fun renderLog() {
        val box = boxes[2]
        box.removeAllViews()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("// LOG", 20f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
        val clear = tv("[limpar]", 13f, Palette.ORANGE, true)
        clear.setPadding(dp(10), dp(10), dp(4), dp(10))
        clear.setOnClickListener {
            Store.clearHistory()
            renderLog()
        }
        head.addView(clear)
        box.addView(head, lp(4))
        val hist = Store.history()
        if (hist.isEmpty()) {
            val empty = card(18, 20f)
            empty.addView(tv("> vazio", 13f, Palette.FAINT))
            box.addView(empty, lp(14))
        } else {
            for (e in hist) box.addView(logRow(e), lp(10))
        }
    }

    private fun qualityDetail(q: String): String = when (q) {
        "high" -> "1920px · 24fps · 3.0Mbps"
        "eco" -> "854px · 12fps · 0.8Mbps"
        else -> "1280px · 15fps · 1.5Mbps"
    }

    private fun settingRow(title: String, sub: String, initial: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = glass(22f)
        row.setPadding(dp(18), dp(14), dp(16), dp(14))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 14f, Color.WHITE, true))
        col.addView(tv(sub, 11f, Palette.FAINT), lp(3))
        row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(GlassSwitch(this, initial, onChange))
        return row
    }

    private fun renderConfig() {
        val box = boxes[3]
        box.removeAllViews()
        box.addView(tv("// CONFIG", 20f, Color.WHITE, true), lp(4))

        val prof = LinearLayout(this)
        prof.orientation = LinearLayout.HORIZONTAL
        prof.gravity = Gravity.CENTER_VERTICAL
        prof.background = glass(24f, hud = true)
        prof.setPadding(dp(16), dp(16), dp(12), dp(16))
        prof.addView(avatar(Online.myName.ifEmpty { "?" }, 54, 22f))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, dp(6), 0)
        col.addView(tv(Online.myName, 17f, Color.WHITE, true))
        col.addView(tv("id:" + Online.myId.take(6), 11f, Palette.FAINT), lp(3))
        prof.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        val rename = tv("[renomear]", 12f, Palette.ORANGE, true)
        rename.setPadding(dp(10), dp(12), dp(10), dp(12))
        rename.setOnClickListener {
            editingName = true
            nameInput.setText(Online.myName)
            nameInput.setSelection(nameInput.text.length)
            refresh()
        }
        prof.addView(rename)
        box.addView(prof, lp(16))

        box.addView(section("// QUALIDADE"), lp(24))
        val keys = listOf("auto", "high", "eco")
        val detail = tv(qualityDetail(Store.quality), 11f, Palette.FAINT, true)
        val seg = Segmented(this, listOf("AUTO", "ALTA", "ECO"), keys.indexOf(Store.quality).coerceAtLeast(0)) { i ->
            Store.quality = keys[i]
            detail.text = qualityDetail(keys[i])
        }
        box.addView(seg, lp(10))
        detail.setPadding(dp(6), 0, 0, 0)
        box.addView(detail, lp(8))

        box.addView(section("// RELAY"), lp(24))
        box.addView(relayField("> servidor (global.relay.metered.ca)", Store.turnHost) { Store.turnHost = it }, lp(10))
        box.addView(relayField("> utilizador", Store.turnUser) { Store.turnUser = it }, lp(8))
        box.addView(relayField("> palavra-passe", Store.turnPass) { Store.turnPass = it }, lp(8))

        box.addView(section("// REDE"), lp(24))
        box.addView(
            settingRow("Aparecer online", "visível na lista", Store.onlineOn) { on ->
                Store.onlineOn = on
                if (on) startOnline() else stopOnline()
                refreshStatus()
            }, lp(10)
        )
        box.addView(
            settingRow("Não incomodar", "recusa pedidos", Store.dnd) { on -> Store.dnd = on }, lp(10)
        )
        box.addView(
            settingRow("Avisar favoritos", "notifica quando ficam online", Store.favNotify) { on -> Store.favNotify = on },
            lp(10)
        )
        box.addView(
            settingRow("Iniciar com o telemóvel", "fica online ao ligar", Store.autostart) { on -> Store.autostart = on },
            lp(10)
        )
        box.addView(section("// COMPORTAMENTO"), lp(24))
        box.addView(
            settingRow("Vibração", "toque nos botões", Store.haptic) { on ->
                Store.haptic = on
                Fx.haptic = on
            }, lp(10)
        )
        box.addView(
            settingRow("Manter ecrã ligado", "enquanto vê", Store.keepOn) { on -> Store.keepOn = on }, lp(10)
        )
        box.addView(
            settingRow("Ocultar controlos", "após 5 s sem tocar", Store.autoHide) { on -> Store.autoHide = on }, lp(10)
        )
        box.addView(
            settingRow("Mostrar estatísticas", "fps, resolução, débito", Store.showStats) { on ->
                Store.showStats = on
                if (!on) viewerStats.text = ""
            }, lp(10)
        )

        box.addView(section("// VISUAL"), lp(24))
        box.addView(Segmented(this, listOf("SUAVE", "ELÁSTICO", "GELEIA"), Store.anim) { i ->
            Store.anim = i
            Fx.setLevel(i)
        }, lp(10))
        box.addView(
            settingRow("Efeitos de fundo", "chuva de código e ondas", Store.fx) { on ->
                Store.fx = on
                fxBg.invalidate()
            }, lp(10)
        )

        val blocked = Store.blocked()
        if (blocked.isNotEmpty()) {
            box.addView(section("// BLOQUEADOS"), lp(24))
            for ((id, name) in blocked) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.background = glass(20f)
                row.setPadding(dp(16), dp(10), dp(8), dp(10))
                row.addView(tv(name, 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, wrap, 1f))
                val un = tv("[desbloquear]", 12f, Palette.ORANGE, true)
                un.setPadding(dp(10), dp(12), dp(10), dp(12))
                un.setOnClickListener {
                    Store.unblock(id)
                    renderConfig()
                }
                row.addView(un)
                box.addView(row, lp(10))
            }
        }

        box.addView(section("// DADOS"), lp(24))
        box.addView(button("[ LIMPAR FAVORITOS ]", false) {
            for (k in Store.favorites().keys.toList()) Store.toggleFav(k, "")
            renderConfig()
            notice("> favoritos limpos")
        }, lp(10))
        box.addView(button("[ CONVIDAR ]", false) { invite() }, lp(10))

        val about = card(16, 20f)
        about.addView(tv("ESPELHO_VISK", 12f, Palette.CREAM, true))
        about.addView(tv("v2.5 // webrtc p2p", 11f, Palette.FAINT), lp(3))
        box.addView(about, lp(28))
    }

    // ---------------------------------------------------------------- estado

    private fun overlay(v: View, show: Boolean) {
        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.animate().cancel()
                v.alpha = 1f
                v.visibility = View.VISIBLE
                val inner = (v as? ViewGroup)?.getChildAt(0)
                inner?.springIn(0L, 30)
            }
        } else if (v.visibility != View.GONE) {
            v.animate().cancel()
            v.visibility = View.GONE
        }
    }

    private fun refresh() {
        val sharing = ShareState.active
        val request = Online.incoming
        val needName = Online.myName.isEmpty() || editingName

        overlay(onboard, needName)
        overlay(requestLayer, !needName && !sharing && request != null)
        overlay(shareLayer, !needName && sharing)
        updateTab()

        if (needName) {
            onboardCancel.visibility = if (Online.myName.isNotEmpty()) View.VISIBLE else View.GONE
            if (onboardTitle.tag == null) {
                onboardTitle.tag = "x"
                onboardTitle.typeText(if (Online.myName.isEmpty()) "\$ identificar_" else "\$ renomear_", 30L)
            }
        } else {
            onboardTitle.tag = null
        }

        if (request != null && request.id != lastReqId) {
            lastReqId = request.id
            reqName.text = request.name
            reqAvatarBox.removeAllViews()
            reqAvatarBox.addView(RippleView(this), FrameLayout.LayoutParams(match, match))
            val av = avatar(request.name, 92, 38f)
            reqAvatarBox.addView(av, FrameLayout.LayoutParams(dp(92), dp(92), Gravity.CENTER))
            av.springIn(120L, 0)
        }
        if (request == null) lastReqId = ""

        shareWith.text = "> ${ShareState.name}"
        shareStatus.text = ShareState.status
        pauseBtn.text = if (ShareState.paused) "[ RETOMAR ]" else "[ PAUSAR ]"
        if (Online.lastMsg.isNotEmpty()) {
            val text = Online.lastMsg
            Online.lastMsg = ""
            notice("> ${ShareState.name}: $text")
        }

        if (!sharing && ShareState.status.isNotEmpty()) {
            val msg = ShareState.status
            ShareState.status = ""
            notice(msg)
        }

        refreshStatus()
        if (tab == 1) renderPeople(false)
    }

    private fun updateTab() {
        val hide = Online.myName.isEmpty() || editingName || ShareState.active ||
            Online.incoming != null || kbOpen || viewer != null
        tabBar.visibility = if (hide) View.INVISIBLE else View.VISIBLE
        for (p in pages) {
            val lp = p.layoutParams as FrameLayout.LayoutParams
            val want = if (hide) 0 else dp(PAGE_GAP)
            if (lp.bottomMargin != want) {
                lp.bottomMargin = want
                p.layoutParams = lp
            }
        }
    }

    private fun refreshStatus() {
        val n = onlineMap().size
        statOnline?.text = n.toString()
        val sl = statusLine ?: return
        if (!Store.onlineOn) {
            sl.text = "○ offline"
            sl.setTextColor(Palette.FAINT)
        } else if (Online.running) {
            sl.text = "● online // $n visíveis"
            sl.setTextColor(Palette.GOOD)
        } else {
            sl.text = "● a ligar…"
            sl.setTextColor(Palette.WARN)
        }
    }

    private fun notice(message: String) {
        ticker.removeCallbacks(noticeHider)
        notice.text = message
        val nlp = notice.layoutParams as FrameLayout.LayoutParams
        nlp.topMargin = dp(if (viewer != null) 118 else 46)
        notice.layoutParams = nlp
        notice.visibility = View.VISIBLE
        notice.springIn(0L, 16)
        ticker.postDelayed(noticeHider, 3800L)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(nameInput.windowToken, 0)
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    companion object {
        private const val REQ_CAPTURE = 42
        private const val PAGE_GAP = 96
    }
}
