package mz.espelho

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Cartão de vidro líquido: translúcido, com brilho no topo, luz laranja por baixo e contorno que apanha a luz. */
class GlassDrawable(
    private val density: Float,
    radiusDp: Float,
    private val accent: Boolean = false,
    private val hud: Boolean = false,
    private val strength: Float = 1f
) : Drawable() {

    private val r = radiusDp * density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private var ticks = FloatArray(0)
    private var bw = 0f
    private var bh = 0f

    init {
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = 1.3f * density
        tick.style = Paint.Style.STROKE
        tick.strokeWidth = 1.8f * density
        tick.strokeCap = Paint.Cap.ROUND
        tick.color = Color.argb(215, 255, 122, 26)
    }

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        bw = w
        bh = h
        val inset = 0.65f * density
        rect.set(inset, inset, w - inset, h - inset)
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)

        fill.shader = if (accent) {
            LinearGradient(
                0f, 0f, w, h,
                Color.argb(242, 255, 154, 61), Color.argb(242, 255, 84, 0), Shader.TileMode.CLAMP
            )
        } else {
            LinearGradient(
                0f, 0f, 0f, h,
                Color.argb((52 * strength).toInt(), 255, 255, 255),
                Color.argb((17 * strength).toInt(), 255, 255, 255),
                Shader.TileMode.CLAMP
            )
        }
        sheen.shader = LinearGradient(
            0f, 0f, 0f, h * 0.5f,
            Color.argb(if (accent) 100 else 72, 255, 255, 255), Color.argb(0, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
        glow.shader = LinearGradient(
            0f, h * 0.55f, 0f, h,
            Color.argb(0, 255, 110, 20), Color.argb(if (accent) 45 else 66, 255, 110, 20),
            Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(
                Color.argb(210, 255, 255, 255),
                Color.argb(26, 255, 255, 255),
                Color.argb(180, 255, 122, 26)
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        val m = r * 0.42f + 3f * density
        val l = 9f * density
        ticks = floatArrayOf(
            m, m, m + l, m, m, m, m, m + l,
            w - m, m, w - m - l, m, w - m, m, w - m, m + l,
            m, h - m, m + l, h - m, m, h - m, m, h - m - l,
            w - m, h - m, w - m - l, h - m, w - m, h - m, w - m, h - m - l
        )
    }

    override fun draw(canvas: Canvas) {
        if (bw <= 0f || bh <= 0f) return
        val b = bounds
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.save()
        canvas.clipPath(clip)
        canvas.drawRect(0f, 0f, bw, bh * 0.5f, sheen)
        canvas.drawRect(0f, bh * 0.55f, bw, bh, glow)
        canvas.restore()
        canvas.drawRoundRect(rect, r, r, rim)
        if (hud) canvas.drawLines(ticks, tick)
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Fundo: preto com manchas de luz laranja, chuva de código, ondas de água e linhas de varrimento. */
class FxBackground(context: Context) : View(context) {

    private class Col(var y: Float, var speed: Float, var len: Int) {
        val chars = CharArray(18)
    }

    private class Blob(
        val color: Int,
        val fx: Float, val fy: Float,
        val ax: Float, val ay: Float,
        val rad: Float, val k: Float, val ph: Float
    ) {
        var shader: Shader? = null
        var r = 0f
    }

    private val d = context.resources.displayMetrics.density
    private val glyphs = "01ABCDEF<>/{}[]#\$%&*+=;:"
    private val rnd = Random(11)
    private val blobs = listOf(
        Blob(Color.rgb(255, 106, 0), 0.18f, 0.14f, 0.16f, 0.07f, 0.70f, 0.55f, 0.0f),
        Blob(Color.rgb(255, 160, 40), 0.92f, 0.38f, 0.12f, 0.09f, 0.60f, 0.42f, 2.1f),
        Blob(Color.rgb(200, 50, 0), 0.25f, 0.78f, 0.15f, 0.08f, 0.66f, 0.50f, 4.0f),
        Blob(Color.rgb(255, 120, 20), 0.90f, 0.95f, 0.12f, 0.06f, 0.55f, 0.35f, 5.2f)
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val waveFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val crest = Paint(Paint.ANTI_ALIAS_FLAG)
    private val overlay = Paint()
    private val fillPath = Path()
    private val crestPath = Path()
    private var cols: Array<Col> = emptyArray()
    private var colW = 15f * d
    private var lineH = 15f * d
    private var last = 0L
    private var t = 0f
    private var vignette: Shader? = null
    private var scan: Shader? = null

    init {
        crest.style = Paint.Style.STROKE
        crest.strokeWidth = 1.5f * d
        crest.color = Color.argb(85, 255, 150, 50)
    }

    private fun newCol(h: Float, anywhere: Boolean): Col {
        val c = Col(
            if (anywhere) rnd.nextFloat() * h else -rnd.nextFloat() * h * 0.4f,
            (40f + rnd.nextFloat() * 90f) * d,
            6 + rnd.nextInt(10)
        )
        for (i in c.chars.indices) c.chars[i] = glyphs[rnd.nextInt(glyphs.length)]
        return c
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        colW = 15f * d
        lineH = 15f * d
        textPaint.textSize = 12f * d
        textPaint.typeface = Fonts.mono
        val n = (w / colW).toInt() + 1
        cols = Array(n) { newCol(h.toFloat(), true) }
        val base = max(w, h).toFloat()
        for (b in blobs) {
            b.r = b.rad * base
            b.shader = RadialGradient(
                0f, 0f, b.r,
                intArrayOf(
                    Color.argb(92, Color.red(b.color), Color.green(b.color), Color.blue(b.color)),
                    Color.argb(0, Color.red(b.color), Color.green(b.color), Color.blue(b.color))
                ),
                null, Shader.TileMode.CLAMP
            )
        }
        vignette = RadialGradient(
            w / 2f, h * 0.45f, base * 0.8f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(215, 0, 0, 0)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        val tile = Bitmap.createBitmap(1, max(2, (3f * d).toInt()), Bitmap.Config.ARGB_8888)
        tile.setPixel(0, 0, Color.argb(20, 255, 255, 255))
        scan = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        waveFill.shader = LinearGradient(
            0f, h * 0.84f, 0f, h.toFloat(),
            Color.argb(52, 255, 110, 20), Color.argb(0, 255, 110, 20), Shader.TileMode.CLAMP
        )
    }

    private fun wave(canvas: Canvas, w: Float, h: Float, base: Float, amp: Float, freq: Float, phase: Float, withCrest: Boolean) {
        fillPath.reset()
        crestPath.reset()
        fillPath.moveTo(0f, h)
        var x = 0f
        var first = true
        while (x <= w + 14f) {
            val y = base + amp * sin(x / w * freq * 2f * PI.toFloat() + phase)
            fillPath.lineTo(x, y)
            if (first) crestPath.moveTo(x, y) else crestPath.lineTo(x, y)
            first = false
            x += 14f
        }
        fillPath.lineTo(w + 14f, h)
        fillPath.close()
        canvas.drawPath(fillPath, waveFill)
        if (withCrest) canvas.drawPath(crestPath, crest)
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1_000_000_000f)
        last = now
        t += dt
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawColor(Palette.BG)
        val fx = try {
            Store.fx
        } catch (e: Exception) {
            true
        }

        for (b in blobs) {
            val cx = (b.fx + b.ax * sin(t * b.k + b.ph)) * w
            val cy = (b.fy + b.ay * cos(t * b.k * 0.8f + b.ph)) * h
            canvas.save()
            canvas.translate(cx, cy)
            paint.shader = b.shader
            canvas.drawCircle(0f, 0f, b.r, paint)
            canvas.restore()
        }

        if (!fx) {
            overlay.shader = vignette
            canvas.drawRect(0f, 0f, w, h, overlay)
            return
        }

        for (i in cols.indices) {
            val c = cols[i]
            c.y += c.speed * dt
            if (c.y - c.len * lineH > h) {
                c.y = -rnd.nextFloat() * h * 0.4f
                c.speed = (40f + rnd.nextFloat() * 90f) * d
                c.len = 6 + rnd.nextInt(10)
            }
            if (rnd.nextInt(6) == 0) c.chars[rnd.nextInt(c.chars.size)] = glyphs[rnd.nextInt(glyphs.length)]
            val x = i * colW + 2f * d
            for (k in 0 until c.len) {
                val y = c.y - k * lineH
                if (y < -lineH || y > h + lineH) continue
                if (k == 0) {
                    textPaint.color = Color.argb(175, 255, 226, 194)
                } else {
                    val a = ((1f - k.toFloat() / c.len) * 72f).toInt()
                    textPaint.color = Color.argb(a, 255, 122, 26)
                }
                canvas.drawText(c.chars, k % c.chars.size, 1, x, y, textPaint)
            }
        }

        wave(canvas, w, h, h * 0.90f, 8f * d, 2.2f, t * 0.9f, true)
        wave(canvas, w, h, h * 0.935f, 6f * d, 3.1f, -t * 0.7f + 1f, false)

        overlay.shader = vignette
        canvas.drawRect(0f, 0f, w, h, overlay)
        overlay.shader = scan
        canvas.drawRect(0f, 0f, w, h, overlay)
        postInvalidateOnAnimation()
    }
}

/** Logótipo: o "E" cromado laranja sobre um quadrado de vidro. */
class LogoView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val bg = GlassDrawable(d, 18f, accent = false, hud = false, strength = 1.3f)
    private val logo: Bitmap? = try {
        BitmapFactory.decodeResource(context.resources, R.drawable.logo_e)
    } catch (e: Throwable) {
        null
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = RectF()
    private val breathe = ValueAnimator.ofFloat(0.96f, 1.04f)
    private var k = 1f

    init {
        breathe.duration = 1800
        breathe.repeatCount = ValueAnimator.INFINITE
        breathe.repeatMode = ValueAnimator.REVERSE
        breathe.addUpdateListener {
            k = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        breathe.start()
    }

    override fun onDetachedFromWindow() {
        breathe.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bg.setBounds(0, 0, w, h)
    }

    override fun onDraw(canvas: Canvas) {
        bg.draw(canvas)
        val b = logo ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val box = min(w, h) * 0.66f * k
        val ratio = b.width.toFloat() / b.height.toFloat()
        var dw = box
        var dh = box / ratio
        if (dh > box) {
            dh = box
            dw = box * ratio
        }
        src.set(0, 0, b.width, b.height)
        dst.set((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
        canvas.drawBitmap(b, src, dst, paint)
    }
}

/** Barra de abas flutuante em vidro; a "lente" laranja estica e salta ao mudar de aba. */
class TabBar(
    context: Context,
    private val labels: List<String>,
    private val onSelect: (Int) -> Unit
) : View(context) {

    private val d = context.resources.displayMetrics.density
    private val bg = GlassDrawable(d, 30f, accent = false, hud = false, strength = 1.15f)
    private val back = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(205, 6, 4, 2) }
    private val pillFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillRim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val arc = RectF()
    private val pillRect = RectF()
    private val pad = 8f * d
    private var pillX = 0f
    private var anim: ValueAnimator? = null

    var selected = 0
        private set

    init {
        pillFill.color = Color.argb(78, 255, 122, 26)
        pillRim.style = Paint.Style.STROKE
        pillRim.strokeWidth = 1.2f * d
        pillRim.color = Color.argb(170, 255, 175, 95)
        iconPaint.style = Paint.Style.STROKE
        iconPaint.strokeWidth = 2f * d
        iconPaint.strokeCap = Paint.Cap.ROUND
        iconPaint.strokeJoin = Paint.Join.ROUND
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 9.5f * d
        textPaint.letterSpacing = 0.06f
    }

    private fun cellW(): Float = (width - 2f * pad) / labels.size

    private fun targetX(i: Int): Float = pad + cellW() * i

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (68f * d).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bg.setBounds(0, 0, w, h)
        textPaint.typeface = Fonts.monoBold
        pillX = targetX(selected)
    }

    fun select(i: Int, animate: Boolean = true) {
        if (i == selected) return
        tick()
        val from = pillX
        selected = i
        val to = targetX(i)
        anim?.cancel()
        if (!animate || width == 0) {
            pillX = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 820
        a.interpolator = Elastic(0.5f, 6.5f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            pillX = from + (to - from) * f
            invalidate()
        }
        anim = a
        a.start()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 30f * d, 30f * d, back)
        bg.draw(canvas)
        val cw = cellW()
        val extra = min(0.55f, abs(targetX(selected) - pillX) / cw * 0.28f)
        val pw = cw * (1f + extra)
        val left = pillX - (pw - cw) / 2f
        pillRect.set(left, 7f * d, left + pw, height - 7f * d)
        canvas.drawRoundRect(pillRect, 24f * d, 24f * d, pillFill)
        canvas.drawRoundRect(pillRect, 24f * d, 24f * d, pillRim)

        for (i in labels.indices) {
            val cx = pad + cw * i + cw / 2f
            val sel = i == selected
            val color = if (sel) Color.WHITE else Palette.FAINT
            iconPaint.color = color
            textPaint.color = if (sel) Palette.CREAM else Palette.FAINT
            drawIcon(canvas, i, cx, height * 0.37f, 9.5f * d)
            canvas.drawText(labels[i], cx, height * 0.82f, textPaint)
        }
    }

    private fun drawIcon(c: Canvas, i: Int, cx: Float, cy: Float, s: Float) {
        val p = iconPaint
        path.reset()
        when (i) {
            0 -> {
                path.moveTo(cx - s, cy)
                path.lineTo(cx, cy - s)
                path.lineTo(cx + s, cy)
                path.moveTo(cx - s * 0.72f, cy - s * 0.12f)
                path.lineTo(cx - s * 0.72f, cy + s * 0.9f)
                path.lineTo(cx + s * 0.72f, cy + s * 0.9f)
                path.lineTo(cx + s * 0.72f, cy - s * 0.12f)
                c.drawPath(path, p)
            }
            1 -> {
                c.drawCircle(cx, cy - s * 0.42f, s * 0.4f, p)
                arc.set(cx - s * 0.9f, cy + s * 0.1f, cx + s * 0.9f, cy + s * 1.8f)
                c.drawArc(arc, 180f, 180f, false, p)
            }
            2 -> {
                path.moveTo(cx - s, cy - s * 0.55f)
                path.lineTo(cx - s * 0.25f, cy)
                path.lineTo(cx - s, cy + s * 0.55f)
                path.moveTo(cx + s * 0.05f, cy + s * 0.7f)
                path.lineTo(cx + s, cy + s * 0.7f)
                c.drawPath(path, p)
            }
            else -> {
                for (k in -1..1) {
                    val y = cy + k * s * 0.7f
                    c.drawLine(cx - s, y, cx + s, y, p)
                    val kx = cx + s * (if (k == -1) -0.35f else if (k == 0) 0.4f else -0.05f)
                    c.drawCircle(kx, y, s * 0.26f, p)
                }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val i = ((e.x - pad) / cellW()).toInt().coerceIn(0, labels.size - 1)
                if (i != selected) {
                    select(i)
                    onSelect(i)
                }
                performClick()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean = super.performClick()
}

/** Interruptor de vidro: a bolinha estica e salta ao mudar. */
class GlassSwitch(
    context: Context,
    initial: Boolean,
    private val onChange: (Boolean) -> Unit
) : View(context) {

    private val d = context.resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val evaluator = ArgbEvaluator()
    private val box = RectF()
    private var pos = if (initial) 1f else 0f
    private var anim: ValueAnimator? = null

    var checked = initial
        private set

    init {
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = 1.2f * d
        rim.color = Color.argb(150, 255, 255, 255)
        thumb.color = Color.WHITE
        setOnClickListener { toggle() }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((58f * d).toInt(), (34f * d).toInt())
    }

    fun set(value: Boolean, animate: Boolean) {
        if (value == checked) return
        checked = value
        val from = pos
        val to = if (value) 1f else 0f
        anim?.cancel()
        if (!animate) {
            pos = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 640
        a.interpolator = Elastic(0.46f, 7f)
        a.addUpdateListener {
            pos = from + (to - from) * (it.animatedValue as Float)
            invalidate()
        }
        anim = a
        a.start()
    }

    private fun toggle() {
        tick()
        set(!checked, true)
        onChange(checked)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val p = pos.coerceIn(0f, 1f)
        track.color = evaluator.evaluate(p, Color.argb(64, 255, 255, 255), Color.argb(238, 255, 122, 26)) as Int
        box.set(1f * d, 1f * d, w - 1f * d, h - 1f * d)
        canvas.drawRoundRect(box, h / 2f, h / 2f, track)
        canvas.drawRoundRect(box, h / 2f, h / 2f, rim)
        val rad = h / 2f - 5f * d
        val target = if (checked) 1f else 0f
        val stretch = 1f + min(0.55f, abs(pos - target) * 0.9f)
        val travel = w - h
        val cx = (h / 2f + travel * pos).coerceIn(h / 2f - 3f * d, w - h / 2f + 3f * d)
        box.set(cx - rad * stretch, h / 2f - rad, cx + rad * stretch, h / 2f + rad)
        canvas.drawRoundRect(box, rad, rad, thumb)
    }
}

/** Seletor de vidro com uma lente laranja elástica. */
class Segmented(
    context: Context,
    private val options: List<String>,
    initial: Int,
    private val onPick: (Int) -> Unit
) : View(context) {

    private val d = context.resources.displayMetrics.density
    private val bg = GlassDrawable(d, 22f, accent = false, hud = false, strength = 1f)
    private val pillFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillRim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pillRect = RectF()
    private val pad = 5f * d
    private var selected = initial
    private var pillX = 0f
    private var anim: ValueAnimator? = null

    init {
        pillFill.color = Color.argb(150, 255, 122, 26)
        pillRim.style = Paint.Style.STROKE
        pillRim.strokeWidth = 1.2f * d
        pillRim.color = Color.argb(190, 255, 190, 120)
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 12f * d
    }

    private fun cellW(): Float = (width - 2f * pad) / options.size

    private fun targetX(i: Int): Float = pad + cellW() * i

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (46f * d).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bg.setBounds(0, 0, w, h)
        textPaint.typeface = Fonts.monoBold
        pillX = targetX(selected)
    }

    private fun choose(i: Int) {
        if (i == selected) return
        tick()
        val from = pillX
        selected = i
        val to = targetX(i)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 780
        a.interpolator = Elastic(0.5f, 6.5f)
        a.addUpdateListener {
            pillX = from + (to - from) * (it.animatedValue as Float)
            invalidate()
        }
        anim = a
        a.start()
        onPick(i)
    }

    override fun onDraw(canvas: Canvas) {
        bg.draw(canvas)
        val cw = cellW()
        val extra = min(0.5f, abs(targetX(selected) - pillX) / cw * 0.3f)
        val pw = cw * (1f + extra)
        val left = pillX - (pw - cw) / 2f
        pillRect.set(left, pad, left + pw, height - pad)
        canvas.drawRoundRect(pillRect, 18f * d, 18f * d, pillFill)
        canvas.drawRoundRect(pillRect, 18f * d, 18f * d, pillRim)
        val y = height / 2f - (textPaint.ascent() + textPaint.descent()) / 2f
        for (i in options.indices) {
            textPaint.color = if (i == selected) Color.WHITE else Palette.FAINT
            canvas.drawText(options[i], pad + cw * i + cw / 2f, y, textPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                choose(((e.x - pad) / cellW()).toInt().coerceIn(0, options.size - 1))
                performClick()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean = super.performClick()
}

/** Ondas concêntricas que se expandem (gota de água), usadas no pedido recebido. */
class RippleView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private var f = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f)

    init {
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 2f * d
        anim.duration = 3200
        anim.repeatCount = ValueAnimator.INFINITE
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener {
            f = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val rMin = min(width, height) * 0.2f
        val rMax = min(width, height) * 0.5f
        for (k in 0..2) {
            val ph = (f + k / 3f) % 1f
            val r = rMin + (rMax - rMin) * ph
            val a = ((1f - ph) * (1f - ph) * 200f).toInt()
            ring.color = Color.argb(a, 255, 122, 26)
            fill.color = Color.argb(a / 7, 255, 122, 26)
            canvas.drawCircle(cx, cy, r, fill)
            canvas.drawCircle(cx, cy, r, ring)
        }
    }
}

/** Avatares: quadrados arredondados com degradê laranja e a inicial do nome. */
object Avatars {
    private val pairs = listOf(
        Pair("#FF9A3D", "#FF4D00"),
        Pair("#FFC86B", "#FF8A1F"),
        Pair("#FF7A59", "#C2410C"),
        Pair("#FFD08A", "#F59E0B"),
        Pair("#FFB27A", "#E85D04")
    )

    fun style(view: TextView, name: String, radiusDp: Int = 14) {
        val pair = pairs[(name.hashCode() and 0x7fffffff) % pairs.size]
        val shape = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor(pair.first), Color.parseColor(pair.second))
        )
        shape.cornerRadius = radiusDp * view.resources.displayMetrics.density
        shape.setStroke((1.2f * view.resources.displayMetrics.density).toInt(), Color.argb(150, 255, 255, 255))
        view.background = shape
        view.text = name.trim().take(1).uppercase()
    }
}

/** Camada por cima de tudo: gotas que escorrem pelo vidro, a partir de onde o dedo toca e passa. */
class WaterLayer(context: Context) : View(context) {
    private class Bead(val x0: Float, val y0: Float, val r: Float, val t0: Long, val delay: Float, val ph: Float) {
        var x = x0
        var y = y0
        var v = 0f
    }

    private val d = context.resources.displayMetrics.density
    private val rnd = Random(5)
    private val beads = ArrayList<Bead>()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val trail = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var last = 0L
    private var lastX = 0f
    private var lastY = 0f
    private val life = 1.8f

    init {
        isClickable = false
        isFocusable = false
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = 1f * d
        trail.style = Paint.Style.STROKE
        trail.strokeCap = Paint.Cap.ROUND
        trail.strokeWidth = 1.3f * d
    }

    private fun spawn(x: Float, y: Float, r: Float) {
        if (beads.size >= 22) beads.removeAt(0)
        beads.add(Bead(x + (rnd.nextFloat() - 0.5f) * 6f * d, y, r, System.nanoTime(), 0.1f + rnd.nextFloat() * 0.25f, rnd.nextFloat() * 6.28f))
        invalidate()
    }

    /** Recebe os toques da janela (qualquer sítio do ecrã). */
    fun touch(e: MotionEvent) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val x = e.rawX - loc[0]
        val y = e.rawY - loc[1]
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                spawn(x, y, 4.6f * d)
                lastX = x
                lastY = y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = x - lastX
                val dy = y - lastY
                if (dx * dx + dy * dy > (40f * d) * (40f * d)) {
                    spawn(x, y, (2.2f + rnd.nextFloat() * 1.8f) * d)
                    lastX = x
                    lastY = y
                }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1_000_000_000f)
        last = now
        val h = height.toFloat()
        val it = beads.iterator()
        while (it.hasNext()) {
            val b = it.next()
            val age = (now - b.t0) / 1_000_000_000f
            if (age > life || b.y > h + 20f * d) {
                it.remove()
                continue
            }
            if (age > b.delay) {
                b.v = min(b.v + 330f * d * (0.6f + b.r / (6f * d)) * dt, 480f * d)
                b.y += b.v * dt
                b.x = b.x0 + sin(age * 5f + b.ph) * 0.9f * d
            }
            val a = min(1f, (life - age) / 0.6f)
            if (b.y > b.y0 + 2f * d) {
                trail.shader = LinearGradient(
                    0f, b.y0, 0f, b.y,
                    Color.argb(0, 255, 255, 255), Color.argb((a * 55).toInt(), 255, 220, 190), Shader.TileMode.CLAMP
                )
                canvas.drawLine(b.x0, b.y0, b.x, b.y, trail)
            }
            val stretch = 1f + min(b.v / (900f * d), 0.4f)
            val rw = b.r * 0.9f
            val rh = b.r * stretch
            oval.set(b.x - rw, b.y - rh, b.x + rw, b.y + rh)
            fill.shader = RadialGradient(
                b.x - rw * 0.35f, b.y - rh * 0.4f, rh * 1.5f,
                Color.argb((a * 120).toInt(), 255, 255, 255), Color.argb((a * 28).toInt(), 255, 150, 60),
                Shader.TileMode.CLAMP
            )
            canvas.drawOval(oval, fill)
            rim.color = Color.argb((a * 130).toInt(), 255, 205, 150)
            canvas.drawOval(oval, rim)
            dot.color = Color.argb((a * 200).toInt(), 255, 255, 255)
            canvas.drawCircle(b.x - rw * 0.35f, b.y - rh * 0.45f, max(0.8f * d, rw * 0.22f), dot)
        }
        if (beads.isNotEmpty()) postInvalidateOnAnimation()
    }
}
