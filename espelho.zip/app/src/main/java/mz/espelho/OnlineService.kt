package mz.espelho

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONObject

/**
 * Mantém o celular na lista de pessoas e recebe os pedidos de quem quer ver a tela.
 * Nada é partilhado sem a pessoa tocar em "Permitir" e aceitar o aviso do Android.
 */
class OnlineService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var dir: NtfyListener? = null
    private var inbox: NtfyListener? = null

    private val beat = object : Runnable {
        override fun run() {
            sendHello()
            main.postDelayed(this, 30000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        Online.load(this)
        if (Online.myName.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Online.running) {
            sendHello()
            return START_STICKY
        }
        Online.running = true

        dir = NtfyListener(Online.DIR, "2m") { m, t -> main.post { onHello(m, t) } }
        dir?.start()
        inbox = NtfyListener(Online.inbox(Online.myId), "30s") { m, t -> main.post { onInbox(m, t) } }
        inbox?.start()
        main.post(beat)
        return START_STICKY
    }

    private fun startAsForeground(): Boolean {
        return try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ONLINE, "Espelho visk online", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val stop = PendingIntent.getService(
                this, 3, Intent(this, OnlineService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            val notification = Notification.Builder(this, CHANNEL_ONLINE)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Espelho visk online")
                .setContentText("Só partilha a sua tela se você permitir.")
                .setContentIntent(open)
                .addAction(0, "Ficar offline", stop)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ONLINE, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ONLINE, notification)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun sendHello() {
        if (Online.myName.isEmpty()) return
        Ntfy.send(
            Online.DIR,
            JSONObject().put("t", "hello").put("id", Online.myId).put("name", Online.myName)
        )
    }

    private fun onHello(m: JSONObject, time: Long) {
        if (Ntfy.ageSeconds(time) > 100) return
        val id = m.optString("id")
        if (m.optString("t") != "hello" || id.isEmpty() || id == Online.myId) return
        val name = m.optString("name").trim().take(24)
        if (name.isEmpty()) return
        Online.people[id] = Person(id, name, System.currentTimeMillis())
        Online.changed()
    }

    private fun onInbox(m: JSONObject, time: Long) {
        if (Ntfy.ageSeconds(time) > 60) return
        val from = m.optString("from")
        if (from.isEmpty()) return
        when (m.optString("t")) {
            "req" -> onRequest(from, m.optString("name").trim().take(24))
            "deny", "offer", "byes" -> Online.viewerHandler?.invoke(m)
            "answer", "byev" -> Online.shareHandler?.invoke(m)
        }
    }

    private fun onRequest(from: String, name: String) {
        if (ShareState.active || Online.incoming != null) {
            Online.send(from, JSONObject().put("t", "deny").put("why", "busy"))
            return
        }
        val shown = name.ifEmpty { "Alguém" }
        Online.incoming = Request(from, shown)
        notifyRequest(shown)
        Online.changed()
        main.postDelayed({
            val current = Online.incoming
            if (current != null && current.id == from) {
                Online.incoming = null
                getSystemService(NotificationManager::class.java).cancel(NOTIF_REQUEST)
                Online.changed()
            }
        }, 60000)
    }

    private fun notifyRequest(name: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_REQUEST, "Pedidos para ver a tela", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            this, 2,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_REQUEST)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("$name quer ver a sua tela")
            .setContentText("Toque para permitir ou recusar.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_REQUEST, notification)
    }

    override fun onDestroy() {
        Online.running = false
        main.removeCallbacksAndMessages(null)
        dir?.stop()
        inbox?.stop()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "mz.espelho.ONLINE_STOP"
        const val NOTIF_REQUEST = 2
        private const val CHANNEL_ONLINE = "online"
        private const val CHANNEL_REQUEST = "pedidos"
        private const val NOTIF_ONLINE = 3
    }
}
