package mz.espelho

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

class MainActivity : Activity() {

    private val white = Color.WHITE
    private val soft = Color.argb(190, 255, 255, 255)
    private val faint = Color.argb(125, 255, 255, 255)
    private val bad = Color.parseColor("#FF9A8F")
    private val good = Color.parseColor("#6EE7B7")
    private val warn = Color.parseColor("#FCD34D")
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var nameGroup: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var idleGroup: LinearLayout
    private lateinit var helloText: TextView
    private lateinit var onlinePill: TextView
    private lateinit var peoplePanel: LinearLayout
    private lateinit var peopleList: LinearLayout
    private lateinit var peopleEmptyCard: LinearLayout
    private lateinit var requestPanel: LinearLayout
    private lateinit var requestAvatar: TextView
    private lateinit var requestText: TextView
    private lateinit var sharePanel: LinearLayout
    private lateinit var shareWith: TextView
    private lateinit var shareStatus: TextView
    private lateinit var homeMessage: TextView
    private lateinit var viewerLayer: FrameLayout
    private lateinit var viewerHost: FrameLayout
    private lateinit var viewerStatus: TextView

    private var viewer: ViewerSession? = null
    private var finding = false
    private var editingName = false
    private var pendingAllow: Request? = null
    private var peopleSig = "\u0000"

    private val ticker = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (finding) showPeople()
            refreshPill()
            ticker.postDelayed(this, 5000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Glass.BG
        window.navigationBarColor = Glass.BG
        Online.load(this)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        val changed = { runOnUiThread { refresh() } }
        ShareState.onChange = changed
        Online.onChange = changed
        startOnline()
        ticker.post(tick)
        refresh()
    }

    override fun onPause() {
        ShareState.onChange = null
        Online.onChange = null
        ticker.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        viewer?.close()
        viewer = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            viewer != null -> closeViewer()
            finding -> {
                finding = false
                refresh()
            }
            editingName && Online.myName.isNotEmpty() -> {
                editingName = false
                refresh()
            }
            else -> super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------- online

    private fun startOnline() {
        if (Online.myName.isEmpty()) return
        try {
            startForegroundService(Intent(this, OnlineService::class.java))
        } catch (e: Exception) {
            showHomeMessage("Não foi possível ficar online (${e.javaClass.simpleName}).")
        }
    }

    private fun saveName() {
        val name = nameInput.text.toString().trim()
        if (name.isEmpty()) {
            showHomeMessage("Escreva o seu nome.")
            return
        }
        hideKeyboard()
        Online.saveName(this, name)
        editingName = false
        homeMessage.visibility = View.GONE
        startOnline()
        refresh()
    }

    // ---------------------------------------------------------------- receber pedidos

    private fun allow() {
        val request = Online.incoming ?: return
        pendingAllow = request
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    private fun deny() {
        val request = Online.incoming ?: return
        Online.send(request.id, JSONObject().put("t", "deny"))
        clearIncoming()
    }

    private fun clearIncoming() {
        Online.incoming = null
        getSystemService(NotificationManager::class.java).cancel(OnlineService.NOTIF_REQUEST)
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        val request = pendingAllow
        pendingAllow = null
        if (request == null) return
        if (resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ShareService::class.java)
                .putExtra(ShareService.EXTRA_DATA, data)
                .putExtra(ShareService.EXTRA_VID, request.id)
                .putExtra(ShareService.EXTRA_VNAME, request.name)
            ShareState.status = ""
            startForegroundService(intent)
            clearIncoming()
        } else {
            Online.send(request.id, JSONObject().put("t", "deny"))
            clearIncoming()
        }
    }

    private fun stopShare() {
        stopService(Intent(this, ShareService::class.java))
    }

    // ---------------------------------------------------------------- ver a tela de alguém

    private fun showPeople() {
        val now = System.currentTimeMillis()
        val list = Online.people.values
            .filter { now - it.seen < 100_000 }
            .sortedBy { it.name.lowercase() }
        val sig = list.joinToString("|") { it.id + it.name }
        if (sig == peopleSig) return
        peopleSig = sig
        peopleList.removeAllViews()
        list.forEachIndexed { i, person ->
            val row = personRow(person)
            peopleList.addView(row, lp(10))
            row.alpha = 0f
            row.translationY = dp(14).toFloat()
            row.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 60L).setDuration(320)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
        peopleEmptyCard.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun connectTo(person: Person) {
        finding = false
        try {
            Rtc.init(this)
        } catch (e: Throwable) {
            showHomeMessage("Este celular não suporta a ligação de vídeo (${e.javaClass.simpleName}).")
            refresh()
            return
        }
        val renderer = SurfaceViewRenderer(this)
        renderer.init(Rtc.eglBase.eglBaseContext, null)
        renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        viewerHost.removeAllViews()
        viewerHost.addView(renderer, FrameLayout.LayoutParams(match, match))
        setViewerStatus("")
        viewerLayer.alpha = 0f
        viewerLayer.visibility = View.VISIBLE
        viewerLayer.animate().alpha(1f).setDuration(260).start()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val session = ViewerSession(person, renderer) { message -> runOnUiThread { setViewerStatus(message) } }
        viewer = session
        session.start()
        refresh()
    }

    private fun closeViewer() {
        viewer?.close()
        viewer = null
        viewerHost.removeAllViews()
        viewerLayer.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setViewerStatus(message: String) {
        viewerStatus.text = message
        viewerStatus.visibility = if (message.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------- estado do ecrã

    /** Mostra com uma entrada suave (sobe e aparece); esconde de imediato. */
    private fun setVis(v: View, show: Boolean) {
        if (show) {
            if (v.visibility != View.VISIBLE) {
                v.animate().cancel()
                v.alpha = 0f
                v.translationY = dp(18).toFloat()
                v.visibility = View.VISIBLE
                v.animate().alpha(1f).translationY(0f).setDuration(340)
                    .setInterpolator(DecelerateInterpolator(1.8f)).start()
            }
        } else if (v.visibility != View.GONE) {
            v.animate().cancel()
            v.visibility = View.GONE
        }
    }

    private fun refresh() {
        val sharing = ShareState.active
        val request = Online.incoming
        val needName = Online.myName.isEmpty() || editingName
        val free = !sharing && request == null

        setVis(nameGroup, free && needName)
        setVis(idleGroup, free && !needName && !finding)
        setVis(peoplePanel, free && !needName && finding)
        setVis(requestPanel, !sharing && request != null)
        setVis(sharePanel, sharing)

        helloText.text = "Olá, ${Online.myName}"
        val requester = request?.name.orEmpty()
        requestText.text = "$requester quer ver a sua tela."
        styleAvatar(requestAvatar, requester)
        shareWith.text = ShareState.name
        shareStatus.text = ShareState.status
        refreshPill()
        if (finding) showPeople()

        if (!sharing && ShareState.status.isNotEmpty()) {
            showHomeMessage(ShareState.status)
        } else if (sharing) {
            homeMessage.visibility = View.GONE
        }
    }

    private fun refreshPill() {
        if (Online.running) {
            onlinePill.text = "●  Online"
            onlinePill.setTextColor(good)
        } else {
            onlinePill.text = "●  A ligar…"
            onlinePill.setTextColor(warn)
        }
    }

    private fun showHomeMessage(message: String) {
        homeMessage.text = message
        homeMessage.visibility = View.VISIBLE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(nameInput.windowToken, 0)
    }

    // ---------------------------------------------------------------- peças visuais

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun lp(topMargin: Int = 0): LinearLayout.LayoutParams {
        val params = LinearLayout.LayoutParams(match, wrap)
        params.topMargin = dp(topMargin)
        return params
    }

    private fun label(text: String, size: Float, color: Int, medium: Boolean = false): TextView {
        val view = TextView(this)
        view.text = text
        view.textSize = size
        view.setTextColor(color)
        view.typeface = Typeface.create(if (medium) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        return view
    }

    private fun glassCard(pad: Int = 20): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = Glass.card(this)
        card.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        return card
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): Button {
        val view = Button(this)
        view.text = text
        view.isAllCaps = false
        view.textSize = 17f
        view.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        view.setTextColor(white)
        view.stateListAnimator = null
        view.elevation = 0f
        view.background = if (primary) Glass.accent(this) else Glass.card(this, 26f, 22)
        view.setPadding(dp(16), dp(16), dp(16), dp(16))
        view.setOnClickListener { onClick() }
        Glass.pressable(view)
        return view
    }

    private val avatarColors = listOf(
        Pair("#22D3EE", "#3B82F6"),
        Pair("#A78BFA", "#EC4899"),
        Pair("#34D399", "#06B6D4"),
        Pair("#FBBF24", "#F472B6")
    )

    private fun styleAvatar(view: TextView, name: String) {
        val pair = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
        view.background = Glass.circle(Color.parseColor(pair.first), Color.parseColor(pair.second))
        view.text = name.trim().take(1).uppercase()
    }

    private fun avatar(name: String, sizeDp: Int, textSp: Float): TextView {
        val view = TextView(this)
        view.gravity = Gravity.CENTER
        view.textSize = textSp
        view.setTextColor(white)
        view.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        view.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        styleAvatar(view, name)
        return view
    }

    private fun personRow(person: Person): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Glass.card(this, 24f, 26)
        row.setPadding(dp(14), dp(14), dp(18), dp(14))
        row.addView(avatar(person.name, 46, 19f))
        val name = label(person.name, 18f, white, true)
        name.setPadding(dp(14), 0, 0, 0)
        row.addView(name, LinearLayout.LayoutParams(0, wrap, 1f))
        row.addView(label("›", 26f, faint))
        row.setOnClickListener { connectTo(person) }
        Glass.pressable(row)
        return row
    }

    private fun pill(text: String, color: Int): TextView {
        val view = label(text, 13f, color, true)
        view.background = Glass.card(this, 20f, 22)
        view.setPadding(dp(14), dp(7), dp(14), dp(7))
        return view
    }

    private fun buildUi() {
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(22), dp(26), dp(22), dp(28))

        // --- cabeçalho com o logótipo
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(LogoView(this), LinearLayout.LayoutParams(dp(58), dp(58)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(16), 0, 0, 0)
        titles.addView(label("Espelho Visk", 26f, white, true))
        titles.addView(label("Veja outra tela, só com permissão.", 13f, soft), lp(2))
        header.addView(titles, LinearLayout.LayoutParams(0, wrap, 1f))
        column.addView(header, lp())

        // --- primeira vez: escolher o nome
        nameGroup = glassCard()
        nameGroup.visibility = View.GONE
        nameGroup.addView(label("Como se chama?", 22f, white, true))
        nameGroup.addView(
            label("Este nome aparece na lista das outras pessoas que têm o Espelho Visk.", 14f, soft),
            lp(6)
        )
        nameInput = EditText(this)
        nameInput.hint = "O seu nome"
        nameInput.setHintTextColor(faint)
        nameInput.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(24))
        nameInput.textSize = 20f
        nameInput.setTextColor(white)
        nameInput.setSingleLine()
        nameInput.background = Glass.card(this, 18f, 16)
        nameInput.setPadding(dp(18), dp(14), dp(18), dp(14))
        nameInput.setText(Online.myName)
        nameGroup.addView(nameInput, lp(18))
        nameGroup.addView(button("Continuar", true) { saveName() }, lp(16))
        column.addView(nameGroup, lp(30))

        // --- normal
        idleGroup = LinearLayout(this)
        idleGroup.orientation = LinearLayout.VERTICAL
        idleGroup.visibility = View.GONE
        helloText = label("", 30f, white, true)
        idleGroup.addView(helloText, lp(34))
        onlinePill = pill("●  A ligar…", warn)
        idleGroup.addView(onlinePill, LinearLayout.LayoutParams(wrap, wrap).also { it.topMargin = dp(12) })
        idleGroup.addView(button("Ver a tela de alguém", true) {
            finding = true
            peopleSig = "\u0000"
            homeMessage.visibility = View.GONE
            refresh()
        }, lp(26))
        val info = glassCard(18)
        info.addView(
            label(
                "Para alguém ver a sua tela, basta ter o Espelho Visk instalado e esta app ligada. " +
                    "Quando alguém pedir, aparece um aviso e você escolhe Permitir ou Recusar.",
                14f, soft
            )
        )
        idleGroup.addView(info, lp(18))
        idleGroup.addView(button("Mudar o meu nome", false) {
            editingName = true
            nameInput.setText(Online.myName)
            refresh()
        }, lp(14))
        column.addView(idleGroup, lp())

        // --- lista de pessoas
        peoplePanel = LinearLayout(this)
        peoplePanel.orientation = LinearLayout.VERTICAL
        peoplePanel.visibility = View.GONE
        peoplePanel.addView(label("Pessoas ligadas", 24f, white, true), lp(34))
        peopleEmptyCard = glassCard(18)
        peopleEmptyCard.addView(
            label(
                "Ainda ninguém. A outra pessoa tem de ter o Espelho Visk instalado e aberto, com internet.",
                15f, soft
            )
        )
        peoplePanel.addView(peopleEmptyCard, lp(14))
        peopleList = LinearLayout(this)
        peopleList.orientation = LinearLayout.VERTICAL
        peoplePanel.addView(peopleList, lp())
        peoplePanel.addView(button("Voltar", false) {
            finding = false
            refresh()
        }, lp(24))
        column.addView(peoplePanel, lp())

        // --- pedido recebido
        requestPanel = glassCard(24)
        requestPanel.visibility = View.GONE
        requestPanel.gravity = Gravity.CENTER_HORIZONTAL
        requestAvatar = avatar("?", 84, 34f)
        requestPanel.addView(requestAvatar)
        requestText = label("", 22f, white, true)
        requestText.gravity = Gravity.CENTER
        requestPanel.addView(requestText, lp(18))
        val askHint = label(
            "Se permitir, o Android vai pedir mais uma confirmação. Pode parar quando quiser.",
            14f, soft
        )
        askHint.gravity = Gravity.CENTER
        requestPanel.addView(askHint, lp(10))
        requestPanel.addView(button("Permitir", true) { allow() }, lp(24))
        requestPanel.addView(button("Recusar", false) { deny() }, lp(12))
        column.addView(requestPanel, lp(34))

        // --- a partilhar
        sharePanel = glassCard(24)
        sharePanel.visibility = View.GONE
        sharePanel.gravity = Gravity.CENTER_HORIZONTAL
        val live = pill("●  Ao vivo", bad)
        sharePanel.addView(live, LinearLayout.LayoutParams(wrap, wrap))
        pulse(live)
        val sharingWith = label("A partilhar a tela com", 15f, soft)
        sharingWith.gravity = Gravity.CENTER
        sharePanel.addView(sharingWith, lp(20))
        shareWith = label("", 30f, white, true)
        shareWith.gravity = Gravity.CENTER
        sharePanel.addView(shareWith, lp(4))
        shareStatus = label("", 15f, soft)
        shareStatus.gravity = Gravity.CENTER
        sharePanel.addView(shareStatus, lp(10))
        sharePanel.addView(button("Parar de partilhar", true) { stopShare() }, lp(26))
        column.addView(sharePanel, lp(34))

        homeMessage = label("", 15f, bad)
        homeMessage.gravity = Gravity.CENTER
        homeMessage.visibility = View.GONE
        column.addView(homeMessage, lp(20))

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(column, FrameLayout.LayoutParams(match, wrap))

        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(match, match))
        root.addView(scroll, FrameLayout.LayoutParams(match, match))

        // --- camada de visualização (por cima de tudo)
        viewerLayer = FrameLayout(this)
        viewerLayer.setBackgroundColor(Color.BLACK)
        viewerLayer.visibility = View.GONE
        viewerLayer.isClickable = true
        viewerHost = FrameLayout(this)
        viewerLayer.addView(viewerHost, FrameLayout.LayoutParams(match, match))
        viewerStatus = label("", 16f, white, true)
        viewerStatus.gravity = Gravity.CENTER
        viewerStatus.background = Glass.card(this, 24f, 30)
        viewerStatus.setPadding(dp(22), dp(18), dp(22), dp(18))
        val statusParams = FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER)
        statusParams.setMargins(dp(28), dp(28), dp(28), dp(28))
        viewerLayer.addView(viewerStatus, statusParams)
        val exit = button("Sair", false) { closeViewer() }
        val exitParams = FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END)
        exitParams.setMargins(dp(14), dp(14), dp(14), dp(14))
        viewerLayer.addView(exit, exitParams)
        root.addView(viewerLayer, FrameLayout.LayoutParams(match, match))

        setContentView(root)
    }

    /** O indicador "Ao vivo" respira devagar. */
    private fun pulse(view: View) {
        val animator = ObjectAnimator.ofFloat(view, View.ALPHA, 1f, 0.45f)
        animator.duration = 1100
        animator.repeatCount = ObjectAnimator.INFINITE
        animator.repeatMode = ObjectAnimator.REVERSE
        animator.interpolator = AccelerateDecelerateInterpolator()
        animator.start()
    }

    private companion object {
        const val REQ_CAPTURE = 42
    }
}
