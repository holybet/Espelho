package mz.espelho

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

class MainActivity : Activity() {

    private val blue = Color.parseColor("#1B6EF3")
    private val ink = Color.parseColor("#14213D")
    private val grey = Color.parseColor("#5B6475")
    private val red = Color.parseColor("#B42318")
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var nameGroup: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var idleGroup: LinearLayout
    private lateinit var helloText: TextView
    private lateinit var peoplePanel: LinearLayout
    private lateinit var peopleList: LinearLayout
    private lateinit var peopleEmpty: TextView
    private lateinit var requestPanel: LinearLayout
    private lateinit var requestText: TextView
    private lateinit var sharePanel: LinearLayout
    private lateinit var shareWith: TextView
    private lateinit var shareStatus: TextView
    private lateinit var homeMessage: TextView
    private lateinit var viewerLayer: FrameLayout
    private lateinit var viewerHost: FrameLayout
    private lateinit var viewerStatus: TextView

    private var viewer: ViewerSession? = null
    private var finding = false
    private var editingName = false
    private var pendingAllow: Request? = null

    private val ticker = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (finding) showPeople()
            ticker.postDelayed(this, 5000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Online.load(this)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        val changed = { runOnUiThread { refresh() } }
        ShareState.onChange = changed
        Online.onChange = changed
        startOnline()
        ticker.post(tick)
        refresh()
    }

    override fun onPause() {
        ShareState.onChange = null
        Online.onChange = null
        ticker.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        viewer?.close()
        viewer = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            viewer != null -> closeViewer()
            finding -> {
                finding = false
                refresh()
            }
            editingName && Online.myName.isNotEmpty() -> {
                editingName = false
                refresh()
            }
            else -> super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------- online

    private fun startOnline() {
        if (Online.myName.isEmpty()) return
        try {
            startForegroundService(Intent(this, OnlineService::class.java))
        } catch (e: Exception) {
            showHomeMessage("Não foi possível ficar online (${e.javaClass.simpleName}).")
        }
    }

    private fun saveName() {
        val name = nameInput.text.toString().trim()
        if (name.isEmpty()) {
            showHomeMessage("Escreva o seu nome.")
            return
        }
        hideKeyboard()
        Online.saveName(this, name)
        editingName = false
        homeMessage.visibility = View.GONE
        startOnline()
        refresh()
    }

    // ---------------------------------------------------------------- receber pedidos

    private fun allow() {
        val request = Online.incoming ?: return
        pendingAllow = request
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    private fun deny() {
        val request = Online.incoming ?: return
        Online.send(request.id, JSONObject().put("t", "deny"))
        clearIncoming()
    }

    private fun clearIncoming() {
        Online.incoming = null
        getSystemService(NotificationManager::class.java).cancel(OnlineService.NOTIF_REQUEST)
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        val request = pendingAllow
        pendingAllow = null
        if (request == null) return
        if (resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ShareService::class.java)
                .putExtra(ShareService.EXTRA_DATA, data)
                .putExtra(ShareService.EXTRA_VID, request.id)
                .putExtra(ShareService.EXTRA_VNAME, request.name)
            ShareState.status = ""
            startForegroundService(intent)
            clearIncoming()
        } else {
            Online.send(request.id, JSONObject().put("t", "deny"))
            clearIncoming()
        }
    }

    private fun stopShare() {
        stopService(Intent(this, ShareService::class.java))
    }

    // ---------------------------------------------------------------- ver a tela de alguém

    private fun showPeople() {
        val now = System.currentTimeMillis()
        val list = Online.people.values
            .filter { now - it.seen < 100_000 }
            .sortedBy { it.name.lowercase() }
        peopleList.removeAllViews()
        for (person in list) {
            peopleList.addView(button(person.name, true) { connectTo(person) }, lp(12))
        }
        peopleEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun connectTo(person: Person) {
        finding = false
        try {
            Rtc.init(this)
        } catch (e: Throwable) {
            showHomeMessage("Este celular não suporta a ligação de vídeo (${e.javaClass.simpleName}).")
            refresh()
            return
        }
        val renderer = SurfaceViewRenderer(this)
        renderer.init(Rtc.eglBase.eglBaseContext, null)
        renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        viewerHost.removeAllViews()
        viewerHost.addView(renderer, FrameLayout.LayoutParams(match, match))
        setViewerStatus("")
        viewerLayer.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val session = ViewerSession(person, renderer) { message -> runOnUiThread { setViewerStatus(message) } }
        viewer = session
        session.start()
        refresh()
    }

    private fun closeViewer() {
        viewer?.close()
        viewer = null
        viewerHost.removeAllViews()
        viewerLayer.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setViewerStatus(message: String) {
        viewerStatus.text = message
        viewerStatus.visibility = if (message.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------- interface

    private fun vis(show: Boolean) = if (show) View.VISIBLE else View.GONE

    private fun refresh() {
        val sharing = ShareState.active
        val request = Online.incoming
        val needName = Online.myName.isEmpty() || editingName
        val free = !sharing && request == null

        nameGroup.visibility = vis(free && needName)
        idleGroup.visibility = vis(free && !needName && !finding)
        peoplePanel.visibility = vis(free && !needName && finding)
        requestPanel.visibility = vis(!sharing && request != null)
        sharePanel.visibility = vis(sharing)

        helloText.text = "Olá, ${Online.myName}"
        requestText.text = "${request?.name.orEmpty()} quer ver a sua tela."
        shareWith.text = ShareState.name
        shareStatus.text = ShareState.status
        if (finding) showPeople()

        if (!sharing && ShareState.status.isNotEmpty()) {
            showHomeMessage(ShareState.status)
        } else if (sharing) {
            homeMessage.visibility = View.GONE
        }
    }

    private fun showHomeMessage(message: String) {
        homeMessage.text = message
        homeMessage.visibility = View.VISIBLE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(nameInput.windowToken, 0)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun lp(topMargin: Int = 0): LinearLayout.LayoutParams {
        val params = LinearLayout.LayoutParams(match, wrap)
        params.topMargin = dp(topMargin)
        return params
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val view = TextView(this)
        view.text = text
        view.textSize = size
        view.setTextColor(color)
        if (bold) view.setTypeface(view.typeface, Typeface.BOLD)
        return view
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): Button {
        val view = Button(this)
        view.text = text
        view.isAllCaps = false
        view.textSize = 17f
        view.setTextColor(if (primary) Color.WHITE else blue)
        val shape = GradientDrawable()
        shape.cornerRadius = dp(14).toFloat()
        shape.setColor(if (primary) blue else Color.WHITE)
        if (!primary) shape.setStroke(dp(2), blue)
        view.background = shape
        view.setPadding(dp(16), dp(16), dp(16), dp(16))
        view.setOnClickListener { onClick() }
        return view
    }

    private fun buildUi() {
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(24), dp(56), dp(24), dp(24))

        column.addView(label("Espelho", 34f, ink, true), lp())
        column.addView(
            label("Veja a tela de outro celular em direto, só com a permissão da pessoa.", 16f, grey),
            lp(8)
        )

        // --- primeira vez: escolher o nome
        nameGroup = LinearLayout(this)
        nameGroup.orientation = LinearLayout.VERTICAL
        nameGroup.addView(label("Como se chama?", 20f, ink, true), lp(36))
        nameGroup.addView(
            label("Este nome aparece na lista das outras pessoas que têm o Espelho.", 14f, grey),
            lp(6)
        )
        nameInput = EditText(this)
        nameInput.hint = "O seu nome"
        nameInput.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(24))
        nameInput.textSize = 20f
        nameInput.setTextColor(ink)
        nameInput.setSingleLine()
        nameInput.setText(Online.myName)
        nameGroup.addView(nameInput, lp(16))
        nameGroup.addView(button("Continuar", true) { saveName() }, lp(16))
        column.addView(nameGroup, lp())

        // --- normal
        idleGroup = LinearLayout(this)
        idleGroup.orientation = LinearLayout.VERTICAL
        helloText = label("", 22f, ink, true)
        idleGroup.addView(helloText, lp(36))
        idleGroup.addView(button("Ver a tela de alguém", true) {
            finding = true
            homeMessage.visibility = View.GONE
            refresh()
        }, lp(20))
        idleGroup.addView(
            label(
                "Para alguém poder ver a sua tela, basta ter o Espelho instalado e ficar com esta app ligada. " +
                    "Quando alguém pedir, aparece um aviso e você escolhe Permitir ou Recusar.",
                14f, grey
            ),
            lp(20)
        )
        idleGroup.addView(button("Mudar o meu nome", false) {
            editingName = true
            nameInput.setText(Online.myName)
            refresh()
        }, lp(24))
        column.addView(idleGroup, lp())

        // --- lista de pessoas
        peoplePanel = LinearLayout(this)
        peoplePanel.orientation = LinearLayout.VERTICAL
        peoplePanel.addView(label("Pessoas ligadas", 20f, ink, true), lp(36))
        peopleEmpty = label(
            "Ainda ninguém. A outra pessoa tem de ter o Espelho instalado e aberto, com internet.",
            15f, grey
        )
        peoplePanel.addView(peopleEmpty, lp(12))
        peopleList = LinearLayout(this)
        peopleList.orientation = LinearLayout.VERTICAL
        peoplePanel.addView(peopleList, lp())
        peoplePanel.addView(button("Voltar", false) {
            finding = false
            refresh()
        }, lp(28))
        column.addView(peoplePanel, lp())

        // --- pedido recebido
        requestPanel = LinearLayout(this)
        requestPanel.orientation = LinearLayout.VERTICAL
        requestText = label("", 22f, ink, true)
        requestText.gravity = Gravity.CENTER
        requestPanel.addView(requestText, lp(48))
        val askHint = label(
            "Se permitir, o Android vai pedir mais uma confirmação. Pode parar quando quiser.",
            14f, grey
        )
        askHint.gravity = Gravity.CENTER
        requestPanel.addView(askHint, lp(12))
        requestPanel.addView(button("Permitir", true) { allow() }, lp(28))
        requestPanel.addView(button("Recusar", false) { deny() }, lp(12))
        requestPanel.visibility = View.GONE
        column.addView(requestPanel, lp())

        // --- a partilhar
        sharePanel = LinearLayout(this)
        sharePanel.orientation = LinearLayout.VERTICAL
        sharePanel.visibility = View.GONE
        val sharingWith = label("A partilhar a tela com", 16f, grey)
        sharingWith.gravity = Gravity.CENTER
        sharePanel.addView(sharingWith, lp(40))
        shareWith = label("", 28f, blue, true)
        shareWith.gravity = Gravity.CENTER
        sharePanel.addView(shareWith, lp(8))
        shareStatus = label("", 16f, ink)
        shareStatus.gravity = Gravity.CENTER
        sharePanel.addView(shareStatus, lp(16))
        sharePanel.addView(button("Parar de partilhar", true) { stopShare() }, lp(32))
        column.addView(sharePanel, lp())

        homeMessage = label("", 15f, red)
        homeMessage.gravity = Gravity.CENTER
        homeMessage.visibility = View.GONE
        column.addView(homeMessage, lp(20))

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(column, FrameLayout.LayoutParams(match, wrap))

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#F6F7F9"))
        root.addView(scroll, FrameLayout.LayoutParams(match, match))

        // --- camada de visualização (por cima de tudo)
        viewerLayer = FrameLayout(this)
        viewerLayer.setBackgroundColor(Color.BLACK)
        viewerLayer.visibility = View.GONE
        viewerLayer.isClickable = true
        viewerHost = FrameLayout(this)
        viewerLayer.addView(viewerHost, FrameLayout.LayoutParams(match, match))
        viewerStatus = label("", 16f, Color.WHITE)
        viewerStatus.gravity = Gravity.CENTER
        viewerStatus.setPadding(dp(24), dp(24), dp(24), dp(24))
        viewerLayer.addView(viewerStatus, FrameLayout.LayoutParams(match, wrap, Gravity.CENTER))
        val exit = button("Sair", false) { closeViewer() }
        val exitParams = FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END)
        exitParams.setMargins(dp(12), dp(12), dp(12), dp(12))
        viewerLayer.addView(exit, exitParams)
        root.addView(viewerLayer, FrameLayout.LayoutParams(match, match))

        setContentView(root)
    }

    private companion object {
        const val REQ_CAPTURE = 42
    }
}
