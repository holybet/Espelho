package mz.espelho

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.RtpTransceiver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

/**
 * Quem vê: envia o pedido à pessoa escolhida; se ela permitir, recebe a oferta,
 * responde e mostra o vídeo no [renderer]. O [renderer] já tem de estar inicializado.
 */
class ViewerSession(
    private val target: Person,
    private val renderer: SurfaceViewRenderer,
    private val onStatus: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var pc: PeerConnection? = null
    private var remoteTrack: VideoTrack? = null
    private var closed = false
    private var gotOffer = false
    private var answerSent = false
    private var connectedOnce = false

    private val handler: (JSONObject) -> Unit = { m -> onSignal(m) }

    fun start() {
        onStatus("À espera que ${target.name} aceite…")
        Online.viewerHandler = handler
        Online.send(target.id, JSONObject().put("t", "req"))
        main.postDelayed({
            if (!closed && !gotOffer) onStatus("${target.name} não respondeu.")
        }, 75000)
    }

    private fun onSignal(m: JSONObject) {
        if (closed || m.optString("from") != target.id) return
        when (m.optString("t")) {
            "deny" -> {
                if (!gotOffer) {
                    onStatus(
                        if (m.optString("why") == "busy") "${target.name} está ocupado(a). Tente mais tarde."
                        else "${target.name} recusou."
                    )
                }
            }
            "offer" -> if (!gotOffer) {
                try {
                    handleOffer(unpack(m.optString("d")))
                } catch (e: Exception) {
                    onStatus("Erro: dados inválidos. Tente de novo.")
                }
            }
            "byes" -> onStatus("A partilha terminou.")
        }
    }

    private fun handleOffer(offerSdp: String) {
        if (offerSdp.isEmpty()) return
        gotOffer = true
        onStatus("A estabelecer a ligação…")

        val peer = Rtc.factory.createPeerConnection(Rtc.rtcConfig(), object : PcObserver() {
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {
                if (newState == PeerConnection.IceGatheringState.COMPLETE) {
                    main.post { sendAnswer() }
                }
            }

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                main.post { onIceState(newState) }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val received = transceiver?.receiver?.track()
                if (received is VideoTrack) {
                    main.post { attach(received) }
                }
            }
        })
        if (peer == null) {
            onStatus("Erro ao iniciar a ligação.")
            return
        }
        pc = peer
        peer.setRemoteDescription(object : SdpObs() {
            override fun onSetSuccess() {
                peer.createAnswer(object : SdpObs() {
                    override fun onCreateSuccess(description: SessionDescription?) {
                        peer.setLocalDescription(SdpObs(), description)
                        main.postDelayed({ sendAnswer() }, 4000)
                    }

                    override fun onCreateFailure(error: String?) {
                        main.post { onStatus("Erro ao responder à ligação.") }
                    }
                }, MediaConstraints())
            }

            override fun onSetFailure(error: String?) {
                main.post { onStatus("Erro ao ligar. Tente de novo.") }
            }
        }, SessionDescription(SessionDescription.Type.OFFER, offerSdp))
    }

    private fun sendAnswer() {
        if (closed || answerSent) return
        val sdp = pc?.localDescription?.description ?: return
        answerSent = true
        Online.send(target.id, JSONObject().put("t", "answer").put("d", pack(sdp)))
    }

    private fun attach(video: VideoTrack) {
        if (closed) return
        remoteTrack = video
        video.addSink(renderer)
    }

    private fun onIceState(state: PeerConnection.IceConnectionState?) {
        if (closed) return
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED,
            PeerConnection.IceConnectionState.COMPLETED -> {
                connectedOnce = true
                onStatus("")
            }
            PeerConnection.IceConnectionState.DISCONNECTED -> onStatus("Ligação instável…")
            PeerConnection.IceConnectionState.FAILED,
            PeerConnection.IceConnectionState.CLOSED -> {
                if (connectedOnce) {
                    onStatus("A partilha terminou.")
                } else {
                    onStatus("Não foi possível ligar. A rede de algum dos celulares pode estar a bloquear a ligação.")
                }
            }
            else -> {}
        }
    }

    fun close() {
        if (closed) return
        closed = true
        main.removeCallbacksAndMessages(null)
        Online.send(target.id, JSONObject().put("t", "byev"))
        if (Online.viewerHandler === handler) Online.viewerHandler = null
        try {
            remoteTrack?.removeSink(renderer)
        } catch (ignored: Exception) {
        }
        try {
            pc?.close()
            pc?.dispose()
        } catch (ignored: Exception) {
        }
        pc = null
        try {
            renderer.release()
        } catch (ignored: Exception) {
        }
    }
}
