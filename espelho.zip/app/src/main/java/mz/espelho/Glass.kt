package mz.espelho

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Peças do visual "vidro líquido": cartões translúcidos com contorno luminoso. */
object Glass {
    val BG: Int = Color.parseColor("#070B1F")

    fun dp(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

    private fun white(a: Int) = Color.argb(a, 255, 255, 255)

    /** Cartão de vidro: fundo translúcido com brilho no topo e contorno que apanha a luz. */
    fun card(ctx: Context, radiusDp: Float = 28f, strength: Int = 30): LayerDrawable {
        val r = dp(ctx, radiusDp)
        val border = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(white(150), white(26), white(85))
        )
        border.cornerRadius = r
        val fill = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(white(strength + 22), white(strength))
        )
        fill.cornerRadius = max(0f, r - dp(ctx, 1f))
        val layer = LayerDrawable(arrayOf(border, fill))
        val inset = dp(ctx, 1f).toInt()
        layer.setLayerInset(1, inset, inset, inset, inset)
        return layer
    }

    /** Botão principal: vidro colorido (ciano → índigo → violeta) com contorno luminoso. */
    fun accent(ctx: Context, radiusDp: Float = 26f): LayerDrawable {
        val r = dp(ctx, radiusDp)
        val border = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(white(230), white(40), white(130))
        )
        border.cornerRadius = r
        val fill = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.argb(225, 34, 211, 238),
                Color.argb(225, 99, 102, 241),
                Color.argb(225, 168, 85, 247)
            )
        )
        fill.cornerRadius = max(0f, r - dp(ctx, 1f))
        val layer = LayerDrawable(arrayOf(border, fill))
        val inset = dp(ctx, 1f).toInt()
        layer.setLayerInset(1, inset, inset, inset, inset)
        return layer
    }

    fun circle(c1: Int, c2: Int): GradientDrawable {
        val d = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
        d.shape = GradientDrawable.OVAL
        return d
    }

    /** Ao tocar, o botão encolhe um pouco e volta com um pequeno salto. */
    @SuppressLint("ClickableViewAccessibility")
    fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(110).setInterpolator(null).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(320)
                        .setInterpolator(OvershootInterpolator(2.4f)).start()
            }
            false
        }
    }
}

/** Fundo escuro com manchas de cor a derivar devagar, que dão profundidade ao vidro. */
class AuroraView(context: Context) : View(context) {

    private class Blob(
        val color: Int,
        val fx: Float, val fy: Float,
        val ax: Float, val ay: Float,
        val radius: Float,
        val kx: Int, val ky: Int,
        val phase: Float
    ) {
        var shader: Shader? = null
        var r = 0f
    }

    private val blobs = listOf(
        Blob(Color.rgb(34, 211, 238), 0.15f, 0.12f, 0.16f, 0.07f, 0.62f, 1, 2, 0.0f),
        Blob(Color.rgb(139, 92, 246), 0.90f, 0.32f, 0.14f, 0.09f, 0.66f, 2, 1, 1.7f),
        Blob(Color.rgb(59, 130, 246), 0.20f, 0.62f, 0.15f, 0.08f, 0.58f, 1, 1, 3.1f),
        Blob(Color.rgb(244, 114, 182), 0.85f, 0.90f, 0.12f, 0.07f, 0.55f, 2, 2, 4.6f)
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f

    private val animator = ValueAnimator.ofFloat(0f, (2.0 * Math.PI).toFloat()).apply {
        duration = 26000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val base = max(w, h).toFloat()
        for (b in blobs) {
            b.r = b.radius * base
            b.shader = RadialGradient(
                0f, 0f, b.r,
                intArrayOf(
                    Color.argb(105, Color.red(b.color), Color.green(b.color), Color.blue(b.color)),
                    Color.argb(0, Color.red(b.color), Color.green(b.color), Color.blue(b.color))
                ),
                null, Shader.TileMode.CLAMP
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Glass.BG)
        val w = width.toFloat()
        val h = height.toFloat()
        for (b in blobs) {
            val cx = (b.fx + b.ax * sin(t * b.kx + b.phase)) * w
            val cy = (b.fy + b.ay * cos(t * b.ky + b.phase)) * h
            canvas.save()
            canvas.translate(cx, cy)
            paint.shader = b.shader
            canvas.drawCircle(0f, 0f, b.r, paint)
            canvas.restore()
        }
    }
}

/** Logótipo "EV": quadrado de vidro com as letras em degradê. */
class LogoView(context: Context) : View(context) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = Glass.dp(context, 1.3f)
        stroke.color = Color.argb(140, 255, 255, 255)
        text.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        text.textAlign = Paint.Align.CENTER
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fill.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            Color.argb(120, 34, 211, 238), Color.argb(120, 139, 92, 246), Shader.TileMode.CLAMP
        )
        text.textSize = h * 0.42f
        text.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            Color.WHITE, Color.rgb(190, 246, 255), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val inset = stroke.strokeWidth / 2f
        rect.set(inset, inset, width - inset, height - inset)
        val radius = height * 0.32f
        canvas.drawRoundRect(rect, radius, radius, fill)
        canvas.drawRoundRect(rect, radius, radius, stroke)
        val y = height / 2f - (text.ascent() + text.descent()) / 2f
        canvas.drawText("EV", width / 2f, y, text)
    }
}
